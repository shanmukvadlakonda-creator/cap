"""
One-time migration: adds account_id column to transactions table.

Run AFTER restarting Flask (so db.create_all() creates the accounts table first):
    python migrate.py
"""
from app.app import create_app, db
from sqlalchemy import text

app = create_app()
with app.app_context():
    with db.engine.connect() as conn:
        conn.execute(text("""
            ALTER TABLE transactions
            ADD COLUMN IF NOT EXISTS account_id INTEGER REFERENCES accounts(id);
        """))
        conn.commit()
    print("Migration complete: account_id column added to transactions.")
