from pydantic import BaseModel
from typing import Optional, List
from datetime import date, datetime
from decimal import Decimal


# ─── Auth ────────────────────────────────────────────────────────────────────

class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: int
    display_name: str


# ─── Users ───────────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    username: str
    display_name: str
    password: str


class UserOut(BaseModel):
    id: int
    username: str
    display_name: str
    created_at: datetime

    class Config:
        from_attributes = True


# ─── Categories ──────────────────────────────────────────────────────────────

class CategoryOut(BaseModel):
    id: int
    name: str
    sort_order: int

    class Config:
        from_attributes = True


class CategoryGroupOut(BaseModel):
    id: int
    name: str
    type: str
    sort_order: int
    categories: List[CategoryOut] = []

    class Config:
        from_attributes = True


# ─── Budget ──────────────────────────────────────────────────────────────────

class BudgetCreate(BaseModel):
    year: int
    beginning_spending_balance: Decimal = Decimal("0")
    beginning_savings_balance: Decimal = Decimal("0")


class BudgetOut(BaseModel):
    id: int
    year: int
    beginning_spending_balance: Decimal
    beginning_savings_balance: Decimal

    class Config:
        from_attributes = True


# ─── Budget Targets ──────────────────────────────────────────────────────────

class TargetUpdate(BaseModel):
    planned_amount: Decimal


class TargetOut(BaseModel):
    id: int
    category_id: int
    month: int
    planned_amount: Decimal

    class Config:
        from_attributes = True


# ─── Transactions ────────────────────────────────────────────────────────────

class TransactionCreate(BaseModel):
    category_id: int
    user_id: int
    amount: Decimal
    transaction_date: date
    payment_method: str = "Cash"
    note: Optional[str] = None
    year: Optional[int] = None  # if omitted, inferred from transaction_date


class TransactionUpdate(BaseModel):
    category_id: Optional[int] = None
    user_id: Optional[int] = None
    amount: Optional[Decimal] = None
    transaction_date: Optional[date] = None
    payment_method: Optional[str] = None
    note: Optional[str] = None


class TransactionOut(BaseModel):
    id: int
    budget_id: int
    category_id: int
    category_name: str
    category_group: str
    user_id: int
    user_display_name: str
    amount: Decimal
    transaction_date: date
    payment_method: str
    note: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ─── Summary / Reports ───────────────────────────────────────────────────────

class DailySummary(BaseModel):
    date: date
    total_income: Decimal
    total_expenses: Decimal
    net: Decimal
    spending_balance: Decimal
    savings_balance: Decimal


class CategorySummary(BaseModel):
    category_id: int
    category_name: str
    group_name: str
    group_type: str
    actual: Decimal
    planned: Decimal
    variance: Decimal  # planned - actual (negative = over budget)


class GroupSummary(BaseModel):
    group_id: int
    group_name: str
    group_type: str
    actual: Decimal
    planned: Decimal
    percent_of_expenses: float
    categories: List[CategorySummary] = []


class MonthlySummary(BaseModel):
    month: int
    month_name: str
    total_income: Decimal
    total_expenses: Decimal
    net: Decimal
    savings_deposited: Decimal
    spending_balance: Decimal
    savings_balance: Decimal
    groups: List[GroupSummary] = []


class AnnualSummary(BaseModel):
    year: int
    beginning_spending_balance: Decimal
    beginning_savings_balance: Decimal
    total_income: Decimal
    total_expenses: Decimal
    net: Decimal
    monthly: List[MonthlySummary] = []


class MonthlyDailyView(BaseModel):
    year: int
    month: int
    month_name: str
    beginning_spending_balance: Decimal
    beginning_savings_balance: Decimal
    days: List[DailySummary] = []
    groups: List[GroupSummary] = []


class CategoryBreakdown(BaseModel):
    group_name: str
    amount: Decimal
    percentage: float


class MonthlyTrend(BaseModel):
    month: int
    month_name: str
    income: Decimal
    expenses: Decimal
    net: Decimal


class PersonSpending(BaseModel):
    user_id: int
    display_name: str
    total_spent: Decimal
    percentage: float
