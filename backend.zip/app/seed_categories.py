"""
Seed all budget categories from the Excel file into the database.
Called automatically on server startup (idempotent).
"""
from app.app import db
from app import models

CATEGORIES = [
    {
        "name": "INCOME",
        "type": "income",
        "sort_order": 1,
        "items": [
            "Wages & Tips",
            "Interest Income",
            "Dividends",
            "Gifts Received",
            "Refunds/Reimbursements",
            "Other",
            "Transfer From Savings",
        ],
    },
    {
        "name": "SAVINGS EXPENSE",
        "type": "savings",
        "sort_order": 2,
        "items": [
            "Emergency Fund",
            "Car Replacement Fund",
            "Retirement Fund",
            "Investments",
            "Education Fund",
            "Other",
        ],
    },
    {
        "name": "HOME EXPENSES",
        "type": "expense",
        "sort_order": 3,
        "items": [
            "Mortgage/Rent",
            "Electricity",
            "Gas/Oil",
            "Water/Sewer/Trash",
            "Phone",
            "Cable/Satellite",
            "Internet",
            "Furnishings/Appliances",
            "Lawn/Garden",
            "Home Supplies",
            "Maintenance",
            "Improvements",
            "Other",
        ],
    },
    {
        "name": "DAILY LIVING",
        "type": "expense",
        "sort_order": 4,
        "items": [
            "Groceries",
            "Personal Supplies",
            "Clothing",
            "Cleaning Services",
            "Dining/Eating Out",
            "Dry Cleaning",
            "Salon/Barber",
            "Discretionary - Name 1",
            "Discretionary - Name 2",
            "Other",
        ],
    },
    {
        "name": "CHILDREN",
        "type": "expense",
        "sort_order": 5,
        "items": [
            "Medical",
            "Clothing",
            "School Tuition",
            "School Lunch",
            "School Supplies",
            "Babysitting",
            "Toys/Games",
            "Other",
        ],
    },
    {
        "name": "TRANSPORTATION",
        "type": "expense",
        "sort_order": 6,
        "items": [
            "Vehicle Payments",
            "Fuel",
            "Bus/Taxi/Train Fare",
            "Repairs",
            "Registration/License",
            "Other",
        ],
    },
    {
        "name": "HEALTH",
        "type": "expense",
        "sort_order": 7,
        "items": [
            "Doctor/Dentist",
            "Medicine/Drugs",
            "Health Club Dues",
            "Emergency",
            "Other",
        ],
    },
    {
        "name": "INSURANCE",
        "type": "expense",
        "sort_order": 8,
        "items": [
            "Auto",
            "Health",
            "Home/Rental",
            "Life",
            "Other",
        ],
    },
    {
        "name": "EDUCATION",
        "type": "expense",
        "sort_order": 9,
        "items": [
            "Tuition",
            "Books",
            "Music Lessons",
            "Other",
        ],
    },
    {
        "name": "CHARITY/GIFTS",
        "type": "expense",
        "sort_order": 10,
        "items": [
            "Gifts Given",
            "Charitable Donations",
            "Religious Donations",
            "Other",
        ],
    },
    {
        "name": "OBLIGATIONS",
        "type": "expense",
        "sort_order": 11,
        "items": [
            "Student Loans",
            "Credit Card Debt",
            "Other Loans",
            "Alimony/Child Support",
            "Federal Taxes",
            "State/Local Taxes",
            "Legal Fees",
            "Other",
        ],
    },
    {
        "name": "BUSINESS EXPENSE",
        "type": "expense",
        "sort_order": 12,
        "items": [
            "Deductible Expenses",
            "Non-Deductible Expenses",
            "Other",
        ],
    },
    {
        "name": "ENTERTAINMENT",
        "type": "expense",
        "sort_order": 13,
        "items": [
            "Activities",
            "Books",
            "Games",
            "Fun Stuff",
            "Hobbies",
            "Media",
            "Outdoor Recreation",
            "Sports",
            "Toys/Gadgets",
            "Vacation/Travel",
            "Other",
        ],
    },
    {
        "name": "PETS",
        "type": "expense",
        "sort_order": 14,
        "items": [
            "Food",
            "Medical",
            "Toys/Supplies",
            "Other",
        ],
    },
    {
        "name": "SUBSCRIPTIONS",
        "type": "expense",
        "sort_order": 15,
        "items": [
            "Newspaper",
            "Magazines",
            "Dues",
            "Club Memberships",
            "Other",
        ],
    },
    {
        "name": "VACATION",
        "type": "expense",
        "sort_order": 16,
        "items": [
            "Travel",
            "Lodging",
            "Food",
            "Rental Car",
            "Entertainment",
            "Other",
        ],
    },
    {
        "name": "MISCELLANEOUS",
        "type": "expense",
        "sort_order": 17,
        "items": [
            "Bank Fees",
            "Postage",
            "Other",
        ],
    },
    {
        "name": "CREDIT CARDS",
        "type": "expense",
        "sort_order": 18,
        "items": [
            "SBI",
            "ICICI",
            "RBL",
            "HDFC",
            "HDFC Rupay",
            "Yes Rupay",
        ],
    },
]


def seed():
    try:
        existing = db.session.query(models.CategoryGroup).count()
        if existing > 0:
            print("Categories already seeded. Skipping.")
            return

        for group_data in CATEGORIES:
            group = models.CategoryGroup(
                name=group_data["name"],
                type=group_data["type"],
                sort_order=group_data["sort_order"],
            )
            db.session.add(group)
            db.session.flush()

            for i, item_name in enumerate(group_data["items"]):
                cat = models.Category(
                    group_id=group.id,
                    name=item_name,
                    sort_order=i + 1,
                )
                db.session.add(cat)

        db.session.commit()
        print(f"Seeded {len(CATEGORIES)} category groups successfully.")
    except Exception as e:
        db.session.rollback()
        print(f"Error seeding categories: {e}")


if __name__ == "__main__":
    seed()
