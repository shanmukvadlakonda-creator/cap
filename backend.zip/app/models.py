from sqlalchemy import Column, Integer, String, Numeric, Date, DateTime, ForeignKey, Text, UniqueConstraint
from sqlalchemy.orm import relationship
from app.database import Base
import datetime


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    display_name = Column(String(100), nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    transactions = relationship("Transaction", back_populates="user")


class CategoryGroup(Base):
    __tablename__ = "category_groups"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    # 'income' | 'expense' | 'savings'
    type = Column(String(20), nullable=False)
    sort_order = Column(Integer, default=0)

    categories = relationship("Category", back_populates="group", order_by="Category.sort_order")


class Category(Base):
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True, index=True)
    group_id = Column(Integer, ForeignKey("category_groups.id"), nullable=False)
    name = Column(String(100), nullable=False)
    sort_order = Column(Integer, default=0)

    group = relationship("CategoryGroup", back_populates="categories")
    transactions = relationship("Transaction", back_populates="category")
    targets = relationship("BudgetTarget", back_populates="category")


class Budget(Base):
    __tablename__ = "budgets"

    id = Column(Integer, primary_key=True, index=True)
    year = Column(Integer, nullable=False, unique=True)
    beginning_spending_balance = Column(Numeric(15, 2), default=0)
    beginning_savings_balance = Column(Numeric(15, 2), default=0)

    targets = relationship("BudgetTarget", back_populates="budget")
    transactions = relationship("Transaction", back_populates="budget")


class BudgetTarget(Base):
    __tablename__ = "budget_targets"

    id = Column(Integer, primary_key=True, index=True)
    budget_id = Column(Integer, ForeignKey("budgets.id"), nullable=False)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    month = Column(Integer, nullable=False)  # 1-12
    planned_amount = Column(Numeric(15, 2), default=0)

    __table_args__ = (UniqueConstraint("budget_id", "category_id", "month"),)

    budget = relationship("Budget", back_populates="targets")
    category = relationship("Category", back_populates="targets")


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    budget_id = Column(Integer, ForeignKey("budgets.id"), nullable=False)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    amount = Column(Numeric(15, 2), nullable=False)
    transaction_date = Column(Date, nullable=False)
    # Cash | SBI | ICICI | RBL | HDFC | HDFC Rupay | Yes Rupay
    payment_method = Column(String(50), default="Cash")
    note = Column(Text)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    budget = relationship("Budget", back_populates="transactions")
    category = relationship("Category", back_populates="transactions")
    user = relationship("User", back_populates="transactions")


class CreditCard(Base):
    __tablename__ = "credit_cards"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    available_balance = Column(Numeric(15, 2), default=0)
    due_amount = Column(Numeric(15, 2), default=0)


class Loan(Base):
    __tablename__ = "loans"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    outstanding_amount = Column(Numeric(15, 2), default=0)
