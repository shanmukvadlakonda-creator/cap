from app.app import db
import datetime


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True, index=True)
    username = db.Column(db.String(50), unique=True, nullable=False, index=True)
    display_name = db.Column(db.String(100), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='member')  # 'admin' | 'member' | 'viewer'
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    transactions = db.relationship("Transaction", back_populates="user")


class CategoryGroup(db.Model):
    __tablename__ = "category_groups"

    id = db.Column(db.Integer, primary_key=True, index=True)
    name = db.Column(db.String(100), nullable=False)
    # 'income' | 'expense' | 'savings'
    type = db.Column(db.String(20), nullable=False)
    sort_order = db.Column(db.Integer, default=0)

    categories = db.relationship("Category", back_populates="group", order_by="Category.sort_order")


class Category(db.Model):
    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True, index=True)
    group_id = db.Column(db.Integer, db.ForeignKey("category_groups.id"), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    sort_order = db.Column(db.Integer, default=0)

    group = db.relationship("CategoryGroup", back_populates="categories")
    transactions = db.relationship("Transaction", back_populates="category")
    targets = db.relationship("BudgetTarget", back_populates="category")


class Budget(db.Model):
    __tablename__ = "budgets"

    id = db.Column(db.Integer, primary_key=True, index=True)
    year = db.Column(db.Integer, nullable=False, unique=True)
    beginning_spending_balance = db.Column(db.Numeric(15, 2), default=0)
    beginning_savings_balance = db.Column(db.Numeric(15, 2), default=0)

    targets = db.relationship("BudgetTarget", back_populates="budget")
    transactions = db.relationship("Transaction", back_populates="budget")


class BudgetTarget(db.Model):
    __tablename__ = "budget_targets"

    id = db.Column(db.Integer, primary_key=True, index=True)
    budget_id = db.Column(db.Integer, db.ForeignKey("budgets.id"), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    month = db.Column(db.Integer, nullable=False)  # 1-12
    planned_amount = db.Column(db.Numeric(15, 2), default=0)

    __table_args__ = (db.UniqueConstraint("budget_id", "category_id", "month"),)

    budget = db.relationship("Budget", back_populates="targets")
    category = db.relationship("Category", back_populates="targets")


class Transaction(db.Model):
    __tablename__ = "transactions"

    id = db.Column(db.Integer, primary_key=True, index=True)
    budget_id = db.Column(db.Integer, db.ForeignKey("budgets.id"), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    account_id = db.Column(db.Integer, db.ForeignKey("accounts.id"), nullable=True)
    amount = db.Column(db.Numeric(15, 2), nullable=False)
    transaction_date = db.Column(db.Date, nullable=False)
    # Cash | SBI | ICICI | RBL | HDFC | HDFC Rupay | Yes Rupay (legacy — new rows use account_id)
    payment_method = db.Column(db.String(50), default="Cash")
    note = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    budget = db.relationship("Budget", back_populates="transactions")
    category = db.relationship("Category", back_populates="transactions")
    user = db.relationship("User", back_populates="transactions")
    account = db.relationship("Account", back_populates="transactions")


class Account(db.Model):
    __tablename__ = "accounts"

    id = db.Column(db.Integer, primary_key=True, index=True)
    name = db.Column(db.String(100), nullable=False)
    # 'bank' | 'credit_card' | 'cash'
    type = db.Column(db.String(20), nullable=False)
    opening_balance = db.Column(db.Numeric(15, 2), default=0)
    is_active = db.Column(db.Boolean, default=True)
    sort_order = db.Column(db.Integer, default=0)

    transactions = db.relationship("Transaction", back_populates="account")
    transfers_out = db.relationship("AccountTransfer",
        foreign_keys="AccountTransfer.from_account_id", back_populates="from_account")
    transfers_in = db.relationship("AccountTransfer",
        foreign_keys="AccountTransfer.to_account_id", back_populates="to_account")
    investments = db.relationship("Investment", back_populates="account")
    loans = db.relationship("Loan", back_populates="account")


class AccountTransfer(db.Model):
    __tablename__ = "account_transfers"

    id = db.Column(db.Integer, primary_key=True, index=True)
    from_account_id = db.Column(db.Integer, db.ForeignKey("accounts.id"), nullable=False)
    to_account_id = db.Column(db.Integer, db.ForeignKey("accounts.id"), nullable=False)
    amount = db.Column(db.Numeric(15, 2), nullable=False)
    transfer_date = db.Column(db.Date, nullable=False)
    note = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    from_account = db.relationship("Account", foreign_keys=[from_account_id], back_populates="transfers_out")
    to_account = db.relationship("Account", foreign_keys=[to_account_id], back_populates="transfers_in")


class Investment(db.Model):
    __tablename__ = "investments"

    id            = db.Column(db.Integer, primary_key=True, index=True)
    name          = db.Column(db.String(200), nullable=False)
    type          = db.Column(db.String(50), nullable=False)   # SIP|FD|Gold|Land|Other
    account_id    = db.Column(db.Integer, db.ForeignKey("accounts.id"), nullable=True)
    amount        = db.Column(db.Numeric(15, 2), nullable=False)
    current_value = db.Column(db.Numeric(15, 2), nullable=True)
    start_date    = db.Column(db.Date, nullable=False)
    maturity_date = db.Column(db.Date, nullable=True)
    notes         = db.Column(db.Text)
    is_active     = db.Column(db.Boolean, default=True)
    created_at    = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    account = db.relationship("Account", back_populates="investments")


class CreditCard(db.Model):
    __tablename__ = "credit_cards"

    id = db.Column(db.Integer, primary_key=True, index=True)
    name = db.Column(db.String(50), nullable=False)
    available_balance = db.Column(db.Numeric(15, 2), default=0)
    due_amount = db.Column(db.Numeric(15, 2), default=0)


class Loan(db.Model):
    __tablename__ = "loans"

    id                 = db.Column(db.Integer, primary_key=True, index=True)
    name               = db.Column(db.String(200), nullable=False)
    type               = db.Column(db.String(50), nullable=False, default='Personal')  # Gold|Personal|Home|Vehicle|Education|Other
    lender             = db.Column(db.String(200))
    principal_amount   = db.Column(db.Numeric(15, 2), nullable=False, default=0)
    outstanding_amount = db.Column(db.Numeric(15, 2), nullable=False, default=0)
    interest_rate      = db.Column(db.Numeric(5, 2))
    emi_amount         = db.Column(db.Numeric(15, 2))
    start_date         = db.Column(db.Date)
    end_date           = db.Column(db.Date)
    account_id         = db.Column(db.Integer, db.ForeignKey("accounts.id"), nullable=True)
    notes              = db.Column(db.Text)
    is_active          = db.Column(db.Boolean, default=True)
    created_at         = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    account = db.relationship("Account", back_populates="loans")
