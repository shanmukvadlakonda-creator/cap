from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from app.config import Config

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Initialize database
    db.init_app(app)

    # Enable CORS for local network access (desktop + mobile on same Wi-Fi)
    CORS(app, resources={r"/api/*": {"origins": "*"}})

    with app.app_context():
        # Import models
        from app import models

        # Create all tables
        db.create_all()

        # Seed categories
        from app.seed_categories import seed
        seed()

        # Register blueprints
        from app.routers import auth, users, categories, budget, targets, transactions, reports, accounts, transfers, investments
        app.register_blueprint(auth.bp)
        app.register_blueprint(users.bp)
        app.register_blueprint(categories.bp)
        app.register_blueprint(budget.bp)
        app.register_blueprint(targets.bp)
        app.register_blueprint(transactions.bp)
        app.register_blueprint(reports.bp)
        app.register_blueprint(accounts.bp)
        app.register_blueprint(transfers.bp)
        app.register_blueprint(investments.bp)

        # Health check endpoint
        @app.route('/api/health', methods=['GET'])
        def health():
            return {
                "status": "ok",
                "message": "Family Budget Planner API is running"
            }, 200

    return app
