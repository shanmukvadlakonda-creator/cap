from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import auth, users, transactions, budget, targets, reports, categories

app = FastAPI(
    title="Family Budget Planner API",
    description="REST API for the Family Budget Planner app",
    version="1.0.0",
)

# Allow all origins for local network access (desktop + mobile on same Wi-Fi)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(categories.router)
app.include_router(budget.router)
app.include_router(targets.router)
app.include_router(transactions.router)
app.include_router(reports.router)


@app.on_event("startup")
def on_startup():
    from app.database import engine
    from app import models
    from app.seed_categories import seed
    models.Base.metadata.create_all(bind=engine)
    seed()


@app.get("/", tags=["health"])
def health():
    return {"status": "ok", "message": "Family Budget Planner API is running"}
