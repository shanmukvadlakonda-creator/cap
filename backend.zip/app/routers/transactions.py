from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models
from datetime import datetime

bp = Blueprint('transactions', __name__, url_prefix='/api/transactions')


def _serialize(t):
    return {
        "id": t.id,
        "budget_id": t.budget_id,
        "category_id": t.category_id,
        "category_name": t.category.name if t.category else None,
        "category_group": t.category.group.name if t.category and t.category.group else None,
        "user_id": t.user_id,
        "user_display_name": t.user.display_name if t.user else None,
        "amount": float(t.amount),
        "transaction_date": t.transaction_date.isoformat(),
        "payment_method": t.payment_method,
        "account_id": t.account_id,
        "account_name": t.account.name if t.account else t.payment_method,
        "note": t.note,
        "created_at": t.created_at.isoformat() if t.created_at else None,
    }


@bp.route('', methods=['GET'])
@auth.token_required
def list_transactions(current_user):
    year = request.args.get('year', type=int)
    month = request.args.get('month', type=int)

    query = models.Transaction.query

    if year is not None:
        budget = models.Budget.query.filter_by(year=year).first()
        if not budget:
            return jsonify([]), 200
        query = query.filter_by(budget_id=budget.id)

    transactions = query.order_by(models.Transaction.transaction_date.desc()).all()

    if month is not None:
        transactions = [t for t in transactions if t.transaction_date.month == month]

    return jsonify([_serialize(t) for t in transactions]), 200


@bp.route('', methods=['POST'])
@auth.token_required
def create_transaction(current_user):
    data = request.get_json()
    if not data or not data.get('category_id') or not data.get('amount'):
        return jsonify({"detail": "Missing required fields"}), 400

    tx_date = datetime.fromisoformat(data['transaction_date']).date() if data.get('transaction_date') else datetime.now().date()

    # Resolve budget from year derived from date
    budget = models.Budget.query.filter_by(year=tx_date.year).first()
    if not budget:
        return jsonify({"detail": f"No budget found for year {tx_date.year}"}), 404

    user_id = data.get('user_id', current_user.id)

    transaction = models.Transaction(
        budget_id=budget.id,
        category_id=data['category_id'],
        user_id=user_id,
        account_id=data.get('account_id'),
        amount=data['amount'],
        transaction_date=tx_date,
        payment_method=data.get('payment_method', 'Cash'),
        note=data.get('note'),
    )
    db.session.add(transaction)
    db.session.commit()

    # Reload with relationships
    db.session.refresh(transaction)
    return jsonify(_serialize(transaction)), 201


@bp.route('/<int:transaction_id>', methods=['DELETE'])
@auth.token_required
def delete_transaction(current_user, transaction_id):
    transaction = models.Transaction.query.get(transaction_id)
    if not transaction:
        return jsonify({"detail": "Transaction not found"}), 404

    db.session.delete(transaction)
    db.session.commit()
    return '', 204
