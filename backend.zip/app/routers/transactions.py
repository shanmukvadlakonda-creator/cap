from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date

from app.database import get_db
from app import models, schemas
from app.auth import get_current_user

router = APIRouter(prefix="/transactions", tags=["transactions"])


def _get_or_create_budget(year: int, db: Session) -> models.Budget:
    budget = db.query(models.Budget).filter(models.Budget.year == year).first()
    if not budget:
        budget = models.Budget(year=year)
        db.add(budget)
        db.commit()
        db.refresh(budget)
    return budget


def _enrich(tx: models.Transaction) -> schemas.TransactionOut:
    return schemas.TransactionOut(
        id=tx.id,
        budget_id=tx.budget_id,
        category_id=tx.category_id,
        category_name=tx.category.name,
        category_group=tx.category.group.name,
        user_id=tx.user_id,
        user_display_name=tx.user.display_name,
        amount=tx.amount,
        transaction_date=tx.transaction_date,
        payment_method=tx.payment_method,
        note=tx.note,
        created_at=tx.created_at,
    )


@router.post("", response_model=schemas.TransactionOut, status_code=201)
def add_transaction(
    body: schemas.TransactionCreate,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    year = body.year or body.transaction_date.year
    budget = _get_or_create_budget(year, db)

    category = db.query(models.Category).filter(models.Category.id == body.category_id).first()
    if not category:
        raise HTTPException(status_code=404, detail="Category not found")

    user = db.query(models.User).filter(models.User.id == body.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    tx = models.Transaction(
        budget_id=budget.id,
        category_id=body.category_id,
        user_id=body.user_id,
        amount=body.amount,
        transaction_date=body.transaction_date,
        payment_method=body.payment_method,
        note=body.note,
    )
    db.add(tx)
    db.commit()
    db.refresh(tx)
    return _enrich(tx)


@router.get("", response_model=List[schemas.TransactionOut])
def list_transactions(
    year: Optional[int] = None,
    month: Optional[int] = None,
    day: Optional[int] = None,
    category_id: Optional[int] = None,
    user_id: Optional[int] = None,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    q = db.query(models.Transaction)

    if year:
        budget = db.query(models.Budget).filter(models.Budget.year == year).first()
        if budget:
            q = q.filter(models.Transaction.budget_id == budget.id)
        else:
            return []

    if month:
        q = q.filter(
            models.Transaction.transaction_date >= date(year or date.today().year, month, 1)
        )
        import calendar
        last_day = calendar.monthrange(year or date.today().year, month)[1]
        q = q.filter(
            models.Transaction.transaction_date <= date(year or date.today().year, month, last_day)
        )

    if day and month and year:
        q = q.filter(models.Transaction.transaction_date == date(year, month, day))

    if category_id:
        q = q.filter(models.Transaction.category_id == category_id)

    if user_id:
        q = q.filter(models.Transaction.user_id == user_id)

    q = q.order_by(models.Transaction.transaction_date.desc(), models.Transaction.created_at.desc())
    return [_enrich(tx) for tx in q.all()]


@router.get("/{tx_id}", response_model=schemas.TransactionOut)
def get_transaction(
    tx_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    tx = db.query(models.Transaction).filter(models.Transaction.id == tx_id).first()
    if not tx:
        raise HTTPException(status_code=404, detail="Transaction not found")
    return _enrich(tx)


@router.put("/{tx_id}", response_model=schemas.TransactionOut)
def update_transaction(
    tx_id: int,
    body: schemas.TransactionUpdate,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    tx = db.query(models.Transaction).filter(models.Transaction.id == tx_id).first()
    if not tx:
        raise HTTPException(status_code=404, detail="Transaction not found")

    for field, value in body.model_dump(exclude_none=True).items():
        setattr(tx, field, value)

    db.commit()
    db.refresh(tx)
    return _enrich(tx)


@router.delete("/{tx_id}", status_code=204)
def delete_transaction(
    tx_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    tx = db.query(models.Transaction).filter(models.Transaction.id == tx_id).first()
    if not tx:
        raise HTTPException(status_code=404, detail="Transaction not found")
    db.delete(tx)
    db.commit()
