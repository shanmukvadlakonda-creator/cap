from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models
from datetime import datetime

bp = Blueprint('transactions', __name__, url_prefix='/api/transactions')


def _serialize(t):
    return {
        "id": t.id,
        "budget_id": t.budget_id,
        "category_id": t.category_id,
        "category_name": t.category.name if t.category else None,
        "category_group": t.category.group.name if t.category and t.category.group else None,
        "user_id": t.user_id,
        "user_display_name": t.user.display_name if t.user else None,
        "amount": float(t.amount),
        "transaction_date": t.transaction_date.isoformat(),
        "payment_method": t.payment_method,
        "account_id": t.account_id,
        "account_name": t.account.name if t.account else t.payment_method,
        "investment_id": t.investment_id,
        "investment_name": t.investment.name if t.investment else None,
        "loan_id": t.loan_id,
        "loan_name": t.loan.name if t.loan else None,
        "note": t.note,
        "created_at": t.created_at.isoformat() if t.created_at else None,
    }


@bp.route('', methods=['GET'])
@auth.token_required
def list_transactions(current_user):
    year = request.args.get('year', type=int)
    month = request.args.get('month', type=int)
    user_id = request.args.get('user_id', type=int)

    # Viewers can only see their own transactions
    if current_user.role == 'viewer':
        user_id = current_user.id

    query = models.Transaction.query

    if year is not None:
        budget = models.Budget.query.filter_by(year=year).first()
        if not budget:
            return jsonify([]), 200
        query = query.filter_by(budget_id=budget.id)

    if user_id is not None:
        query = query.filter_by(user_id=user_id)

    transactions = query.order_by(models.Transaction.transaction_date.desc()).all()

    if month is not None:
        transactions = [t for t in transactions if t.transaction_date.month == month]

    return jsonify([_serialize(t) for t in transactions]), 200


@bp.route('', methods=['POST'])
@auth.token_required
def create_transaction(current_user):
    data = request.get_json()
    if not data or not data.get('category_id') or not data.get('amount'):
        return jsonify({"detail": "Missing required fields"}), 400

    tx_date = datetime.fromisoformat(data['transaction_date']).date() if data.get('transaction_date') else datetime.now().date()

    # Resolve budget from year derived from date
    budget = models.Budget.query.filter_by(year=tx_date.year).first()
    if not budget:
        return jsonify({"detail": f"No budget found for year {tx_date.year}"}), 404

    user_id = data.get('user_id', current_user.id)

    investment_id = data.get('investment_id')
    loan_id = data.get('loan_id')
    amount = float(data['amount'])

    transaction = models.Transaction(
        budget_id=budget.id,
        category_id=data['category_id'],
        user_id=user_id,
        account_id=data.get('account_id'),
        investment_id=investment_id,
        loan_id=loan_id,
        amount=amount,
        transaction_date=tx_date,
        payment_method=data.get('payment_method', 'Cash'),
        note=data.get('note'),
    )
    db.session.add(transaction)

    # Auto-update linked investment or loan
    if investment_id:
        inv = db.session.get(models.Investment, investment_id)
        if inv:
            inv.amount = float(inv.amount) + amount
    if loan_id:
        loan = db.session.get(models.Loan, loan_id)
        if loan:
            loan.outstanding_amount = max(0.0, float(loan.outstanding_amount) - amount)

    db.session.commit()

    # Reload with relationships
    db.session.refresh(transaction)
    return jsonify(_serialize(transaction)), 201


@bp.route('/<int:transaction_id>', methods=['PUT'])
@auth.token_required
def update_transaction(current_user, transaction_id):
    transaction = models.Transaction.query.get(transaction_id)
    if not transaction:
        return jsonify({"detail": "Transaction not found"}), 404
    if current_user.role != 'admin' and transaction.user_id != current_user.id:
        return jsonify({"detail": "Not authorized to edit this transaction"}), 403

    data = request.get_json()

    old_amount = float(transaction.amount)
    old_investment_id = transaction.investment_id
    old_loan_id = transaction.loan_id

    if 'category_id' in data:
        transaction.category_id = data['category_id']
    if 'user_id' in data and current_user.role == 'admin':
        transaction.user_id = data['user_id']
    if 'amount' in data:
        transaction.amount = data['amount']
    if 'transaction_date' in data:
        transaction.transaction_date = datetime.fromisoformat(data['transaction_date']).date()
    if 'account_id' in data:
        transaction.account_id = data['account_id']
    if 'note' in data:
        transaction.note = data['note']
    if 'investment_id' in data:
        transaction.investment_id = data['investment_id']
    if 'loan_id' in data:
        transaction.loan_id = data['loan_id']

    new_amount = float(transaction.amount)
    new_investment_id = transaction.investment_id
    new_loan_id = transaction.loan_id

    # Reverse old investment/loan effect, apply new
    if old_investment_id:
        inv = db.session.get(models.Investment, old_investment_id)
        if inv:
            inv.amount = float(inv.amount) - old_amount
    if old_loan_id:
        loan = db.session.get(models.Loan, old_loan_id)
        if loan:
            loan.outstanding_amount = float(loan.outstanding_amount) + old_amount

    if new_investment_id:
        inv = db.session.get(models.Investment, new_investment_id)
        if inv:
            inv.amount = float(inv.amount) + new_amount
    if new_loan_id:
        loan = db.session.get(models.Loan, new_loan_id)
        if loan:
            loan.outstanding_amount = max(0.0, float(loan.outstanding_amount) - new_amount)

    db.session.commit()
    db.session.refresh(transaction)
    return jsonify(_serialize(transaction)), 200


@bp.route('/<int:transaction_id>', methods=['DELETE'])
@auth.token_required
def delete_transaction(current_user, transaction_id):
    transaction = models.Transaction.query.get(transaction_id)
    if not transaction:
        return jsonify({"detail": "Transaction not found"}), 404
    if current_user.role != 'admin' and transaction.user_id != current_user.id:
        return jsonify({"detail": "Not authorized to delete this transaction"}), 403

    # Reverse investment/loan effect before deleting
    amount = float(transaction.amount)
    if transaction.investment_id:
        inv = db.session.get(models.Investment, transaction.investment_id)
        if inv:
            inv.amount = float(inv.amount) - amount
    if transaction.loan_id:
        loan = db.session.get(models.Loan, transaction.loan_id)
        if loan:
            loan.outstanding_amount = float(loan.outstanding_amount) + amount

    db.session.delete(transaction)
    db.session.commit()
    return '', 204
