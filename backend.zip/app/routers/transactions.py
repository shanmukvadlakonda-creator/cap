from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models
from datetime import datetime

bp = Blueprint('transactions', __name__, url_prefix='/api/transactions')


@bp.route('/', methods=['GET'])
@auth.token_required
def list_transactions(current_user):
    transactions = models.Transaction.query.all()
    return jsonify([{
        "id": t.id,
        "budget_id": t.budget_id,
        "category_id": t.category_id,
        "user_id": t.user_id,
        "amount": float(t.amount),
        "transaction_date": t.transaction_date.isoformat(),
        "payment_method": t.payment_method,
        "note": t.note,
        "created_at": t.created_at.isoformat() if t.created_at else None,
    } for t in transactions]), 200


@bp.route('/', methods=['POST'])
@auth.token_required
def create_transaction(current_user):
    data = request.get_json()
    if not data or not data.get('budget_id') or not data.get('category_id') or not data.get('amount'):
        return jsonify({"detail": "Missing required fields"}), 400

    transaction = models.Transaction(
        budget_id=data['budget_id'],
        category_id=data['category_id'],
        user_id=current_user.id,
        amount=data['amount'],
        transaction_date=datetime.fromisoformat(data['transaction_date']).date() if data.get('transaction_date') else datetime.now().date(),
        payment_method=data.get('payment_method', 'Cash'),
        note=data.get('note'),
    )
    db.session.add(transaction)
    db.session.commit()

    return jsonify({
        "id": transaction.id,
        "budget_id": transaction.budget_id,
        "category_id": transaction.category_id,
        "user_id": transaction.user_id,
        "amount": float(transaction.amount),
        "transaction_date": transaction.transaction_date.isoformat(),
        "payment_method": transaction.payment_method,
        "note": transaction.note,
        "created_at": transaction.created_at.isoformat() if transaction.created_at else None,
    }), 201