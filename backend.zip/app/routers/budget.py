from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from decimal import Decimal
import calendar

from app.database import get_db
from app import models, schemas
from app.auth import get_current_user

router = APIRouter(prefix="/budget", tags=["budget"])

MONTH_NAMES = [
    "", "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
]


def _calc_group_summaries(
    budget: models.Budget,
    year: int,
    month: int,
    db: Session,
) -> List[schemas.GroupSummary]:
    # Get actuals grouped by category for this month
    from datetime import date
    month_start = date(year, month, 1)
    month_end = date(year, month, calendar.monthrange(year, month)[1])

    actuals = (
        db.query(models.Transaction.category_id, func.sum(models.Transaction.amount).label("total"))
        .filter(
            models.Transaction.budget_id == budget.id,
            models.Transaction.transaction_date >= month_start,
            models.Transaction.transaction_date <= month_end,
        )
        .group_by(models.Transaction.category_id)
        .all()
    )
    actuals_map = {row.category_id: row.total for row in actuals}

    # Get planned amounts for this month
    targets = (
        db.query(models.BudgetTarget)
        .filter(
            models.BudgetTarget.budget_id == budget.id,
            models.BudgetTarget.month == month,
        )
        .all()
    )
    targets_map = {t.category_id: t.planned_amount for t in targets}

    # Calculate total expenses for % calculation
    expense_groups = db.query(models.CategoryGroup).filter(
        models.CategoryGroup.type.in_(["expense", "savings"])
    ).all()
    total_expenses = sum(
        actuals_map.get(cat.id, Decimal("0"))
        for group in expense_groups
        for cat in group.categories
    )

    groups = db.query(models.CategoryGroup).order_by(models.CategoryGroup.sort_order).all()
    result = []

    for group in groups:
        cat_summaries = []
        group_actual = Decimal("0")
        group_planned = Decimal("0")

        for cat in group.categories:
            actual = actuals_map.get(cat.id, Decimal("0"))
            planned = targets_map.get(cat.id, Decimal("0"))
            variance = planned - actual
            group_actual += actual
            group_planned += planned
            cat_summaries.append(schemas.CategorySummary(
                category_id=cat.id,
                category_name=cat.name,
                group_name=group.name,
                group_type=group.type,
                actual=actual,
                planned=planned,
                variance=variance,
            ))

        pct = float(group_actual / total_expenses * 100) if total_expenses > 0 else 0.0
        result.append(schemas.GroupSummary(
            group_id=group.id,
            group_name=group.name,
            group_type=group.type,
            actual=group_actual,
            planned=group_planned,
            percent_of_expenses=round(pct, 2),
            categories=cat_summaries,
        ))

    return result


@router.post("", response_model=schemas.BudgetOut, status_code=201)
def create_budget(
    body: schemas.BudgetCreate,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    if db.query(models.Budget).filter(models.Budget.year == body.year).first():
        raise HTTPException(status_code=400, detail="Budget for this year already exists")

    budget = models.Budget(
        year=body.year,
        beginning_spending_balance=body.beginning_spending_balance,
        beginning_savings_balance=body.beginning_savings_balance,
    )
    db.add(budget)
    db.commit()
    db.refresh(budget)
    return budget


@router.get("/{year}", response_model=schemas.AnnualSummary)
def get_annual_budget(
    year: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    budget = db.query(models.Budget).filter(models.Budget.year == year).first()
    if not budget:
        raise HTTPException(status_code=404, detail="No budget found for this year")

    monthly_list = []
    cumulative_spending = budget.beginning_spending_balance
    cumulative_savings = budget.beginning_savings_balance
    annual_income = Decimal("0")
    annual_expenses = Decimal("0")

    for m in range(1, 13):
        groups = _calc_group_summaries(budget, year, m, db)

        month_income = sum(g.actual for g in groups if g.group_type == "income")
        month_expenses = sum(g.actual for g in groups if g.group_type in ("expense", "savings"))
        month_savings = sum(g.actual for g in groups if g.group_type == "savings")
        net = month_income - month_expenses
        cumulative_spending += net
        cumulative_savings += month_savings

        annual_income += month_income
        annual_expenses += month_expenses

        monthly_list.append(schemas.MonthlySummary(
            month=m,
            month_name=MONTH_NAMES[m],
            total_income=month_income,
            total_expenses=month_expenses,
            net=net,
            savings_deposited=month_savings,
            spending_balance=cumulative_spending,
            savings_balance=cumulative_savings,
            groups=groups,
        ))

    return schemas.AnnualSummary(
        year=year,
        beginning_spending_balance=budget.beginning_spending_balance,
        beginning_savings_balance=budget.beginning_savings_balance,
        total_income=annual_income,
        total_expenses=annual_expenses,
        net=annual_income - annual_expenses,
        monthly=monthly_list,
    )


@router.get("/{year}/{month}", response_model=schemas.MonthlyDailyView)
def get_monthly_daily(
    year: int,
    month: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    if month < 1 or month > 12:
        raise HTTPException(status_code=400, detail="Month must be 1-12")

    budget = db.query(models.Budget).filter(models.Budget.year == year).first()
    if not budget:
        raise HTTPException(status_code=404, detail="No budget found for this year")

    from datetime import date
    days_in_month = calendar.monthrange(year, month)[1]

    # Actuals per day
    daily_actuals = (
        db.query(
            models.Transaction.transaction_date,
            models.Transaction.category_id,
            func.sum(models.Transaction.amount).label("total"),
        )
        .filter(
            models.Transaction.budget_id == budget.id,
            models.Transaction.transaction_date >= date(year, month, 1),
            models.Transaction.transaction_date <= date(year, month, days_in_month),
        )
        .group_by(models.Transaction.transaction_date, models.Transaction.category_id)
        .all()
    )

    # Build daily maps
    from collections import defaultdict
    day_cat_map = defaultdict(lambda: defaultdict(Decimal))
    for row in daily_actuals:
        day_cat_map[row.transaction_date.day][row.category_id] += row.total

    # Get category groups for type classification
    income_cat_ids = set(
        cat.id
        for grp in db.query(models.CategoryGroup).filter(models.CategoryGroup.type == "income").all()
        for cat in grp.categories
    )
    savings_cat_ids = set(
        cat.id
        for grp in db.query(models.CategoryGroup).filter(models.CategoryGroup.type == "savings").all()
        for cat in grp.categories
    )

    # Compute previous months' running balance
    running_spending = budget.beginning_spending_balance
    running_savings = budget.beginning_savings_balance

    # Add previous months' contributions
    for prev_month in range(1, month):
        prev_start = date(year, prev_month, 1)
        prev_end = date(year, prev_month, calendar.monthrange(year, prev_month)[1])
        prev_txs = (
            db.query(models.Transaction.category_id, func.sum(models.Transaction.amount).label("total"))
            .filter(
                models.Transaction.budget_id == budget.id,
                models.Transaction.transaction_date >= prev_start,
                models.Transaction.transaction_date <= prev_end,
            )
            .group_by(models.Transaction.category_id)
            .all()
        )
        prev_income = sum(r.total for r in prev_txs if r.category_id in income_cat_ids)
        prev_expenses = sum(r.total for r in prev_txs if r.category_id not in income_cat_ids)
        prev_savings = sum(r.total for r in prev_txs if r.category_id in savings_cat_ids)
        running_spending += prev_income - prev_expenses
        running_savings += prev_savings

    days_list = []
    for d in range(1, days_in_month + 1):
        cats = day_cat_map[d]
        day_income = sum(v for cid, v in cats.items() if cid in income_cat_ids)
        day_expenses = sum(v for cid, v in cats.items() if cid not in income_cat_ids)
        day_savings = sum(v for cid, v in cats.items() if cid in savings_cat_ids)
        net = day_income - day_expenses
        running_spending += net
        running_savings += day_savings

        days_list.append(schemas.DailySummary(
            date=date(year, month, d),
            total_income=day_income,
            total_expenses=day_expenses,
            net=net,
            spending_balance=running_spending,
            savings_balance=running_savings,
        ))

    groups = _calc_group_summaries(budget, year, month, db)

    return schemas.MonthlyDailyView(
        year=year,
        month=month,
        month_name=MONTH_NAMES[month],
        beginning_spending_balance=budget.beginning_spending_balance,
        beginning_savings_balance=budget.beginning_savings_balance,
        days=days_list,
        groups=groups,
    )


@router.put("/{year}/balances", response_model=schemas.BudgetOut)
def update_balances(
    year: int,
    body: schemas.BudgetCreate,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    budget = db.query(models.Budget).filter(models.Budget.year == year).first()
    if not budget:
        raise HTTPException(status_code=404, detail="Budget not found")
    budget.beginning_spending_balance = body.beginning_spending_balance
    budget.beginning_savings_balance = body.beginning_savings_balance
    db.commit()
    db.refresh(budget)
    return budget
