from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models

bp = Blueprint('budget', __name__, url_prefix='/api/budget')


@bp.route('/', methods=['GET'])
@auth.token_required
def list_budgets(current_user):
    budgets = models.Budget.query.all()
    return jsonify([{
        "id": b.id,
        "year": b.year,
        "beginning_spending_balance": float(b.beginning_spending_balance),
        "beginning_savings_balance": float(b.beginning_savings_balance),
    } for b in budgets]), 200


@bp.route('/', methods=['POST'])
@auth.token_required
def create_budget(current_user):
    data = request.get_json()
    if not data or not data.get('year'):
        return jsonify({"detail": "Missing year"}), 400

    budget = models.Budget(
        year=data['year'],
        beginning_spending_balance=data.get('beginning_spending_balance', 0),
        beginning_savings_balance=data.get('beginning_savings_balance', 0),
    )
    db.session.add(budget)
    db.session.commit()

    return jsonify({
        "id": budget.id,
        "year": budget.year,
        "beginning_spending_balance": float(budget.beginning_spending_balance),
        "beginning_savings_balance": float(budget.beginning_savings_balance),
    }), 201
