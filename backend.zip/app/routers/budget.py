from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models

bp = Blueprint('budget', __name__, url_prefix='/api/budget', strict_slashes=False)

MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
]


def _build_group_summaries(groups, tx_by_cat, target_by_cat):
    """Build group + category summaries for a given month's tx/target dicts."""
    month_income = month_savings = month_expenses = 0
    group_summaries = []

    for group in groups:
        group_actual = group_planned = 0
        cat_summaries = []
        for cat in group.categories:
            actual = tx_by_cat.get(cat.id, 0.0)
            planned = target_by_cat.get(cat.id, 0.0)
            group_actual += actual
            group_planned += planned
            cat_summaries.append({
                'category_id': cat.id,
                'category_name': cat.name,
                'group_name': group.name,
                'group_type': group.type,
                'actual': actual,
                'planned': planned,
                'variance': planned - actual,
            })

        if group.type == 'income':
            month_income += group_actual
        elif group.type == 'savings':
            month_savings += group_actual
        else:
            month_expenses += group_actual

        group_summaries.append({
            'group_id': group.id,
            'group_name': group.name,
            'group_type': group.type,
            'actual': group_actual,
            'planned': group_planned,
            'percent_of_expenses': 0.0,
            'categories': cat_summaries,
        })

    total_outflow = month_expenses + month_savings
    for gs in group_summaries:
        gs['percent_of_expenses'] = round(
            (gs['actual'] / total_outflow) * 100, 2) if total_outflow > 0 else 0.0

    return group_summaries, month_income, month_savings, month_expenses


@bp.route('', methods=['GET'])
@auth.token_required
def list_budgets(current_user):
    budgets = models.Budget.query.order_by(models.Budget.year).all()
    return jsonify([{
        'id': b.id,
        'year': b.year,
        'beginning_spending_balance': float(b.beginning_spending_balance),
        'beginning_savings_balance': float(b.beginning_savings_balance),
    } for b in budgets]), 200


@bp.route('', methods=['POST'])
@auth.token_required
def create_budget(current_user):
    data = request.get_json()
    if not data or not data.get('year'):
        return jsonify({'detail': 'Missing year'}), 400

    if models.Budget.query.filter_by(year=data['year']).first():
        return jsonify({'detail': 'Budget for this year already exists'}), 400

    budget = models.Budget(
        year=data['year'],
        beginning_spending_balance=data.get('beginning_spending_balance', 0),
        beginning_savings_balance=data.get('beginning_savings_balance', 0),
    )
    db.session.add(budget)
    db.session.commit()
    return jsonify({
        'id': budget.id,
        'year': budget.year,
        'beginning_spending_balance': float(budget.beginning_spending_balance),
        'beginning_savings_balance': float(budget.beginning_savings_balance),
    }), 201


@bp.route('/<int:year>', methods=['GET'])
@auth.token_required
def get_annual_budget(current_user, year):
    budget = models.Budget.query.filter_by(year=year).first()
    if not budget:
        return jsonify({'detail': 'No budget found for year'}), 404

    groups = models.CategoryGroup.query.order_by(models.CategoryGroup.sort_order).all()
    transactions = models.Transaction.query.filter_by(budget_id=budget.id).all()
    targets = models.BudgetTarget.query.filter_by(budget_id=budget.id).all()

    # Index targets: (month, category_id) → planned_amount
    target_idx = {}
    for t in targets:
        target_idx[(t.month, t.category_id)] = float(t.planned_amount)

    spending_balance = float(budget.beginning_spending_balance)
    savings_balance = float(budget.beginning_savings_balance)
    total_income = total_expenses = 0.0
    monthly = []

    for month in range(1, 13):
        # Index transactions for this month: category_id → total amount
        tx_by_cat = {}
        for t in transactions:
            if t.transaction_date.month == month:
                tx_by_cat[t.category_id] = tx_by_cat.get(t.category_id, 0.0) + float(t.amount)

        target_by_cat = {cat_id: amt for (m, cat_id), amt in target_idx.items() if m == month}

        group_summaries, m_income, m_savings, m_expenses = _build_group_summaries(
            groups, tx_by_cat, target_by_cat)

        month_net = m_income - m_expenses - m_savings
        spending_balance += month_net
        savings_balance += m_savings
        total_income += m_income
        total_expenses += m_expenses + m_savings

        monthly.append({
            'month': month,
            'month_name': MONTH_NAMES[month - 1],
            'total_income': m_income,
            'total_expenses': m_expenses,
            'net': month_net,
            'savings_deposited': m_savings,
            'spending_balance': spending_balance,
            'savings_balance': savings_balance,
            'groups': group_summaries,
        })

    return jsonify({
        'year': year,
        'beginning_spending_balance': float(budget.beginning_spending_balance),
        'beginning_savings_balance': float(budget.beginning_savings_balance),
        'total_income': total_income,
        'total_expenses': total_expenses,
        'net': total_income - total_expenses,
        'monthly': monthly,
    }), 200


@bp.route('/<int:year>/<int:month>', methods=['GET'])
@auth.token_required
def get_monthly_budget(current_user, year, month):
    if month < 1 or month > 12:
        return jsonify({'detail': 'Invalid month'}), 400

    budget = models.Budget.query.filter_by(year=year).first()
    if not budget:
        return jsonify({'detail': 'No budget found for year'}), 404

    groups = models.CategoryGroup.query.order_by(models.CategoryGroup.sort_order).all()

    # All transactions for this budget
    all_transactions = models.Transaction.query.filter_by(budget_id=budget.id).all()

    # Compute beginning balances for this month (sum of all prior months)
    spending_balance = float(budget.beginning_spending_balance)
    savings_balance = float(budget.beginning_savings_balance)

    for m in range(1, month):
        tx_by_cat = {}
        for t in all_transactions:
            if t.transaction_date.month == m:
                tx_by_cat[t.category_id] = tx_by_cat.get(t.category_id, 0.0) + float(t.amount)

        income = savings = expenses = 0.0
        for group in groups:
            group_total = sum(tx_by_cat.get(cat.id, 0.0) for cat in group.categories)
            if group.type == 'income':
                income += group_total
            elif group.type == 'savings':
                savings += group_total
            else:
                expenses += group_total

        spending_balance += income - expenses - savings
        savings_balance += savings

    # Transactions for this specific month
    month_transactions = [t for t in all_transactions if t.transaction_date.month == month]

    # Targets for this month
    targets = models.BudgetTarget.query.filter_by(budget_id=budget.id, month=month).all()
    target_by_cat = {t.category_id: float(t.planned_amount) for t in targets}

    # Build tx_by_cat for the month
    tx_by_cat = {}
    for t in month_transactions:
        tx_by_cat[t.category_id] = tx_by_cat.get(t.category_id, 0.0) + float(t.amount)

    group_summaries, _, _, _ = _build_group_summaries(groups, tx_by_cat, target_by_cat)

    # Build daily summaries
    import calendar
    days_in_month = calendar.monthrange(year, month)[1]
    from datetime import date

    # Group transactions by day
    tx_by_day = {}
    for t in month_transactions:
        d = t.transaction_date
        if d not in tx_by_day:
            tx_by_day[d] = {'income': 0.0, 'savings': 0.0, 'expenses': 0.0}
        # Find group type for this transaction
        cat = models.Category.query.get(t.category_id)
        if cat:
            group_type = cat.group.type
            if group_type == 'income':
                tx_by_day[d]['income'] += float(t.amount)
            elif group_type == 'savings':
                tx_by_day[d]['savings'] += float(t.amount)
            else:
                tx_by_day[d]['expenses'] += float(t.amount)

    running_spending = spending_balance
    running_savings = savings_balance
    days = []

    for day_num in range(1, days_in_month + 1):
        d = date(year, month, day_num)
        day_data = tx_by_day.get(d, {'income': 0.0, 'savings': 0.0, 'expenses': 0.0})
        day_income = day_data['income']
        day_savings = day_data['savings']
        day_expenses = day_data['expenses']
        day_net = day_income - day_expenses - day_savings
        running_spending += day_net
        running_savings += day_savings

        days.append({
            'date': d.isoformat(),
            'total_income': day_income,
            'total_expenses': day_expenses,
            'net': day_net,
            'spending_balance': running_spending,
            'savings_balance': running_savings,
        })

    return jsonify({
        'year': year,
        'month': month,
        'month_name': MONTH_NAMES[month - 1],
        'beginning_spending_balance': spending_balance,
        'beginning_savings_balance': savings_balance,
        'days': days,
        'groups': group_summaries,
    }), 200
