from flask import Blueprint, jsonify
from app import auth, models

bp = Blueprint('reports', __name__, url_prefix='/api/reports')

MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
]


@bp.route('/category-breakdown/<int:year>/<int:month>', methods=['GET'])
@auth.token_required
def category_breakdown(current_user, year, month):
    """Returns spending by expense group for a given month as a pie/bar chart feed."""
    budget = models.Budget.query.filter_by(year=year).first()
    if not budget:
        return jsonify([]), 200

    transactions = models.Transaction.query.filter_by(budget_id=budget.id).all()
    month_txs = [t for t in transactions if t.transaction_date.month == month]

    # Sum amounts by group (expense only for meaningful breakdown)
    group_totals = {}
    for t in month_txs:
        if not t.category or not t.category.group:
            continue
        group = t.category.group
        if group.type == 'expense':
            key = group.name
            group_totals[key] = group_totals.get(key, 0.0) + float(t.amount)

    total = sum(group_totals.values())
    result = [
        {
            "group_name": name,
            "amount": round(amount, 2),
            "percentage": round((amount / total) * 100, 2) if total > 0 else 0.0,
        }
        for name, amount in sorted(group_totals.items(), key=lambda x: -x[1])
    ]
    return jsonify(result), 200


@bp.route('/monthly-trends/<int:year>', methods=['GET'])
@auth.token_required
def monthly_trends(current_user, year):
    """Returns income, expenses, net for each month of the year."""
    budget = models.Budget.query.filter_by(year=year).first()
    if not budget:
        return jsonify([]), 200

    groups = models.CategoryGroup.query.all()
    transactions = models.Transaction.query.filter_by(budget_id=budget.id).all()

    result = []
    for month in range(1, 13):
        month_txs = [t for t in transactions if t.transaction_date.month == month]

        income = expenses = savings = 0.0
        for t in month_txs:
            if not t.category or not t.category.group:
                continue
            gtype = t.category.group.type
            amt = float(t.amount)
            if gtype == 'income':
                income += amt
            elif gtype == 'savings':
                savings += amt
            else:
                expenses += amt

        result.append({
            "month": month,
            "month_name": MONTH_NAMES[month - 1],
            "income": round(income, 2),
            "expenses": round(expenses + savings, 2),
            "net": round(income - expenses - savings, 2),
        })

    return jsonify(result), 200


@bp.route('/person-spending/<int:year>/<int:month>', methods=['GET'])
@auth.token_required
def person_spending(current_user, year, month):
    """Returns total expense spending per user for a given month."""
    budget = models.Budget.query.filter_by(year=year).first()
    if not budget:
        return jsonify([]), 200

    transactions = models.Transaction.query.filter_by(budget_id=budget.id).all()
    month_txs = [t for t in transactions if t.transaction_date.month == month]

    user_totals = {}
    user_names = {}
    for t in month_txs:
        if not t.category or not t.category.group:
            continue
        if t.category.group.type == 'expense':
            uid = t.user_id
            user_totals[uid] = user_totals.get(uid, 0.0) + float(t.amount)
            if uid not in user_names and t.user:
                user_names[uid] = t.user.display_name

    total = sum(user_totals.values())
    result = [
        {
            "user_id": uid,
            "display_name": user_names.get(uid, f"User {uid}"),
            "total_spent": round(amount, 2),
            "percentage": round((amount / total) * 100, 2) if total > 0 else 0.0,
        }
        for uid, amount in sorted(user_totals.items(), key=lambda x: -x[1])
    ]
    return jsonify(result), 200
