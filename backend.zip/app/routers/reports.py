from flask import Blueprint, request, jsonify
from app import auth, models
from sqlalchemy import func

bp = Blueprint('reports', __name__, url_prefix='/api/reports')


@bp.route('/summary/<int:budget_id>', methods=['GET'])
@auth.token_required
def get_budget_summary(current_user, budget_id):
    budget = models.Budget.query.get(budget_id)
    if not budget:
        return jsonify({"detail": "Budget not found"}), 404

    # Get transactions grouped by category
    transactions = models.Transaction.query.filter(
        models.Transaction.budget_id == budget_id
    ).all()

    summary = {}
    for t in transactions:
        cat_id = t.category_id
        if cat_id not in summary:
            summary[cat_id] = {"total": 0, "count": 0}
        summary[cat_id]["total"] += float(t.amount)
        summary[cat_id]["count"] += 1

    return jsonify({
        "budget_id": budget_id,
        "year": budget.year,
        "summary": summary,
    }), 200