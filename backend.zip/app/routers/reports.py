from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from decimal import Decimal
import calendar
from datetime import date

from app.database import get_db
from app import models, schemas
from app.auth import get_current_user

router = APIRouter(prefix="/reports", tags=["reports"])

MONTH_NAMES = [
    "", "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
]


@router.get("/category-breakdown/{year}/{month}", response_model=List[schemas.CategoryBreakdown])
def category_breakdown(
    year: int,
    month: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    budget = db.query(models.Budget).filter(models.Budget.year == year).first()
    if not budget:
        raise HTTPException(status_code=404, detail="Budget not found")

    month_start = date(year, month, 1)
    month_end = date(year, month, calendar.monthrange(year, month)[1])

    # Group actuals by category group, exclude income
    rows = (
        db.query(
            models.CategoryGroup.name.label("group_name"),
            func.sum(models.Transaction.amount).label("total"),
        )
        .join(models.Category, models.Category.group_id == models.CategoryGroup.id)
        .join(models.Transaction, models.Transaction.category_id == models.Category.id)
        .filter(
            models.Transaction.budget_id == budget.id,
            models.Transaction.transaction_date >= month_start,
            models.Transaction.transaction_date <= month_end,
            models.CategoryGroup.type.in_(["expense", "savings"]),
        )
        .group_by(models.CategoryGroup.name)
        .order_by(func.sum(models.Transaction.amount).desc())
        .all()
    )

    total = sum(r.total for r in rows)
    return [
        schemas.CategoryBreakdown(
            group_name=r.group_name,
            amount=r.total,
            percentage=round(float(r.total / total * 100), 2) if total > 0 else 0.0,
        )
        for r in rows
    ]


@router.get("/monthly-trends/{year}", response_model=List[schemas.MonthlyTrend])
def monthly_trends(
    year: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    budget = db.query(models.Budget).filter(models.Budget.year == year).first()
    if not budget:
        raise HTTPException(status_code=404, detail="Budget not found")

    income_group_ids = [
        g.id for g in db.query(models.CategoryGroup).filter(models.CategoryGroup.type == "income").all()
    ]
    income_cat_ids = set(
        cat.id
        for gid in income_group_ids
        for cat in db.query(models.Category).filter(models.Category.group_id == gid).all()
    )

    result = []
    for m in range(1, 13):
        month_start = date(year, m, 1)
        month_end = date(year, m, calendar.monthrange(year, m)[1])

        rows = (
            db.query(models.Transaction.category_id, func.sum(models.Transaction.amount).label("total"))
            .filter(
                models.Transaction.budget_id == budget.id,
                models.Transaction.transaction_date >= month_start,
                models.Transaction.transaction_date <= month_end,
            )
            .group_by(models.Transaction.category_id)
            .all()
        )

        income = sum(r.total for r in rows if r.category_id in income_cat_ids)
        expenses = sum(r.total for r in rows if r.category_id not in income_cat_ids)

        result.append(schemas.MonthlyTrend(
            month=m,
            month_name=MONTH_NAMES[m],
            income=income,
            expenses=expenses,
            net=income - expenses,
        ))

    return result


@router.get("/person-spending/{year}/{month}", response_model=List[schemas.PersonSpending])
def person_spending(
    year: int,
    month: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    budget = db.query(models.Budget).filter(models.Budget.year == year).first()
    if not budget:
        raise HTTPException(status_code=404, detail="Budget not found")

    month_start = date(year, month, 1)
    month_end = date(year, month, calendar.monthrange(year, month)[1])

    # Exclude income categories
    income_cat_ids = set(
        cat.id
        for grp in db.query(models.CategoryGroup).filter(models.CategoryGroup.type == "income").all()
        for cat in grp.categories
    )

    rows = (
        db.query(
            models.User.id.label("user_id"),
            models.User.display_name,
            func.sum(models.Transaction.amount).label("total"),
        )
        .join(models.Transaction, models.Transaction.user_id == models.User.id)
        .filter(
            models.Transaction.budget_id == budget.id,
            models.Transaction.transaction_date >= month_start,
            models.Transaction.transaction_date <= month_end,
            models.Transaction.category_id.notin_(income_cat_ids),
        )
        .group_by(models.User.id, models.User.display_name)
        .all()
    )

    total = sum(r.total for r in rows)
    return [
        schemas.PersonSpending(
            user_id=r.user_id,
            display_name=r.display_name,
            total_spent=r.total,
            percentage=round(float(r.total / total * 100), 2) if total > 0 else 0.0,
        )
        for r in rows
    ]
