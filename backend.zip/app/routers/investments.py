from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models
from datetime import datetime

bp = Blueprint('investments', __name__, url_prefix='/api/investments')


def _serialize(inv):
    return {
        "id": inv.id,
        "name": inv.name,
        "type": inv.type,
        "account_id": inv.account_id,
        "account_name": inv.account.name if inv.account else None,
        "amount": float(inv.amount),
        "current_value": float(inv.current_value) if inv.current_value is not None else None,
        "gain_loss": (float(inv.current_value) - float(inv.amount)) if inv.current_value is not None else None,
        "start_date": inv.start_date.isoformat(),
        "maturity_date": inv.maturity_date.isoformat() if inv.maturity_date else None,
        "notes": inv.notes,
        "is_active": inv.is_active,
    }


@bp.route('', methods=['GET'])
@auth.token_required
def list_investments(current_user):
    investments = models.Investment.query.filter_by(is_active=True).order_by(
        models.Investment.type, models.Investment.start_date.desc()).all()
    return jsonify([_serialize(i) for i in investments]), 200


@bp.route('', methods=['POST'])
@auth.token_required
def create_investment(current_user):
    data = request.get_json()
    if not data or not data.get('name') or not data.get('type') or not data.get('amount') or not data.get('start_date'):
        return jsonify({"detail": "name, type, amount and start_date are required"}), 400

    inv = models.Investment(
        name=data['name'],
        type=data['type'],
        account_id=data.get('account_id'),
        amount=data['amount'],
        current_value=data.get('current_value'),
        start_date=datetime.fromisoformat(data['start_date']).date(),
        maturity_date=datetime.fromisoformat(data['maturity_date']).date() if data.get('maturity_date') else None,
        notes=data.get('notes'),
    )
    db.session.add(inv)
    db.session.commit()
    db.session.refresh(inv)
    return jsonify(_serialize(inv)), 201


@bp.route('/<int:inv_id>', methods=['PUT'])
@auth.token_required
def update_investment(current_user, inv_id):
    inv = models.Investment.query.get_or_404(inv_id)
    data = request.get_json()
    if 'name' in data:
        inv.name = data['name']
    if 'amount' in data:
        inv.amount = data['amount']
    if 'current_value' in data:
        inv.current_value = data['current_value']
    if 'maturity_date' in data:
        inv.maturity_date = datetime.fromisoformat(data['maturity_date']).date() if data['maturity_date'] else None
    if 'notes' in data:
        inv.notes = data['notes']
    if 'account_id' in data:
        inv.account_id = data['account_id']
    db.session.commit()
    db.session.refresh(inv)
    return jsonify(_serialize(inv)), 200


@bp.route('/<int:inv_id>', methods=['DELETE'])
@auth.token_required
def delete_investment(current_user, inv_id):
    inv = models.Investment.query.get_or_404(inv_id)
    inv.is_active = False
    db.session.commit()
    return '', 204
