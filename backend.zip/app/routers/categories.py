from flask import Blueprint, jsonify
from app import auth, models

bp = Blueprint('categories', __name__, url_prefix='/api/categories', strict_slashes=False)


@bp.route('', methods=['GET'])
@auth.token_required
def get_categories(current_user):
    groups = models.CategoryGroup.query.order_by(models.CategoryGroup.sort_order).all()
    result = []
    for group in groups:
        categories = [{
            "id": c.id,
            "name": c.name,
            "sort_order": c.sort_order,
        } for c in group.categories]
        result.append({
            "id": group.id,
            "name": group.name,
            "type": group.type,
            "sort_order": group.sort_order,
            "categories": categories,
        })
    return jsonify(result), 200
