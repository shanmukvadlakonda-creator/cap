from flask import Blueprint, jsonify
from app import auth, models

bp = Blueprint('users', __name__, url_prefix='/api/users')


@bp.route('', methods=['GET'])
@auth.token_required
def list_users(current_user):
    users = models.User.query.order_by(models.User.display_name).all()
    return jsonify([{
        "id": u.id,
        "username": u.username,
        "display_name": u.display_name,
        "created_at": u.created_at.isoformat() if u.created_at else None,
    } for u in users]), 200


@bp.route('/me', methods=['GET'])
@auth.token_required
def get_me(current_user):
    return jsonify({
        "id": current_user.id,
        "username": current_user.username,
        "display_name": current_user.display_name,
        "created_at": current_user.created_at.isoformat() if current_user.created_at else None,
    }), 200
