from flask import Blueprint, jsonify, request
from app.app import db
from app import auth, models

bp = Blueprint('users', __name__, url_prefix='/api/users')


def _serialize(u):
    return {
        "id": u.id,
        "username": u.username,
        "display_name": u.display_name,
        "role": u.role,
        "created_at": u.created_at.isoformat() if u.created_at else None,
    }


@bp.route('', methods=['GET'])
@auth.token_required
def list_users(current_user):
    users = models.User.query.order_by(models.User.display_name).all()
    return jsonify([_serialize(u) for u in users]), 200


@bp.route('', methods=['POST'])
@auth.token_required
def create_user(current_user):
    if current_user.role != 'admin':
        return jsonify({"detail": "Admin access required"}), 403
    data = request.get_json()
    if not data or not data.get('username') or not data.get('password') or not data.get('display_name'):
        return jsonify({"detail": "username, display_name and password are required"}), 400
    if models.User.query.filter_by(username=data['username']).first():
        return jsonify({"detail": "Username already taken"}), 400
    user = models.User(
        username=data['username'],
        display_name=data['display_name'],
        password_hash=auth.hash_password(data['password']),
        role=data.get('role', 'member'),
    )
    db.session.add(user)
    db.session.commit()
    return jsonify(_serialize(user)), 201


@bp.route('/<int:user_id>/role', methods=['PUT'])
@auth.token_required
def update_role(current_user, user_id):
    if current_user.role != 'admin':
        return jsonify({"detail": "Admin access required"}), 403
    user = models.User.query.get_or_404(user_id)
    data = request.get_json()
    role = data.get('role') if data else None
    if role not in ('admin', 'member', 'viewer'):
        return jsonify({"detail": "Invalid role. Must be admin, member, or viewer"}), 400
    user.role = role
    db.session.commit()
    return jsonify(_serialize(user)), 200


@bp.route('/me', methods=['GET'])
@auth.token_required
def get_me(current_user):
    return jsonify(_serialize(current_user)), 200
