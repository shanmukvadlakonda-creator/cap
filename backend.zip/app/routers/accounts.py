from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models

bp = Blueprint('accounts', __name__, url_prefix='/api/accounts')


def _balance(account):
    txns = account.transactions
    income_txn_sum = sum(
        float(t.amount) for t in txns
        if t.category and t.category.group and t.category.group.type == 'income'
    )
    expense_txn_sum = sum(
        float(t.amount) for t in txns
        if t.category and t.category.group and t.category.group.type in ('expense', 'savings')
    )
    transfers_in = sum(float(t.amount) for t in account.transfers_in)
    transfers_out = sum(float(t.amount) for t in account.transfers_out)

    opening = float(account.opening_balance)
    if account.type == 'credit_card':
        # Outstanding = opening + new charges - payments received (transfers to this CC)
        return opening + expense_txn_sum - transfers_in
    else:
        # Bank/Cash = opening + income - expenses/savings + transfers_in - transfers_out
        return opening + income_txn_sum - expense_txn_sum + transfers_in - transfers_out


def _serialize(account):
    return {
        "id": account.id,
        "name": account.name,
        "type": account.type,
        "opening_balance": float(account.opening_balance),
        "balance": _balance(account),
        "is_active": account.is_active,
        "sort_order": account.sort_order,
    }


@bp.route('', methods=['GET'])
@auth.token_required
def list_accounts(current_user):
    accounts = models.Account.query.filter_by(is_active=True).order_by(
        models.Account.type, models.Account.sort_order).all()
    return jsonify([_serialize(a) for a in accounts]), 200


@bp.route('', methods=['POST'])
@auth.token_required
def create_account(current_user):
    data = request.get_json()
    if not data or not data.get('name') or not data.get('type'):
        return jsonify({"detail": "name and type are required"}), 400
    account = models.Account(
        name=data['name'],
        type=data['type'],
        opening_balance=data.get('opening_balance', 0),
        sort_order=data.get('sort_order', 0),
    )
    db.session.add(account)
    db.session.commit()
    return jsonify(_serialize(account)), 201


@bp.route('/<int:account_id>', methods=['PUT'])
@auth.token_required
def update_account(current_user, account_id):
    account = models.Account.query.get_or_404(account_id)
    data = request.get_json()
    if 'name' in data:
        account.name = data['name']
    if 'opening_balance' in data:
        account.opening_balance = data['opening_balance']
    if 'sort_order' in data:
        account.sort_order = data['sort_order']
    db.session.commit()
    return jsonify(_serialize(account)), 200


@bp.route('/<int:account_id>', methods=['DELETE'])
@auth.token_required
def deactivate_account(current_user, account_id):
    account = models.Account.query.get_or_404(account_id)
    account.is_active = False
    db.session.commit()
    return '', 204
