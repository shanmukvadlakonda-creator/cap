from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from decimal import Decimal
import calendar

from app.database import get_db
from app import models, schemas
from app.auth import get_current_user

router = APIRouter(prefix="/targets", tags=["targets"])


@router.get("/{year}", response_model=List[schemas.TargetOut])
def get_targets(
    year: int,
    month: int = None,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    budget = db.query(models.Budget).filter(models.Budget.year == year).first()
    if not budget:
        raise HTTPException(status_code=404, detail="Budget not found")

    q = db.query(models.BudgetTarget).filter(models.BudgetTarget.budget_id == budget.id)
    if month:
        q = q.filter(models.BudgetTarget.month == month)
    return q.all()


@router.put("/{year}/{month}/{category_id}", response_model=schemas.TargetOut)
def upsert_target(
    year: int,
    month: int,
    category_id: int,
    body: schemas.TargetUpdate,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    if month < 1 or month > 12:
        raise HTTPException(status_code=400, detail="Month must be 1-12")

    budget = db.query(models.Budget).filter(models.Budget.year == year).first()
    if not budget:
        raise HTTPException(status_code=404, detail="Budget not found")

    target = (
        db.query(models.BudgetTarget)
        .filter(
            models.BudgetTarget.budget_id == budget.id,
            models.BudgetTarget.category_id == category_id,
            models.BudgetTarget.month == month,
        )
        .first()
    )

    if target:
        target.planned_amount = body.planned_amount
    else:
        target = models.BudgetTarget(
            budget_id=budget.id,
            category_id=category_id,
            month=month,
            planned_amount=body.planned_amount,
        )
        db.add(target)

    db.commit()
    db.refresh(target)
    return target


@router.post("/{year}/{month}/copy-from-previous", response_model=List[schemas.TargetOut])
def copy_from_previous_month(
    year: int,
    month: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(get_current_user),
):
    """Copy targets from the previous month (or December of previous year) into this month."""
    if month < 1 or month > 12:
        raise HTTPException(status_code=400, detail="Month must be 1-12")

    budget = db.query(models.Budget).filter(models.Budget.year == year).first()
    if not budget:
        raise HTTPException(status_code=404, detail="Budget not found")

    if month == 1:
        prev_year = year - 1
        prev_month = 12
        prev_budget = db.query(models.Budget).filter(models.Budget.year == prev_year).first()
        if not prev_budget:
            raise HTTPException(status_code=404, detail="No previous year budget found")
        source_budget_id = prev_budget.id
    else:
        prev_month = month - 1
        source_budget_id = budget.id

    source_targets = (
        db.query(models.BudgetTarget)
        .filter(
            models.BudgetTarget.budget_id == source_budget_id,
            models.BudgetTarget.month == prev_month,
        )
        .all()
    )

    result = []
    for src in source_targets:
        existing = (
            db.query(models.BudgetTarget)
            .filter(
                models.BudgetTarget.budget_id == budget.id,
                models.BudgetTarget.category_id == src.category_id,
                models.BudgetTarget.month == month,
            )
            .first()
        )
        if existing:
            existing.planned_amount = src.planned_amount
            result.append(existing)
        else:
            new_target = models.BudgetTarget(
                budget_id=budget.id,
                category_id=src.category_id,
                month=month,
                planned_amount=src.planned_amount,
            )
            db.add(new_target)
            result.append(new_target)

    db.commit()
    for t in result:
        db.refresh(t)
    return result
