from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models

bp = Blueprint('targets', __name__, url_prefix='/api/targets', strict_slashes=False)


@bp.route('/<int:year>', methods=['GET'])
@auth.token_required
def get_targets(current_user, year):
    month = request.args.get('month', type=int)

    budget = models.Budget.query.filter_by(year=year).first()
    if not budget:
        return jsonify([]), 200

    query = models.BudgetTarget.query.filter_by(budget_id=budget.id)
    if month is not None:
        query = query.filter_by(month=month)

    targets = query.all()
    return jsonify([{
        "id": t.id,
        "budget_id": t.budget_id,
        "category_id": t.category_id,
        "month": t.month,
        "planned_amount": float(t.planned_amount),
    } for t in targets]), 200


@bp.route('/<int:year>/<int:month>/<int:category_id>', methods=['PUT'])
@auth.token_required
def upsert_target(current_user, year, month, category_id):
    if month < 1 or month > 12:
        return jsonify({"detail": "Invalid month"}), 400

    data = request.get_json()
    if not data or 'planned_amount' not in data:
        return jsonify({"detail": "Missing planned_amount"}), 400

    budget = models.Budget.query.filter_by(year=year).first()
    if not budget:
        return jsonify({"detail": f"No budget found for year {year}"}), 404

    target = models.BudgetTarget.query.filter_by(
        budget_id=budget.id,
        category_id=category_id,
        month=month,
    ).first()

    if target:
        target.planned_amount = data['planned_amount']
    else:
        target = models.BudgetTarget(
            budget_id=budget.id,
            category_id=category_id,
            month=month,
            planned_amount=data['planned_amount'],
        )
        db.session.add(target)

    db.session.commit()
    return jsonify({
        "id": target.id,
        "budget_id": target.budget_id,
        "category_id": target.category_id,
        "month": target.month,
        "planned_amount": float(target.planned_amount),
    }), 200


@bp.route('/<int:year>/<int:month>/copy-from-previous', methods=['POST'])
@auth.token_required
def copy_targets_from_previous(current_user, year, month):
    if month < 1 or month > 12:
        return jsonify({"detail": "Invalid month"}), 400

    budget = models.Budget.query.filter_by(year=year).first()
    if not budget:
        return jsonify({"detail": f"No budget found for year {year}"}), 404

    # Determine previous month/year
    if month == 1:
        prev_month, prev_year = 12, year - 1
        prev_budget = models.Budget.query.filter_by(year=prev_year).first()
        if not prev_budget:
            return jsonify({"detail": "No previous month budget found"}), 404
        prev_budget_id = prev_budget.id
    else:
        prev_month = month - 1
        prev_budget_id = budget.id

    prev_targets = models.BudgetTarget.query.filter_by(
        budget_id=prev_budget_id,
        month=prev_month,
    ).all()

    copied = 0
    for pt in prev_targets:
        existing = models.BudgetTarget.query.filter_by(
            budget_id=budget.id,
            category_id=pt.category_id,
            month=month,
        ).first()
        if not existing:
            db.session.add(models.BudgetTarget(
                budget_id=budget.id,
                category_id=pt.category_id,
                month=month,
                planned_amount=pt.planned_amount,
            ))
            copied += 1

    db.session.commit()
    return jsonify({"copied": copied}), 200
