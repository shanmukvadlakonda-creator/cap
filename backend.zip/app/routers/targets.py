from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models

bp = Blueprint('targets', __name__, url_prefix='/api/targets')


@bp.route('/', methods=['GET'])
@auth.token_required
def list_targets(current_user):
    targets = models.BudgetTarget.query.all()
    return jsonify([{
        "id": t.id,
        "budget_id": t.budget_id,
        "category_id": t.category_id,
        "month": t.month,
        "planned_amount": float(t.planned_amount),
    } for t in targets]), 200


@bp.route('/', methods=['POST'])
@auth.token_required
def create_target(current_user):
    data = request.get_json()
    if not data or not data.get('budget_id') or not data.get('category_id') or not data.get('month'):
        return jsonify({"detail": "Missing required fields"}), 400

    target = models.BudgetTarget(
        budget_id=data['budget_id'],
        category_id=data['category_id'],
        month=data['month'],
        planned_amount=data.get('planned_amount', 0),
    )
    db.session.add(target)
    db.session.commit()

    return jsonify({
        "id": target.id,
        "budget_id": target.budget_id,
        "category_id": target.category_id,
        "month": target.month,
        "planned_amount": float(target.planned_amount),
    }), 201
