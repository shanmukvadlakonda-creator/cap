from flask import Blueprint, request, jsonify
from app.app import db
from app import models, auth

bp = Blueprint('auth', __name__, url_prefix='/api/auth')


@bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({"detail": "Missing username or password"}), 400

    user = models.User.query.filter(models.User.username == data['username']).first()
    if not user or not auth.verify_password(data['password'], user.password_hash):
        return jsonify({"detail": "Invalid credentials"}), 401

    token = auth.create_access_token(data={"sub": str(user.id)})
    return jsonify({
        "access_token": token,
        "token_type": "bearer",
        "user_id": user.id,
        "display_name": user.display_name,
        "role": user.role,
    }), 200


@bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    if not data or not data.get('username') or not data.get('password') or not data.get('display_name'):
        return jsonify({"detail": "Missing required fields"}), 400

    if models.User.query.filter(models.User.username == data['username']).first():
        return jsonify({"detail": "Username already taken"}), 400

    user = models.User(
        username=data['username'],
        display_name=data['display_name'],
        password_hash=auth.hash_password(data['password']),
    )
    db.session.add(user)
    db.session.commit()

    return jsonify({
        "id": user.id,
        "username": user.username,
        "display_name": user.display_name,
    }), 201