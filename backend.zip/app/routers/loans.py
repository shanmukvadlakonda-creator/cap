from datetime import date as date_type
from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models

bp = Blueprint('loans', __name__, url_prefix='/api/loans')


def _serialize(loan):
    return {
        'id': loan.id,
        'name': loan.name,
        'type': loan.type,
        'lender': loan.lender,
        'principal_amount': float(loan.principal_amount),
        'outstanding_amount': float(loan.outstanding_amount),
        'interest_rate': float(loan.interest_rate) if loan.interest_rate is not None else None,
        'emi_amount': float(loan.emi_amount) if loan.emi_amount is not None else None,
        'start_date': loan.start_date.isoformat() if loan.start_date else None,
        'end_date': loan.end_date.isoformat() if loan.end_date else None,
        'account_id': loan.account_id,
        'account_name': loan.account.name if loan.account else None,
        'notes': loan.notes,
        'is_active': loan.is_active,
    }


@bp.route('', methods=['GET'])
@auth.token_required
def list_loans(current_user):
    loans = models.Loan.query.filter_by(is_active=True).order_by(models.Loan.id).all()
    return jsonify([_serialize(l) for l in loans]), 200


@bp.route('', methods=['POST'])
@auth.token_required
def create_loan(current_user):
    data = request.get_json()
    if not data or not data.get('name'):
        return jsonify({'detail': 'name is required'}), 400

    loan = models.Loan(
        name=data['name'],
        type=data.get('type', 'Personal'),
        lender=data.get('lender'),
        principal_amount=data.get('principal_amount', 0),
        outstanding_amount=data.get('outstanding_amount', data.get('principal_amount', 0)),
        interest_rate=data.get('interest_rate'),
        emi_amount=data.get('emi_amount'),
        start_date=date_type.fromisoformat(data['start_date']) if data.get('start_date') else None,
        end_date=date_type.fromisoformat(data['end_date']) if data.get('end_date') else None,
        account_id=data.get('account_id'),
        notes=data.get('notes'),
    )
    db.session.add(loan)
    db.session.commit()
    return jsonify(_serialize(loan)), 201


@bp.route('/<int:loan_id>', methods=['PUT'])
@auth.token_required
def update_loan(current_user, loan_id):
    loan = models.Loan.query.get_or_404(loan_id)
    data = request.get_json() or {}

    if 'name' in data:
        loan.name = data['name']
    if 'type' in data:
        loan.type = data['type']
    if 'lender' in data:
        loan.lender = data['lender']
    if 'principal_amount' in data:
        loan.principal_amount = data['principal_amount']
    if 'outstanding_amount' in data:
        loan.outstanding_amount = data['outstanding_amount']
    if 'interest_rate' in data:
        loan.interest_rate = data['interest_rate']
    if 'emi_amount' in data:
        loan.emi_amount = data['emi_amount']
    if 'start_date' in data:
        loan.start_date = date_type.fromisoformat(data['start_date']) if data['start_date'] else None
    if 'end_date' in data:
        loan.end_date = date_type.fromisoformat(data['end_date']) if data['end_date'] else None
    if 'account_id' in data:
        loan.account_id = data['account_id']
    if 'notes' in data:
        loan.notes = data['notes']

    db.session.commit()
    return jsonify(_serialize(loan)), 200


@bp.route('/<int:loan_id>', methods=['DELETE'])
@auth.token_required
def delete_loan(current_user, loan_id):
    loan = models.Loan.query.get_or_404(loan_id)
    loan.is_active = False
    db.session.commit()
    return '', 204
