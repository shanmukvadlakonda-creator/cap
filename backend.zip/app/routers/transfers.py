from flask import Blueprint, request, jsonify
from app.app import db
from app import auth, models
from datetime import datetime

bp = Blueprint('transfers', __name__, url_prefix='/api/transfers')


def _serialize(t):
    return {
        "id": t.id,
        "from_account_id": t.from_account_id,
        "from_account_name": t.from_account.name if t.from_account else None,
        "to_account_id": t.to_account_id,
        "to_account_name": t.to_account.name if t.to_account else None,
        "to_account_type": t.to_account.type if t.to_account else None,
        "amount": float(t.amount),
        "transfer_date": t.transfer_date.isoformat(),
        "note": t.note,
        "is_cc_payment": t.to_account.type == 'credit_card' if t.to_account else False,
    }


@bp.route('', methods=['GET'])
@auth.token_required
def list_transfers(current_user):
    year = request.args.get('year', type=int)
    month = request.args.get('month', type=int)
    transfers = models.AccountTransfer.query.order_by(
        models.AccountTransfer.transfer_date.desc()).all()
    if year:
        transfers = [t for t in transfers if t.transfer_date.year == year]
    if month:
        transfers = [t for t in transfers if t.transfer_date.month == month]
    return jsonify([_serialize(t) for t in transfers]), 200


@bp.route('', methods=['POST'])
@auth.token_required
def create_transfer(current_user):
    data = request.get_json()
    if not data or not data.get('from_account_id') or not data.get('to_account_id') or not data.get('amount'):
        return jsonify({"detail": "from_account_id, to_account_id, and amount are required"}), 400
    transfer = models.AccountTransfer(
        from_account_id=data['from_account_id'],
        to_account_id=data['to_account_id'],
        amount=data['amount'],
        transfer_date=datetime.fromisoformat(data['transfer_date']).date()
            if data.get('transfer_date') else datetime.now().date(),
        note=data.get('note'),
    )
    db.session.add(transfer)
    db.session.commit()
    db.session.refresh(transfer)
    return jsonify(_serialize(transfer)), 201


@bp.route('/<int:transfer_id>', methods=['DELETE'])
@auth.token_required
def delete_transfer(current_user, transfer_id):
    transfer = models.AccountTransfer.query.get_or_404(transfer_id)
    db.session.delete(transfer)
    db.session.commit()
    return '', 204
