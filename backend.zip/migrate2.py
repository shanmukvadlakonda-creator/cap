from app.app import create_app, db
from sqlalchemy import text

app = create_app()
with app.app_context():
    with db.engine.connect() as conn:
        conn.execute(text(
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR(20) NOT NULL DEFAULT 'member';"
        ))
        conn.commit()
    print("Migration 2 complete: role column added to users.")
    print("Next: UPDATE users SET role='admin' WHERE username='<your_username>';")
