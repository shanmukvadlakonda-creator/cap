#!/usr/bin/env python3
"""
Entry point for the Flask Budget Planner API
Run with: python run.py
"""
from app.app import create_app
import os

if __name__ == '__main__':
    app = create_app()
    port = int(os.getenv('API_PORT', 8080))
    app.run(host='0.0.0.0', port=port, debug=True, use_reloader=False, threaded=True)
