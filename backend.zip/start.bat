@echo off
echo Starting Family Budget Planner API...
echo.
echo Make sure PostgreSQL is running on port 5432
echo API will be available at http://localhost:8080
echo Swagger docs at http://localhost:8080/docs
echo.
cd /d "%~dp0"
call venv\Scripts\activate.bat
uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload
pause
