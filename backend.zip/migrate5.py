from app.app import create_app, db
from sqlalchemy import text

app = create_app()
with app.app_context():
    with db.engine.connect() as conn:
        conn.execute(text(
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS investment_id INTEGER REFERENCES investments(id);"
        ))
        conn.execute(text(
            "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS loan_id INTEGER REFERENCES loans(id);"
        ))
        conn.commit()
    print("Migration 5 complete: investment_id and loan_id added to transactions.")
