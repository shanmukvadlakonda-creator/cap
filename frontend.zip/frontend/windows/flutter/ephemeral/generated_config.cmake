# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\shanmuv\\OneDrive - Capgemini\\Desktop\\Shanmuk\\Personal\\Skills\\Budget App\\frontend" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\flutter"
  "PROJECT_DIR=C:\\Users\\shanmuv\\OneDrive - Capgemini\\Desktop\\Shanmuk\\Personal\\Skills\\Budget App\\frontend"
  "FLUTTER_ROOT=C:\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\shanmuv\\OneDrive - Capgemini\\Desktop\\Shanmuk\\Personal\\Skills\\Budget App\\frontend\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\shanmuv\\OneDrive - Capgemini\\Desktop\\Shanmuk\\Personal\\Skills\\Budget App\\frontend"
  "FLUTTER_TARGET=C:\\Users\\shanmuv\\OneDrive - Capgemini\\Desktop\\Shanmuk\\Personal\\Skills\\Budget App\\frontend\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDEuNg==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ZGI1MGUyMDE2OA==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NDI1Y2ZiNTRkMA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS40"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\shanmuv\\OneDrive - Capgemini\\Desktop\\Shanmuk\\Personal\\Skills\\Budget App\\frontend\\.dart_tool\\package_config.json"
)
