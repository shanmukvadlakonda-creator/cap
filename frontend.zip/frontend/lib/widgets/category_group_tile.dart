import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/budget.dart';

class CategoryGroupTile extends StatelessWidget {
  final GroupSummary group;
  final NumberFormat fmt = NumberFormat('#,##,##0.00', 'en_IN');

  CategoryGroupTile({super.key, required this.group});

  Color get _typeColor {
    switch (group.groupType) {
      case 'income':
        return const Color(0xFF2E7D32);
      case 'savings':
        return const Color(0xFF1565C0);
      default:
        return const Color(0xFFC62828);
    }
  }

  @override
  Widget build(BuildContext context) {
    final overBudget =
        group.groupType != 'income' && group.actual > group.planned && group.planned > 0;

    return ExpansionTile(
      tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        width: 10,
        decoration: BoxDecoration(
          color: _typeColor,
          borderRadius: BorderRadius.circular(4),
        ),
      ),
      title: Text(
        group.groupName,
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
      ),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            '₹${fmt.format(group.actual)}',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: overBudget ? Colors.red[700] : _typeColor,
              fontSize: 14,
            ),
          ),
          if (group.planned > 0)
            Text(
              'of ₹${fmt.format(group.planned)}',
              style: TextStyle(fontSize: 11, color: Colors.grey[500]),
            ),
        ],
      ),
      children: [
        if (group.groupType != 'income' && group.actual > 0)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: LinearProgressIndicator(
              value: group.planned > 0
                  ? (group.actual / group.planned).clamp(0.0, 1.0)
                  : 0,
              backgroundColor: Colors.grey[200],
              color: overBudget ? Colors.red[400] : Colors.green[400],
            ),
          ),
        ...group.categories
            .where((c) => c.actual > 0 || c.planned > 0)
            .map((cat) => _CategoryRow(cat: cat, fmt: fmt))
            .toList(),
      ],
    );
  }
}

class _CategoryRow extends StatelessWidget {
  final CategorySummary cat;
  final NumberFormat fmt;

  const _CategoryRow({required this.cat, required this.fmt});

  @override
  Widget build(BuildContext context) {
    final over = cat.actual > cat.planned && cat.planned > 0;
    return ListTile(
      dense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 32),
      title: Text(cat.categoryName, style: const TextStyle(fontSize: 13)),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            '₹${fmt.format(cat.actual)}',
            style: TextStyle(
              fontSize: 13,
              color: over ? Colors.red[700] : Colors.black87,
              fontWeight: FontWeight.w500,
            ),
          ),
          if (cat.planned > 0)
            Text(
              '/ ₹${fmt.format(cat.planned)}',
              style: TextStyle(fontSize: 11, color: Colors.grey[500]),
            ),
        ],
      ),
    );
  }
}
