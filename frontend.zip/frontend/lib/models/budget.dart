class CategorySummary {
  final int categoryId;
  final String categoryName;
  final String groupName;
  final String groupType;
  final double actual;
  final double planned;
  final double variance;

  CategorySummary({
    required this.categoryId,
    required this.categoryName,
    required this.groupName,
    required this.groupType,
    required this.actual,
    required this.planned,
    required this.variance,
  });

  factory CategorySummary.fromJson(Map<String, dynamic> j) => CategorySummary(
        categoryId: j['category_id'],
        categoryName: j['category_name'],
        groupName: j['group_name'],
        groupType: j['group_type'],
        actual: (j['actual'] as num).toDouble(),
        planned: (j['planned'] as num).toDouble(),
        variance: (j['variance'] as num).toDouble(),
      );
}

class GroupSummary {
  final int groupId;
  final String groupName;
  final String groupType;
  final double actual;
  final double planned;
  final double percentOfExpenses;
  final List<CategorySummary> categories;

  GroupSummary({
    required this.groupId,
    required this.groupName,
    required this.groupType,
    required this.actual,
    required this.planned,
    required this.percentOfExpenses,
    required this.categories,
  });

  factory GroupSummary.fromJson(Map<String, dynamic> j) => GroupSummary(
        groupId: j['group_id'],
        groupName: j['group_name'],
        groupType: j['group_type'],
        actual: (j['actual'] as num).toDouble(),
        planned: (j['planned'] as num).toDouble(),
        percentOfExpenses: (j['percent_of_expenses'] as num).toDouble(),
        categories: (j['categories'] as List)
            .map((c) => CategorySummary.fromJson(c))
            .toList(),
      );
}

class MonthlySummary {
  final int month;
  final String monthName;
  final double totalIncome;
  final double totalExpenses;
  final double net;
  final double savingsDeposited;
  final double spendingBalance;
  final double savingsBalance;
  final List<GroupSummary> groups;

  MonthlySummary({
    required this.month,
    required this.monthName,
    required this.totalIncome,
    required this.totalExpenses,
    required this.net,
    required this.savingsDeposited,
    required this.spendingBalance,
    required this.savingsBalance,
    required this.groups,
  });

  factory MonthlySummary.fromJson(Map<String, dynamic> j) => MonthlySummary(
        month: j['month'],
        monthName: j['month_name'],
        totalIncome: (j['total_income'] as num).toDouble(),
        totalExpenses: (j['total_expenses'] as num).toDouble(),
        net: (j['net'] as num).toDouble(),
        savingsDeposited: (j['savings_deposited'] as num).toDouble(),
        spendingBalance: (j['spending_balance'] as num).toDouble(),
        savingsBalance: (j['savings_balance'] as num).toDouble(),
        groups: (j['groups'] as List)
            .map((g) => GroupSummary.fromJson(g))
            .toList(),
      );
}

class AnnualSummary {
  final int year;
  final double beginningSpendingBalance;
  final double beginningSavingsBalance;
  final double totalIncome;
  final double totalExpenses;
  final double net;
  final List<MonthlySummary> monthly;

  AnnualSummary({
    required this.year,
    required this.beginningSpendingBalance,
    required this.beginningSavingsBalance,
    required this.totalIncome,
    required this.totalExpenses,
    required this.net,
    required this.monthly,
  });

  factory AnnualSummary.fromJson(Map<String, dynamic> j) => AnnualSummary(
        year: j['year'],
        beginningSpendingBalance:
            (j['beginning_spending_balance'] as num).toDouble(),
        beginningSavingsBalance:
            (j['beginning_savings_balance'] as num).toDouble(),
        totalIncome: (j['total_income'] as num).toDouble(),
        totalExpenses: (j['total_expenses'] as num).toDouble(),
        net: (j['net'] as num).toDouble(),
        monthly: (j['monthly'] as List)
            .map((m) => MonthlySummary.fromJson(m))
            .toList(),
      );
}

class DailySummary {
  final DateTime date;
  final double totalIncome;
  final double totalExpenses;
  final double net;
  final double spendingBalance;
  final double savingsBalance;

  DailySummary({
    required this.date,
    required this.totalIncome,
    required this.totalExpenses,
    required this.net,
    required this.spendingBalance,
    required this.savingsBalance,
  });

  factory DailySummary.fromJson(Map<String, dynamic> j) => DailySummary(
        date: DateTime.parse(j['date']),
        totalIncome: (j['total_income'] as num).toDouble(),
        totalExpenses: (j['total_expenses'] as num).toDouble(),
        net: (j['net'] as num).toDouble(),
        spendingBalance: (j['spending_balance'] as num).toDouble(),
        savingsBalance: (j['savings_balance'] as num).toDouble(),
      );
}

class MonthlyDailyView {
  final int year;
  final int month;
  final String monthName;
  final double beginningSpendingBalance;
  final double beginningSavingsBalance;
  final List<DailySummary> days;
  final List<GroupSummary> groups;

  MonthlyDailyView({
    required this.year,
    required this.month,
    required this.monthName,
    required this.beginningSpendingBalance,
    required this.beginningSavingsBalance,
    required this.days,
    required this.groups,
  });

  factory MonthlyDailyView.fromJson(Map<String, dynamic> j) => MonthlyDailyView(
        year: j['year'],
        month: j['month'],
        monthName: j['month_name'],
        beginningSpendingBalance:
            (j['beginning_spending_balance'] as num).toDouble(),
        beginningSavingsBalance:
            (j['beginning_savings_balance'] as num).toDouble(),
        days: (j['days'] as List).map((d) => DailySummary.fromJson(d)).toList(),
        groups: (j['groups'] as List)
            .map((g) => GroupSummary.fromJson(g))
            .toList(),
      );
}

class CategoryBreakdown {
  final String groupName;
  final double amount;
  final double percentage;

  CategoryBreakdown({
    required this.groupName,
    required this.amount,
    required this.percentage,
  });

  factory CategoryBreakdown.fromJson(Map<String, dynamic> j) =>
      CategoryBreakdown(
        groupName: j['group_name'],
        amount: (j['amount'] as num).toDouble(),
        percentage: (j['percentage'] as num).toDouble(),
      );
}

class MonthlyTrend {
  final int month;
  final String monthName;
  final double income;
  final double expenses;
  final double net;

  MonthlyTrend({
    required this.month,
    required this.monthName,
    required this.income,
    required this.expenses,
    required this.net,
  });

  factory MonthlyTrend.fromJson(Map<String, dynamic> j) => MonthlyTrend(
        month: j['month'],
        monthName: j['month_name'],
        income: (j['income'] as num).toDouble(),
        expenses: (j['expenses'] as num).toDouble(),
        net: (j['net'] as num).toDouble(),
      );
}

class PersonSpending {
  final int userId;
  final String displayName;
  final double totalSpent;
  final double percentage;

  PersonSpending({
    required this.userId,
    required this.displayName,
    required this.totalSpent,
    required this.percentage,
  });

  factory PersonSpending.fromJson(Map<String, dynamic> j) => PersonSpending(
        userId: j['user_id'],
        displayName: j['display_name'],
        totalSpent: (j['total_spent'] as num).toDouble(),
        percentage: (j['percentage'] as num).toDouble(),
      );
}
