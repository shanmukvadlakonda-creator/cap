class Investment {
  final int id;
  final String name;
  final String type;
  final int? accountId;
  final String? accountName;
  final double amount;
  final double? currentValue;
  final double? gainLoss;
  final DateTime startDate;
  final DateTime? maturityDate;
  final String? notes;
  final bool isActive;

  Investment({
    required this.id,
    required this.name,
    required this.type,
    this.accountId,
    this.accountName,
    required this.amount,
    this.currentValue,
    this.gainLoss,
    required this.startDate,
    this.maturityDate,
    this.notes,
    this.isActive = true,
  });

  factory Investment.fromJson(Map<String, dynamic> j) => Investment(
        id: j['id'],
        name: j['name'],
        type: j['type'],
        accountId: j['account_id'],
        accountName: j['account_name'],
        amount: (j['amount'] as num).toDouble(),
        currentValue: j['current_value'] != null ? (j['current_value'] as num).toDouble() : null,
        gainLoss: j['gain_loss'] != null ? (j['gain_loss'] as num).toDouble() : null,
        startDate: DateTime.parse(j['start_date']),
        maturityDate: j['maturity_date'] != null ? DateTime.parse(j['maturity_date']) : null,
        notes: j['notes'],
        isActive: j['is_active'] ?? true,
      );
}
