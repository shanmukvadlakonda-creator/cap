class Account {
  final int id;
  final String name;
  final String type; // bank | credit_card | cash
  final double openingBalance;
  final double balance; // available balance (for CC: available credit = limit - outstanding)
  final bool isActive;
  final int sortOrder;
  final double? creditLimit;   // CC only
  final double? outstanding;   // CC only

  Account({
    required this.id,
    required this.name,
    required this.type,
    required this.openingBalance,
    required this.balance,
    required this.isActive,
    required this.sortOrder,
    this.creditLimit,
    this.outstanding,
  });

  factory Account.fromJson(Map<String, dynamic> j) => Account(
        id: j['id'],
        name: j['name'],
        type: j['type'],
        openingBalance: (j['opening_balance'] as num).toDouble(),
        balance: (j['balance'] as num).toDouble(),
        isActive: j['is_active'],
        sortOrder: j['sort_order'] ?? 0,
        creditLimit: j['credit_limit'] != null ? (j['credit_limit'] as num).toDouble() : null,
        outstanding: j['outstanding'] != null ? (j['outstanding'] as num).toDouble() : null,
      );
}
