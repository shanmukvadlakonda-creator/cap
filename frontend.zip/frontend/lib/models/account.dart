class Account {
  final int id;
  final String name;
  final String type; // bank | credit_card | cash
  final double openingBalance;
  final double balance;
  final bool isActive;
  final int sortOrder;

  Account({
    required this.id,
    required this.name,
    required this.type,
    required this.openingBalance,
    required this.balance,
    required this.isActive,
    required this.sortOrder,
  });

  factory Account.fromJson(Map<String, dynamic> j) => Account(
        id: j['id'],
        name: j['name'],
        type: j['type'],
        openingBalance: (j['opening_balance'] as num).toDouble(),
        balance: (j['balance'] as num).toDouble(),
        isActive: j['is_active'],
        sortOrder: j['sort_order'] ?? 0,
      );
}
