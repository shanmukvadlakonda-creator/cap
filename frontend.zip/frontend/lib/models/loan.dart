class Loan {
  final int id;
  final String name;
  final String type;
  final String? lender;
  final double principalAmount;
  final double outstandingAmount;
  final double? interestRate;
  final double? emiAmount;
  final DateTime? startDate;
  final DateTime? endDate;
  final int? accountId;
  final String? accountName;
  final String? notes;
  final bool isActive;

  Loan({
    required this.id,
    required this.name,
    required this.type,
    this.lender,
    required this.principalAmount,
    required this.outstandingAmount,
    this.interestRate,
    this.emiAmount,
    this.startDate,
    this.endDate,
    this.accountId,
    this.accountName,
    this.notes,
    required this.isActive,
  });

  factory Loan.fromJson(Map<String, dynamic> j) => Loan(
        id: j['id'],
        name: j['name'],
        type: j['type'] ?? 'Personal',
        lender: j['lender'],
        principalAmount: (j['principal_amount'] as num).toDouble(),
        outstandingAmount: (j['outstanding_amount'] as num).toDouble(),
        interestRate: j['interest_rate'] != null
            ? (j['interest_rate'] as num).toDouble()
            : null,
        emiAmount:
            j['emi_amount'] != null ? (j['emi_amount'] as num).toDouble() : null,
        startDate:
            j['start_date'] != null ? DateTime.parse(j['start_date']) : null,
        endDate: j['end_date'] != null ? DateTime.parse(j['end_date']) : null,
        accountId: j['account_id'],
        accountName: j['account_name'],
        notes: j['notes'],
        isActive: j['is_active'] ?? true,
      );
}
