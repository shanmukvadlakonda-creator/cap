class User {
  final int id;
  final String username;
  final String displayName;

  User({required this.id, required this.username, required this.displayName});

  factory User.fromJson(Map<String, dynamic> j) => User(
        id: j['id'],
        username: j['username'],
        displayName: j['display_name'],
      );
}
