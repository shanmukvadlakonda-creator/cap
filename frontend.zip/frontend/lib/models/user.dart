class User {
  final int id;
  final String username;
  final String displayName;
  final String role;

  User({required this.id, required this.username, required this.displayName, this.role = 'member'});

  factory User.fromJson(Map<String, dynamic> j) => User(
        id: j['id'],
        username: j['username'],
        displayName: j['display_name'],
        role: j['role'] ?? 'member',
      );
}
