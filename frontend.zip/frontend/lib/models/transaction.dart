class Transaction {
  final int id;
  final int budgetId;
  final int categoryId;
  final String categoryName;
  final String categoryGroup;
  final int userId;
  final String userDisplayName;
  final double amount;
  final DateTime transactionDate;
  final String paymentMethod;
  final String? note;

  Transaction({
    required this.id,
    required this.budgetId,
    required this.categoryId,
    required this.categoryName,
    required this.categoryGroup,
    required this.userId,
    required this.userDisplayName,
    required this.amount,
    required this.transactionDate,
    required this.paymentMethod,
    this.note,
  });

  factory Transaction.fromJson(Map<String, dynamic> j) => Transaction(
        id: j['id'],
        budgetId: j['budget_id'],
        categoryId: j['category_id'],
        categoryName: j['category_name'],
        categoryGroup: j['category_group'],
        userId: j['user_id'],
        userDisplayName: j['user_display_name'],
        amount: (j['amount'] as num).toDouble(),
        transactionDate: DateTime.parse(j['transaction_date']),
        paymentMethod: j['payment_method'],
        note: j['note'],
      );
}
