class Transaction {
  final int id;
  final int budgetId;
  final int categoryId;
  final String categoryName;
  final String categoryGroup;
  final int userId;
  final String userDisplayName;
  final double amount;
  final DateTime transactionDate;
  final String paymentMethod;
  final int? accountId;
  final String? accountName;
  final int? investmentId;
  final String? investmentName;
  final int? loanId;
  final String? loanName;
  final String? note;

  Transaction({
    required this.id,
    required this.budgetId,
    required this.categoryId,
    required this.categoryName,
    required this.categoryGroup,
    required this.userId,
    required this.userDisplayName,
    required this.amount,
    required this.transactionDate,
    required this.paymentMethod,
    this.accountId,
    this.accountName,
    this.investmentId,
    this.investmentName,
    this.loanId,
    this.loanName,
    this.note,
  });

  factory Transaction.fromJson(Map<String, dynamic> j) => Transaction(
        id: j['id'],
        budgetId: j['budget_id'],
        categoryId: j['category_id'],
        categoryName: j['category_name'],
        categoryGroup: j['category_group'],
        userId: j['user_id'],
        userDisplayName: j['user_display_name'],
        amount: (j['amount'] as num).toDouble(),
        transactionDate: DateTime.parse(j['transaction_date']),
        paymentMethod: j['payment_method'] ?? '',
        accountId: j['account_id'],
        accountName: j['account_name'],
        investmentId: j['investment_id'],
        investmentName: j['investment_name'],
        loanId: j['loan_id'],
        loanName: j['loan_name'],
        note: j['note'],
      );
}
