class AccountTransfer {
  final int id;
  final int fromAccountId;
  final String fromAccountName;
  final int toAccountId;
  final String toAccountName;
  final String toAccountType;
  final double amount;
  final DateTime transferDate;
  final String? note;
  final bool isCcPayment;

  AccountTransfer({
    required this.id,
    required this.fromAccountId,
    required this.fromAccountName,
    required this.toAccountId,
    required this.toAccountName,
    required this.toAccountType,
    required this.amount,
    required this.transferDate,
    this.note,
    required this.isCcPayment,
  });

  factory AccountTransfer.fromJson(Map<String, dynamic> j) => AccountTransfer(
        id: j['id'],
        fromAccountId: j['from_account_id'],
        fromAccountName: j['from_account_name'] ?? '',
        toAccountId: j['to_account_id'],
        toAccountName: j['to_account_name'] ?? '',
        toAccountType: j['to_account_type'] ?? 'bank',
        amount: (j['amount'] as num).toDouble(),
        transferDate: DateTime.parse(j['transfer_date']),
        note: j['note'],
        isCcPayment: j['is_cc_payment'] ?? false,
      );
}
