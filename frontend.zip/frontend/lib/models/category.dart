class Category {
  final int id;
  final String name;
  final int sortOrder;

  Category({required this.id, required this.name, required this.sortOrder});

  factory Category.fromJson(Map<String, dynamic> j) => Category(
        id: j['id'],
        name: j['name'],
        sortOrder: j['sort_order'],
      );
}

class CategoryGroup {
  final int id;
  final String name;
  final String type; // income | expense | savings
  final int sortOrder;
  final List<Category> categories;

  CategoryGroup({
    required this.id,
    required this.name,
    required this.type,
    required this.sortOrder,
    required this.categories,
  });

  factory CategoryGroup.fromJson(Map<String, dynamic> j) => CategoryGroup(
        id: j['id'],
        name: j['name'],
        type: j['type'],
        sortOrder: j['sort_order'],
        categories: (j['categories'] as List)
            .map((c) => Category.fromJson(c))
            .toList(),
      );
}
