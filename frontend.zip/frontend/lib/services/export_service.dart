import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'api_service.dart';

class ExportService {
  static String _cell(dynamic v) {
    final s = '$v'.replaceAll('"', '""');
    return '"$s"';
  }

  static String _row(List<dynamic> cols) => cols.map(_cell).join(',');

  static Future<String> _save(String csv, String filename) async {
    final dir = await getDownloadsDirectory();
    if (dir == null) throw Exception('Could not locate Downloads folder');
    final path = '${dir.path}/$filename';
    await File(path).writeAsString(csv);
    return path;
  }

  /// Monthly Detail: planned vs actual per group/category for a given month.
  /// Uses getMonthlyView which returns GroupSummary with categories.
  static Future<String> exportMonthlyDetail(int year, int month) async {
    final view = await ApiService.getMonthlyView(year, month);
    final buf = StringBuffer();
    buf.writeln(_row(['Budget Export - Monthly Detail - ${view.monthName} $year']));
    buf.writeln(_row(['Group', 'Category', 'Planned (Rs)', 'Actual (Rs)', 'Variance (Rs)', 'Status']));
    for (final g in view.groups) {
      for (final c in g.categories) {
        final status = c.variance >= 0 ? 'On Budget' : 'Over Budget';
        buf.writeln(_row([
          g.groupName, c.categoryName,
          c.planned.toStringAsFixed(2), c.actual.toStringAsFixed(2),
          c.variance.toStringAsFixed(2), status,
        ]));
      }
      final gVariance = g.planned - g.actual;
      buf.writeln(_row([
        g.groupName, 'TOTAL',
        g.planned.toStringAsFixed(2), g.actual.toStringAsFixed(2),
        gVariance.toStringAsFixed(2), '',
      ]));
    }
    final monthStr = month.toString().padLeft(2, '0');
    return _save(buf.toString(), 'budget_monthly_${year}_$monthStr.csv');
  }

  /// Annual Summary: income, expenses, net per month for the full year.
  static Future<String> exportAnnualSummary(int year) async {
    final trends = await ApiService.getMonthlyTrends(year);
    final buf = StringBuffer();
    buf.writeln(_row(['Budget Export - Annual Summary - $year']));
    buf.writeln(_row(['Month', 'Income (Rs)', 'Expenses (Rs)', 'Net (Rs)']));
    for (final t in trends) {
      buf.writeln(_row([
        t.monthName,
        t.income.toStringAsFixed(2),
        t.expenses.toStringAsFixed(2),
        t.net.toStringAsFixed(2),
      ]));
    }
    return _save(buf.toString(), 'budget_annual_$year.csv');
  }

  /// All Transactions: raw list filtered by year and optionally month.
  static Future<String> exportTransactions(int year, int? month) async {
    final txs = await ApiService.getTransactions(year: year, month: month);
    final buf = StringBuffer();
    final label = month != null ? 'Month $month/$year' : 'Year $year';
    buf.writeln(_row(['Budget Export - Transactions - $label']));
    buf.writeln(_row(['Date', 'Category', 'Group', 'User', 'Amount (Rs)', 'Payment Method', 'Note']));
    for (final t in txs) {
      buf.writeln(_row([
        t.transactionDate.toIso8601String().split('T').first,
        t.categoryName, t.categoryGroup, t.userDisplayName,
        t.amount.toStringAsFixed(2), t.paymentMethod, t.note ?? '',
      ]));
    }
    final monthStr = month != null ? '_${month.toString().padLeft(2, '0')}' : '';
    return _save(buf.toString(), 'budget_transactions_$year$monthStr.csv');
  }

  /// By Category: all transactions in a year for one specific category.
  static Future<String> exportByCategory(int year, String categoryName) async {
    final txs = await ApiService.getTransactions(year: year);
    final filtered = txs.where((t) => t.categoryName == categoryName).toList();
    final buf = StringBuffer();
    buf.writeln(_row(['Budget Export - Category: $categoryName - $year']));
    buf.writeln(_row(['Date', 'Category', 'Group', 'User', 'Amount (Rs)', 'Payment Method', 'Note']));
    for (final t in filtered) {
      buf.writeln(_row([
        t.transactionDate.toIso8601String().split('T').first,
        t.categoryName, t.categoryGroup, t.userDisplayName,
        t.amount.toStringAsFixed(2), t.paymentMethod, t.note ?? '',
      ]));
    }
    final safeName = categoryName.toLowerCase().replaceAll(' ', '_');
    return _save(buf.toString(), 'budget_category_${safeName}_$year.csv');
  }
}
