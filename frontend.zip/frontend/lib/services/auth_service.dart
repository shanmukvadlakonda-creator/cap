import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';

class AuthService {
  static String? _token;
  static int? _userId;
  static String? _displayName;
  static String? _role;

  static String? get token => _token;
  static int? get userId => _userId;
  static String? get displayName => _displayName;
  static String? get role => _role;
  static bool get isLoggedIn => _token != null;
  static bool get isAdmin => _role == 'admin';

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('token');
    _userId = prefs.getInt('user_id');
    _displayName = prefs.getString('display_name');
    _role = prefs.getString('role');
  }

  static Future<void> login(String username, String password) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );
    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      _token = data['access_token'];
      _userId = data['user_id'];
      _displayName = data['display_name'];
      _role = data['role'] ?? 'member';
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('token', _token!);
      await prefs.setInt('user_id', _userId!);
      await prefs.setString('display_name', _displayName!);
      await prefs.setString('role', _role!);
    } else {
      final msg = jsonDecode(res.body)['detail'] ?? 'Login failed';
      throw Exception(msg);
    }
  }

  static Future<void> logout() async {
    _token = null;
    _userId = null;
    _displayName = null;
    _role = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
