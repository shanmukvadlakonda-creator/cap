import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../services/auth_service.dart';
import '../models/category.dart';
import '../models/user.dart';
import '../models/transaction.dart';
import '../models/budget.dart';

class ApiService {
  static Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${AuthService.token}',
      };

  static Future<T> _get<T>(String path, T Function(dynamic) parse) async {
    final res = await http.get(
      Uri.parse('${ApiConfig.baseUrl}$path'),
      headers: _headers,
    );
    if (res.statusCode == 200) return parse(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Request failed');
  }

  // ─── Categories ──────────────────────────────────────────────────────────

  static Future<List<CategoryGroup>> getCategories() => _get(
        '/categories',
        (d) => (d as List).map((g) => CategoryGroup.fromJson(g)).toList(),
      );

  // ─── Users ───────────────────────────────────────────────────────────────

  static Future<List<User>> getUsers() => _get(
        '/users',
        (d) => (d as List).map((u) => User.fromJson(u)).toList(),
      );

  // ─── Budget ──────────────────────────────────────────────────────────────

  static Future<AnnualSummary> getAnnualBudget(int year) => _get(
        '/budget/$year',
        (d) => AnnualSummary.fromJson(d),
      );

  static Future<MonthlyDailyView> getMonthlyView(int year, int month) => _get(
        '/budget/$year/$month',
        (d) => MonthlyDailyView.fromJson(d),
      );

  static Future<void> createBudget(
      int year, double spendingBalance, double savingsBalance) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/budget'),
      headers: _headers,
      body: jsonEncode({
        'year': year,
        'beginning_spending_balance': spendingBalance,
        'beginning_savings_balance': savingsBalance,
      }),
    );
    if (res.statusCode != 201) {
      throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to create budget');
    }
  }

  // ─── Transactions ─────────────────────────────────────────────────────────

  static Future<List<Transaction>> getTransactions({
    int? year,
    int? month,
  }) async {
    String path = '/transactions?';
    if (year != null) path += 'year=$year&';
    if (month != null) path += 'month=$month&';
    return _get(path, (d) => (d as List).map((t) => Transaction.fromJson(t)).toList());
  }

  static Future<Transaction> addTransaction({
    required int categoryId,
    required int userId,
    required double amount,
    required DateTime date,
    required String paymentMethod,
    String? note,
  }) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/transactions'),
      headers: _headers,
      body: jsonEncode({
        'category_id': categoryId,
        'user_id': userId,
        'amount': amount,
        'transaction_date':
            '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}',
        'payment_method': paymentMethod,
        'note': note,
      }),
    );
    if (res.statusCode == 201) return Transaction.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to add transaction');
  }

  static Future<void> deleteTransaction(int id) async {
    final res = await http.delete(
      Uri.parse('${ApiConfig.baseUrl}/transactions/$id'),
      headers: _headers,
    );
    if (res.statusCode != 204) {
      throw Exception('Failed to delete transaction');
    }
  }

  // ─── Targets ──────────────────────────────────────────────────────────────

  static Future<List<Map<String, dynamic>>> getTargets(int year, int month) async {
    final res = await http.get(
      Uri.parse('${ApiConfig.baseUrl}/targets/$year?month=$month'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
    }
    throw Exception('Failed to load targets');
  }

  static Future<void> upsertTarget(
      int year, int month, int categoryId, double amount) async {
    final res = await http.put(
      Uri.parse('${ApiConfig.baseUrl}/targets/$year/$month/$categoryId'),
      headers: _headers,
      body: jsonEncode({'planned_amount': amount}),
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to update target');
    }
  }

  static Future<void> copyTargetsFromPrevious(int year, int month) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/targets/$year/$month/copy-from-previous'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to copy targets');
    }
  }

  // ─── Reports ──────────────────────────────────────────────────────────────

  static Future<List<CategoryBreakdown>> getCategoryBreakdown(
          int year, int month) =>
      _get(
        '/reports/category-breakdown/$year/$month',
        (d) => (d as List).map((e) => CategoryBreakdown.fromJson(e)).toList(),
      );

  static Future<List<MonthlyTrend>> getMonthlyTrends(int year) => _get(
        '/reports/monthly-trends/$year',
        (d) => (d as List).map((e) => MonthlyTrend.fromJson(e)).toList(),
      );

  static Future<List<PersonSpending>> getPersonSpending(
          int year, int month) =>
      _get(
        '/reports/person-spending/$year/$month',
        (d) => (d as List).map((e) => PersonSpending.fromJson(e)).toList(),
      );
}
