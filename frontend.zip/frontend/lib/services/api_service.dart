import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import '../services/auth_service.dart';
import '../models/category.dart';
import '../models/user.dart';
import '../models/transaction.dart';
import '../models/budget.dart';
import '../models/account.dart';
import '../models/account_transfer.dart';
import '../models/investment.dart';
import '../models/loan.dart';

class ApiService {
  static Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${AuthService.token}',
      };

  static Future<T> _get<T>(String path, T Function(dynamic) parse) async {
    final res = await http.get(
      Uri.parse('${ApiConfig.baseUrl}$path'),
      headers: _headers,
    );
    if (res.statusCode == 200) return parse(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Request failed');
  }

  // ─── Categories ──────────────────────────────────────────────────────────

  static Future<List<CategoryGroup>> getCategories() => _get(
        '/categories',
        (d) => (d as List).map((g) => CategoryGroup.fromJson(g)).toList(),
      );

  // ─── Users ───────────────────────────────────────────────────────────────

  static Future<List<User>> getUsers() => _get(
        '/users',
        (d) => (d as List).map((u) => User.fromJson(u)).toList(),
      );

  // ─── Budget ──────────────────────────────────────────────────────────────

  static Future<AnnualSummary> getAnnualBudget(int year) => _get(
        '/budget/$year',
        (d) => AnnualSummary.fromJson(d),
      );

  static Future<MonthlyDailyView> getMonthlyView(int year, int month) => _get(
        '/budget/$year/$month',
        (d) => MonthlyDailyView.fromJson(d),
      );

  static Future<void> updateBudget(int year,
      {double? spendingBalance, double? savingsBalance}) async {
    final body = <String, dynamic>{};
    if (spendingBalance != null) body['beginning_spending_balance'] = spendingBalance;
    if (savingsBalance != null) body['beginning_savings_balance'] = savingsBalance;
    final res = await http.put(
      Uri.parse('${ApiConfig.baseUrl}/budget/$year'),
      headers: _headers,
      body: jsonEncode(body),
    );
    if (res.statusCode != 200) {
      throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to update budget');
    }
  }

  static Future<void> createBudget(
      int year, double spendingBalance, double savingsBalance) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/budget'),
      headers: _headers,
      body: jsonEncode({
        'year': year,
        'beginning_spending_balance': spendingBalance,
        'beginning_savings_balance': savingsBalance,
      }),
    );
    if (res.statusCode != 201) {
      throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to create budget');
    }
  }

  // ─── Transactions ─────────────────────────────────────────────────────────

  static Future<List<Transaction>> getTransactions({
    int? year,
    int? month,
    int? userId,
  }) async {
    String path = '/transactions?';
    if (year != null) path += 'year=$year&';
    if (month != null) path += 'month=$month&';
    if (userId != null) path += 'user_id=$userId&';
    return _get(path, (d) => (d as List).map((t) => Transaction.fromJson(t)).toList());
  }

  static Future<Transaction> addTransaction({
    required int categoryId,
    required int userId,
    required double amount,
    required DateTime date,
    int? accountId,
    String? note,
  }) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/transactions'),
      headers: _headers,
      body: jsonEncode({
        'category_id': categoryId,
        'user_id': userId,
        'amount': amount,
        'transaction_date':
            '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}',
        if (accountId != null) 'account_id': accountId,
        'note': note,
      }),
    );
    if (res.statusCode == 201) return Transaction.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to add transaction');
  }

  static Future<Transaction> updateTransaction(
    int id, {
    int? categoryId,
    int? userId,
    double? amount,
    DateTime? date,
    int? accountId,
    String? note,
  }) async {
    final body = <String, dynamic>{};
    if (categoryId != null) body['category_id'] = categoryId;
    if (userId != null) body['user_id'] = userId;
    if (amount != null) body['amount'] = amount;
    if (date != null) {
      body['transaction_date'] =
          '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
    }
    if (accountId != null) body['account_id'] = accountId;
    body['note'] = note;
    final res = await http.put(
      Uri.parse('${ApiConfig.baseUrl}/transactions/$id'),
      headers: _headers,
      body: jsonEncode(body),
    );
    if (res.statusCode == 200) return Transaction.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to update transaction');
  }

  static Future<void> deleteTransaction(int id) async {
    final res = await http.delete(
      Uri.parse('${ApiConfig.baseUrl}/transactions/$id'),
      headers: _headers,
    );
    if (res.statusCode != 204) {
      throw Exception('Failed to delete transaction');
    }
  }

  // ─── Targets ──────────────────────────────────────────────────────────────

  static Future<List<Map<String, dynamic>>> getTargets(int year, int month) async {
    final res = await http.get(
      Uri.parse('${ApiConfig.baseUrl}/targets/$year?month=$month'),
      headers: _headers,
    );
    if (res.statusCode == 200) {
      return (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
    }
    throw Exception('Failed to load targets');
  }

  static Future<void> upsertTarget(
      int year, int month, int categoryId, double amount) async {
    final res = await http.put(
      Uri.parse('${ApiConfig.baseUrl}/targets/$year/$month/$categoryId'),
      headers: _headers,
      body: jsonEncode({'planned_amount': amount}),
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to update target');
    }
  }

  static Future<void> copyTargetsFromPrevious(int year, int month) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/targets/$year/$month/copy-from-previous'),
      headers: _headers,
    );
    if (res.statusCode != 200) {
      throw Exception('Failed to copy targets');
    }
  }

  // ─── Accounts ─────────────────────────────────────────────────────────────

  static Future<List<Account>> getAccounts() => _get(
        '/accounts',
        (d) => (d as List).map((a) => Account.fromJson(a)).toList(),
      );

  static Future<Account> createAccount({
    required String name,
    required String type,
    required double openingBalance,
    int sortOrder = 0,
  }) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/accounts'),
      headers: _headers,
      body: jsonEncode({
        'name': name,
        'type': type,
        'opening_balance': openingBalance,
        'sort_order': sortOrder,
      }),
    );
    if (res.statusCode == 201) return Account.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to create account');
  }

  static Future<void> updateAccount(int id,
      {String? name, double? openingBalance, int? sortOrder}) async {
    final body = <String, dynamic>{};
    if (name != null) body['name'] = name;
    if (openingBalance != null) body['opening_balance'] = openingBalance;
    if (sortOrder != null) body['sort_order'] = sortOrder;
    final res = await http.put(
      Uri.parse('${ApiConfig.baseUrl}/accounts/$id'),
      headers: _headers,
      body: jsonEncode(body),
    );
    if (res.statusCode != 200) {
      throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to update account');
    }
  }

  static Future<void> deleteAccount(int id) async {
    final res = await http.delete(
      Uri.parse('${ApiConfig.baseUrl}/accounts/$id'),
      headers: _headers,
    );
    if (res.statusCode != 204) {
      throw Exception('Failed to delete account');
    }
  }

  // ─── Transfers ─────────────────────────────────────────────────────────────

  static Future<List<AccountTransfer>> getTransfers({int? year, int? month}) async {
    String path = '/transfers?';
    if (year != null) path += 'year=$year&';
    if (month != null) path += 'month=$month&';
    return _get(path, (d) => (d as List).map((t) => AccountTransfer.fromJson(t)).toList());
  }

  static Future<AccountTransfer> createTransfer({
    required int fromAccountId,
    required int toAccountId,
    required double amount,
    required DateTime date,
    String? note,
  }) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/transfers'),
      headers: _headers,
      body: jsonEncode({
        'from_account_id': fromAccountId,
        'to_account_id': toAccountId,
        'amount': amount,
        'transfer_date':
            '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}',
        if (note != null) 'note': note,
      }),
    );
    if (res.statusCode == 201) return AccountTransfer.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to create transfer');
  }

  static Future<void> deleteTransfer(int id) async {
    final res = await http.delete(
      Uri.parse('${ApiConfig.baseUrl}/transfers/$id'),
      headers: _headers,
    );
    if (res.statusCode != 204) {
      throw Exception('Failed to delete transfer');
    }
  }

  // ─── Reports ──────────────────────────────────────────────────────────────

  static Future<List<CategoryBreakdown>> getCategoryBreakdown(
          int year, int month) =>
      _get(
        '/reports/category-breakdown/$year/$month',
        (d) => (d as List).map((e) => CategoryBreakdown.fromJson(e)).toList(),
      );

  static Future<List<MonthlyTrend>> getMonthlyTrends(int year) => _get(
        '/reports/monthly-trends/$year',
        (d) => (d as List).map((e) => MonthlyTrend.fromJson(e)).toList(),
      );

  static Future<List<PersonSpending>> getPersonSpending(
          int year, int month) =>
      _get(
        '/reports/person-spending/$year/$month',
        (d) => (d as List).map((e) => PersonSpending.fromJson(e)).toList(),
      );

  // ─── Investments ──────────────────────────────────────────────────────────

  static Future<List<Investment>> getInvestments() => _get(
        '/investments',
        (d) => (d as List).map((i) => Investment.fromJson(i)).toList(),
      );

  static Future<Investment> createInvestment({
    required String name,
    required String type,
    int? accountId,
    required double amount,
    double? currentValue,
    required DateTime startDate,
    DateTime? maturityDate,
    String? notes,
  }) async {
    final body = <String, dynamic>{
      'name': name,
      'type': type,
      'amount': amount,
      'start_date':
          '${startDate.year}-${startDate.month.toString().padLeft(2, '0')}-${startDate.day.toString().padLeft(2, '0')}',
    };
    if (accountId != null) body['account_id'] = accountId;
    if (currentValue != null) body['current_value'] = currentValue;
    if (maturityDate != null) {
      body['maturity_date'] =
          '${maturityDate.year}-${maturityDate.month.toString().padLeft(2, '0')}-${maturityDate.day.toString().padLeft(2, '0')}';
    }
    if (notes != null) body['notes'] = notes;
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/investments'),
      headers: _headers,
      body: jsonEncode(body),
    );
    if (res.statusCode == 201) return Investment.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to create investment');
  }

  static Future<Investment> updateInvestment(
    int id, {
    String? name,
    double? amount,
    double? currentValue,
    DateTime? maturityDate,
    String? notes,
    int? accountId,
  }) async {
    final body = <String, dynamic>{};
    if (name != null) body['name'] = name;
    if (amount != null) body['amount'] = amount;
    body['current_value'] = currentValue;
    if (maturityDate != null) {
      body['maturity_date'] =
          '${maturityDate.year}-${maturityDate.month.toString().padLeft(2, '0')}-${maturityDate.day.toString().padLeft(2, '0')}';
    }
    if (notes != null) body['notes'] = notes;
    if (accountId != null) body['account_id'] = accountId;
    final res = await http.put(
      Uri.parse('${ApiConfig.baseUrl}/investments/$id'),
      headers: _headers,
      body: jsonEncode(body),
    );
    if (res.statusCode == 200) return Investment.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to update investment');
  }

  static Future<void> deleteInvestment(int id) async {
    final res = await http.delete(
      Uri.parse('${ApiConfig.baseUrl}/investments/$id'),
      headers: _headers,
    );
    if (res.statusCode != 204) {
      throw Exception('Failed to delete investment');
    }
  }

  // ─── Loans ────────────────────────────────────────────────────────────────

  static Future<List<Loan>> getLoans() => _get(
        '/loans',
        (d) => (d as List).map((l) => Loan.fromJson(l)).toList(),
      );

  static Future<Loan> createLoan({
    required String name,
    required String type,
    String? lender,
    required double principalAmount,
    double? outstandingAmount,
    double? interestRate,
    double? emiAmount,
    DateTime? startDate,
    DateTime? endDate,
    int? accountId,
    String? notes,
  }) async {
    final body = <String, dynamic>{
      'name': name,
      'type': type,
      'principal_amount': principalAmount,
      'outstanding_amount': outstandingAmount ?? principalAmount,
    };
    if (lender != null) body['lender'] = lender;
    if (interestRate != null) body['interest_rate'] = interestRate;
    if (emiAmount != null) body['emi_amount'] = emiAmount;
    if (startDate != null) {
      body['start_date'] =
          '${startDate.year}-${startDate.month.toString().padLeft(2, '0')}-${startDate.day.toString().padLeft(2, '0')}';
    }
    if (endDate != null) {
      body['end_date'] =
          '${endDate.year}-${endDate.month.toString().padLeft(2, '0')}-${endDate.day.toString().padLeft(2, '0')}';
    }
    if (accountId != null) body['account_id'] = accountId;
    if (notes != null) body['notes'] = notes;
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/loans'),
      headers: _headers,
      body: jsonEncode(body),
    );
    if (res.statusCode == 201) return Loan.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to create loan');
  }

  static Future<Loan> updateLoan(
    int id, {
    String? name,
    String? type,
    String? lender,
    double? principalAmount,
    double? outstandingAmount,
    double? interestRate,
    double? emiAmount,
    DateTime? startDate,
    DateTime? endDate,
    int? accountId,
    String? notes,
  }) async {
    final body = <String, dynamic>{};
    if (name != null) body['name'] = name;
    if (type != null) body['type'] = type;
    if (lender != null) body['lender'] = lender;
    if (principalAmount != null) body['principal_amount'] = principalAmount;
    if (outstandingAmount != null) body['outstanding_amount'] = outstandingAmount;
    if (interestRate != null) body['interest_rate'] = interestRate;
    if (emiAmount != null) body['emi_amount'] = emiAmount;
    if (startDate != null) {
      body['start_date'] =
          '${startDate.year}-${startDate.month.toString().padLeft(2, '0')}-${startDate.day.toString().padLeft(2, '0')}';
    }
    if (endDate != null) {
      body['end_date'] =
          '${endDate.year}-${endDate.month.toString().padLeft(2, '0')}-${endDate.day.toString().padLeft(2, '0')}';
    }
    if (accountId != null) body['account_id'] = accountId;
    if (notes != null) body['notes'] = notes;
    final res = await http.put(
      Uri.parse('${ApiConfig.baseUrl}/loans/$id'),
      headers: _headers,
      body: jsonEncode(body),
    );
    if (res.statusCode == 200) return Loan.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to update loan');
  }

  static Future<void> deleteLoan(int id) async {
    final res = await http.delete(
      Uri.parse('${ApiConfig.baseUrl}/loans/$id'),
      headers: _headers,
    );
    if (res.statusCode != 204) {
      throw Exception('Failed to delete loan');
    }
  }

  // ─── User Management ──────────────────────────────────────────────────────

  static Future<User> createUser({
    required String username,
    required String displayName,
    required String password,
    String role = 'member',
  }) async {
    final res = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/users'),
      headers: _headers,
      body: jsonEncode({
        'username': username,
        'display_name': displayName,
        'password': password,
        'role': role,
      }),
    );
    if (res.statusCode == 201) return User.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to create user');
  }

  static Future<User> updateUserRole(int id, String role) async {
    final res = await http.put(
      Uri.parse('${ApiConfig.baseUrl}/users/$id/role'),
      headers: _headers,
      body: jsonEncode({'role': role}),
    );
    if (res.statusCode == 200) return User.fromJson(jsonDecode(res.body));
    throw Exception(jsonDecode(res.body)['detail'] ?? 'Failed to update role');
  }
}
