import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../services/export_service.dart';
import '../models/budget.dart';
import '../models/category.dart';

class ReportsScreen extends StatefulWidget {
  final VoidCallback? onMenuTap;
  const ReportsScreen({super.key, this.onMenuTap});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen>
    with SingleTickerProviderStateMixin {
  int _year = DateTime.now().year;
  int _month = DateTime.now().month;
  late TabController _tabCtrl;
  final _fmt = NumberFormat('#,##,##0', 'en_IN');

  List<CategoryBreakdown>? _breakdown;
  List<MonthlyTrend>? _trends;
  List<PersonSpending>? _personSpending;
  bool _loadingBreakdown = false;
  bool _loadingTrends = false;
  bool _loadingPerson = false;

  List<CategoryGroup> _allCategories = [];
  bool _exporting = false;

  static const _months = [
    '', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];

  static const _colors = [
    Color(0xFF1565C0), Color(0xFF2E7D32), Color(0xFFC62828),
    Color(0xFFE65100), Color(0xFF6A1B9A), Color(0xFF00838F),
    Color(0xFF558B2F), Color(0xFF4527A0), Color(0xFF283593),
    Color(0xFFAD1457), Color(0xFF00695C), Color(0xFFBF360C),
  ];

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
    _tabCtrl.addListener(() { if (!_tabCtrl.indexIsChanging) _loadTab(); });
    _loadTab();
    ApiService.getCategories().then((g) { if (mounted) setState(() => _allCategories = g); });
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  void _loadTab() {
    switch (_tabCtrl.index) {
      case 0: _loadBreakdown(); break;
      case 1: _loadTrends(); break;
      case 2: _loadPerson(); break;
    }
  }

  Future<void> _loadBreakdown() async {
    setState(() => _loadingBreakdown = true);
    try {
      final data = await ApiService.getCategoryBreakdown(_year, _month);
      setState(() => _breakdown = data);
    } catch (_) { setState(() => _breakdown = []); }
    finally { if (mounted) setState(() => _loadingBreakdown = false); }
  }

  Future<void> _loadTrends() async {
    setState(() => _loadingTrends = true);
    try {
      final data = await ApiService.getMonthlyTrends(_year);
      setState(() => _trends = data);
    } catch (_) { setState(() => _trends = []); }
    finally { if (mounted) setState(() => _loadingTrends = false); }
  }

  Future<void> _loadPerson() async {
    setState(() => _loadingPerson = true);
    try {
      final data = await ApiService.getPersonSpending(_year, _month);
      setState(() => _personSpending = data);
    } catch (_) { setState(() => _personSpending = []); }
    finally { if (mounted) setState(() => _loadingPerson = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: Column(
        children: [
          _buildHeader(),
          Expanded(
            child: TabBarView(
              controller: _tabCtrl,
              children: [
                _buildPieTab(),
                _buildTrendsTab(),
                _buildPersonTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      color: const Color(0xFF1565C0),
      padding: const EdgeInsets.fromLTRB(16, 48, 16, 0),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.menu, color: Colors.white),
                onPressed: widget.onMenuTap,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.bar_chart, color: Colors.white),
              const SizedBox(width: 8),
              const Text('Reports',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold)),
              const Spacer(),
              // Year selector
              Row(children: [
                IconButton(
                    icon: const Icon(Icons.chevron_left, color: Colors.white),
                    onPressed: () {
                      setState(() => _year--);
                      _loadTab();
                    }),
                Text('$_year',
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
                IconButton(
                    icon: const Icon(Icons.chevron_right, color: Colors.white),
                    onPressed: () {
                      setState(() => _year++);
                      _loadTab();
                    }),
                IconButton(
                  icon: _exporting
                      ? const SizedBox(
                          width: 18, height: 18,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2))
                      : const Icon(Icons.download, color: Colors.white),
                  onPressed: _exporting ? null : _showExportDialog,
                  tooltip: 'Export CSV',
                ),
              ]),
            ],
          ),
          // Month chips (for pie & person tabs)
          if (_tabCtrl.index != 1)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: List.generate(12, (i) {
                  final m = i + 1;
                  return Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: FilterChip(
                      label: Text(_months[m]),
                      selected: _month == m,
                      onSelected: (_) {
                        setState(() => _month = m);
                        _loadTab();
                      },
                      selectedColor: Colors.white,
                      labelStyle: TextStyle(
                          color: _month == m
                              ? const Color(0xFF1565C0)
                              : Colors.white,
                          fontWeight: FontWeight.bold),
                      backgroundColor: Colors.white24,
                      checkmarkColor: const Color(0xFF1565C0),
                    ),
                  );
                }),
              ),
            ),
          TabBar(
            controller: _tabCtrl,
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: const [
              Tab(text: 'By Category'),
              Tab(text: 'Monthly Trend'),
              Tab(text: 'By Person'),
            ],
          ),
        ],
      ),
    );
  }

  static const _fullMonths = [
    '', 'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  Future<void> _showExportDialog() async {
    String type = 'monthly';
    int month = _month;
    String? selectedCategory;
    final allCats = _allCategories
        .expand((g) => g.categories.map((c) => c.name))
        .toList();

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) => AlertDialog(
          title: const Text('Export Data'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                RadioListTile<String>(
                  title: const Text('Monthly Detail (Planned vs Actual)'),
                  value: 'monthly', groupValue: type,
                  onChanged: (v) => setDlg(() => type = v!),
                ),
                RadioListTile<String>(
                  title: const Text('Annual Summary'),
                  value: 'annual', groupValue: type,
                  onChanged: (v) => setDlg(() => type = v!),
                ),
                RadioListTile<String>(
                  title: const Text('All Transactions'),
                  value: 'transactions', groupValue: type,
                  onChanged: (v) => setDlg(() => type = v!),
                ),
                RadioListTile<String>(
                  title: const Text('By Category'),
                  value: 'category', groupValue: type,
                  onChanged: (v) => setDlg(() => type = v!),
                ),
                if (type == 'monthly' || type == 'transactions') ...[
                  const Divider(),
                  Row(children: [
                    const Text('Month: '),
                    const SizedBox(width: 8),
                    DropdownButton<int>(
                      value: month,
                      items: List.generate(12, (i) => DropdownMenuItem(
                          value: i + 1, child: Text(_fullMonths[i + 1]))),
                      onChanged: (m) => setDlg(() => month = m!),
                    ),
                  ]),
                ],
                if (type == 'category') ...[
                  const Divider(),
                  const Text('Category:'),
                  const SizedBox(height: 4),
                  DropdownButton<String>(
                    value: selectedCategory,
                    hint: const Text('Select category'),
                    isExpanded: true,
                    items: allCats.map((c) => DropdownMenuItem(
                        value: c, child: Text(c))).toList(),
                    onChanged: (c) => setDlg(() => selectedCategory = c),
                  ),
                ],
                const SizedBox(height: 8),
                Text('Year: $_year',
                    style: const TextStyle(color: Colors.grey, fontSize: 13)),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(ctx);
                _doExport(type, month, selectedCategory);
              },
              child: const Text('Export CSV'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _doExport(String type, int month, String? categoryName) async {
    setState(() => _exporting = true);
    try {
      String path;
      switch (type) {
        case 'monthly':
          path = await ExportService.exportMonthlyDetail(_year, month);
          break;
        case 'annual':
          path = await ExportService.exportAnnualSummary(_year);
          break;
        case 'transactions':
          path = await ExportService.exportTransactions(_year, month);
          break;
        case 'category':
          if (categoryName == null) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Please select a category'),
                  backgroundColor: Colors.orange));
            }
            return;
          }
          path = await ExportService.exportByCategory(_year, categoryName);
          break;
        default:
          return;
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Saved: $path'),
          duration: const Duration(seconds: 6),
          backgroundColor: Colors.green[700],
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Export failed: $e'),
          backgroundColor: Colors.red,
        ));
      }
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  Widget _buildPieTab() {
    if (_loadingBreakdown) return const Center(child: CircularProgressIndicator());
    if (_breakdown == null || _breakdown!.isEmpty) {
      return const Center(
          child: Text('No expense data for this month',
              style: TextStyle(color: Colors.grey)));
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        SizedBox(
          height: 220,
          child: PieChart(
            PieChartData(
              sections: _breakdown!.asMap().entries.map((e) {
                final color = _colors[e.key % _colors.length];
                return PieChartSectionData(
                  value: e.value.amount,
                  color: color,
                  title: '${e.value.percentage.toStringAsFixed(1)}%',
                  radius: 80,
                  titleStyle: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold),
                );
              }).toList(),
              centerSpaceRadius: 40,
              sectionsSpace: 2,
            ),
          ),
        ),
        const SizedBox(height: 16),
        ..._breakdown!.asMap().entries.map((e) {
          final color = _colors[e.key % _colors.length];
          return ListTile(
            dense: true,
            leading: Container(
                width: 14,
                height: 14,
                decoration: BoxDecoration(
                    color: color, borderRadius: BorderRadius.circular(3))),
            title: Text(e.value.groupName,
                style: const TextStyle(fontSize: 13)),
            trailing: Text(
              '₹${_fmt.format(e.value.amount)} (${e.value.percentage.toStringAsFixed(1)}%)',
              style: const TextStyle(
                  fontSize: 13, fontWeight: FontWeight.w500),
            ),
          );
        }).toList(),
      ],
    );
  }

  Widget _buildTrendsTab() {
    if (_loadingTrends) return const Center(child: CircularProgressIndicator());
    if (_trends == null || _trends!.isEmpty) {
      return const Center(
          child: Text('No data available', style: TextStyle(color: Colors.grey)));
    }
    final maxVal = _trends!.fold(0.0, (m, t) => t.income > m ? t.income : m);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Income vs Expenses by Month',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 12),
        SizedBox(
          height: 220,
          child: BarChart(
            BarChartData(
              maxY: maxVal * 1.2,
              barGroups: _trends!.map((t) {
                return BarChartGroupData(
                  x: t.month,
                  barRods: [
                    BarChartRodData(
                        toY: t.income,
                        color: Colors.green[400],
                        width: 8,
                        borderRadius: BorderRadius.circular(4)),
                    BarChartRodData(
                        toY: t.expenses,
                        color: Colors.red[400],
                        width: 8,
                        borderRadius: BorderRadius.circular(4)),
                  ],
                );
              }).toList(),
              titlesData: FlTitlesData(
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (v, _) => Text(
                        _months[v.toInt()],
                        style: const TextStyle(fontSize: 9)),
                  ),
                ),
                leftTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
                topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false)),
              ),
              gridData: const FlGridData(show: false),
              borderData: FlBorderData(show: false),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Row(children: [
          _Legend(color: Colors.green[400]!, label: 'Income'),
          const SizedBox(width: 16),
          _Legend(color: Colors.red[400]!, label: 'Expenses'),
        ]),
        const SizedBox(height: 16),
        ..._trends!.where((t) => t.income > 0 || t.expenses > 0).map((t) =>
            ListTile(
              dense: true,
              title: Text(_months[t.month],
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(
                  'Income: ₹${_fmt.format(t.income)}  |  Expenses: ₹${_fmt.format(t.expenses)}'),
              trailing: Text(
                '${t.net >= 0 ? '+' : ''}₹${_fmt.format(t.net)}',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: t.net >= 0 ? Colors.green[700] : Colors.red[700]),
              ),
            )).toList(),
      ],
    );
  }

  Widget _buildPersonTab() {
    if (_loadingPerson) return const Center(child: CircularProgressIndicator());
    if (_personSpending == null || _personSpending!.isEmpty) {
      return const Center(
          child: Text('No spending data for this month',
              style: TextStyle(color: Colors.grey)));
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Spending by Person',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 12),
        SizedBox(
          height: 200,
          child: PieChart(
            PieChartData(
              sections: _personSpending!.asMap().entries.map((e) {
                final color = _colors[e.key % _colors.length];
                return PieChartSectionData(
                  value: e.value.totalSpent,
                  color: color,
                  title: '${e.value.percentage.toStringAsFixed(1)}%',
                  radius: 80,
                  titleStyle: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold),
                );
              }).toList(),
              centerSpaceRadius: 40,
              sectionsSpace: 2,
            ),
          ),
        ),
        const SizedBox(height: 16),
        ..._personSpending!.asMap().entries.map((e) {
          final color = _colors[e.key % _colors.length];
          return Card(
            child: ListTile(
              leading: CircleAvatar(
                  backgroundColor: color,
                  child: Text(e.value.displayName[0],
                      style: const TextStyle(color: Colors.white))),
              title: Text(e.value.displayName),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('₹${_fmt.format(e.value.totalSpent)}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('${e.value.percentage.toStringAsFixed(1)}%',
                      style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                ],
              ),
            ),
          );
        }).toList(),
      ],
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  const _Legend({required this.color, required this.label});

  @override
  Widget build(BuildContext context) => Row(children: [
        Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
                color: color, borderRadius: BorderRadius.circular(3))),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 12)),
      ]);
}
