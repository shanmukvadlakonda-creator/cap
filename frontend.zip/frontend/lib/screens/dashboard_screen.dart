import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../services/auth_service.dart';
import '../models/budget.dart';
import '../models/transaction.dart';
import '../models/category.dart';
import '../models/account.dart';
import '../widgets/summary_card.dart';
import 'monthly_view_screen.dart';

class DashboardScreen extends StatefulWidget {
  final VoidCallback? onMenuTap;
  const DashboardScreen({super.key, this.onMenuTap});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _year = DateTime.now().year;
  AnnualSummary? _data;
  List<Transaction> _transactions = [];
  List<CategoryGroup> _groups = [];
  List<Account> _accounts = [];
  bool _loading = true;
  String? _error;
  final _fmt = NumberFormat('#,##,##0', 'en_IN');

  int get _currentMonth => DateTime.now().month;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final now = DateTime.now();
      final results = await Future.wait([
        ApiService.getAnnualBudget(_year),
        ApiService.getTransactions(year: now.year, month: now.month),
        ApiService.getCategories(),
        ApiService.getAccounts(),
      ]);
      setState(() {
        _data = results[0] as AnnualSummary;
        _transactions = results[1] as List<Transaction>;
        _groups = results[2] as List<CategoryGroup>;
        _accounts = results[3] as List<Account>;
      });
    } catch (e) {
      final msg = e.toString().replaceFirst('Exception: ', '');
      if (msg.contains('No budget found')) {
        setState(() => _error = 'no_budget');
      } else {
        setState(() => _error = msg);
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _reloadTransactions() async {
    try {
      final now = DateTime.now();
      final txns = await ApiService.getTransactions(year: now.year, month: now.month);
      setState(() => _transactions = txns);
    } catch (_) {}
  }

  Future<void> _editBeginningBalances(AnnualSummary d) async {
    final spendCtrl = TextEditingController(
        text: d.beginningSpendingBalance.toStringAsFixed(2));
    final savCtrl = TextEditingController(
        text: d.beginningSavingsBalance.toStringAsFixed(2));
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Edit Beginning Balances $_year'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: spendCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                  labelText: 'Beginning Spending Balance ₹',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: savCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                  labelText: 'Beginning Savings Balance ₹',
                  border: OutlineInputBorder()),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Save')),
        ],
      ),
    );
    if (ok == true) {
      try {
        await ApiService.updateBudget(
          _year,
          spendingBalance: double.tryParse(spendCtrl.text),
          savingsBalance: double.tryParse(savCtrl.text),
        );
        _load();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(e.toString()), backgroundColor: Colors.red));
        }
      }
    }
  }

  Future<void> _createBudget() async {
    final spendCtrl = TextEditingController(text: '0');
    final savCtrl = TextEditingController(text: '0');
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Set up Budget $_year'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: spendCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  labelText: 'Beginning Spending Balance ₹',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: savCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  labelText: 'Beginning Savings Balance ₹',
                  border: OutlineInputBorder()),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Create')),
        ],
      ),
    );
    if (ok == true) {
      try {
        await ApiService.createBudget(
          _year,
          double.tryParse(spendCtrl.text) ?? 0,
          double.tryParse(savCtrl.text) ?? 0,
        );
        _load();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(e.toString()), backgroundColor: Colors.red));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: Column(
        children: [
          _buildHeader(),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      color: const Color(0xFF1565C0),
      padding: const EdgeInsets.fromLTRB(16, 48, 16, 16),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.menu, color: Colors.white),
            onPressed: widget.onMenuTap,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
          const SizedBox(width: 8),
          const Icon(Icons.dashboard, color: Colors.white),
          const SizedBox(width: 8),
          const Expanded(
            child: Text('Annual Overview',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold)),
          ),
          IconButton(
            icon: const Icon(Icons.chevron_left, color: Colors.white),
            onPressed: () { _year--; _load(); },
          ),
          Text('$_year',
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
          IconButton(
            icon: const Icon(Icons.chevron_right, color: Colors.white),
            onPressed: () { _year++; _load(); },
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error == 'no_budget') {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.inbox, size: 64, color: Colors.grey),
            const SizedBox(height: 12),
            Text('No budget for $_year yet',
                style: const TextStyle(fontSize: 16, color: Colors.grey)),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _createBudget,
              icon: const Icon(Icons.add),
              label: Text('Create Budget $_year'),
            ),
          ],
        ),
      );
    }
    if (_error != null) {
      return Center(
        child: Column(children: [
          Text(_error!, style: const TextStyle(color: Colors.red)),
          TextButton(onPressed: _load, child: const Text('Retry')),
        ]),
      );
    }
    final d = _data!;
    final months = [
      '', 'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Summary cards
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: 2.6,
            children: [
              SummaryCard(
                label: 'Total Income',
                value: d.totalIncome,
                valueColor: const Color(0xFF1B5E20),
                bgColor: const Color(0xFFE8F5E9),
                icon: Icons.arrow_downward,
              ),
              SummaryCard(
                label: 'Total Expenses',
                value: d.totalExpenses,
                valueColor: const Color(0xFFB71C1C),
                bgColor: const Color(0xFFFFEBEE),
                icon: Icons.arrow_upward,
              ),
              SummaryCard(
                label: 'NET Balance',
                value: d.net,
                bgColor: d.net >= 0
                    ? const Color(0xFFE8F5E9)
                    : const Color(0xFFFFEBEE),
                icon: Icons.account_balance_wallet_outlined,
              ),
              SummaryCard(
                label: 'Spending Balance',
                value: d.monthly.isNotEmpty ? d.monthly.last.spendingBalance : 0,
                valueColor: const Color(0xFF0D47A1),
                bgColor: const Color(0xFFE3F2FD),
                icon: Icons.savings_outlined,
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Beginning balances with edit
          Card(
            elevation: 1,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Beginning Balances',
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: Color(0xFF1565C0))),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Text('Spending: ',
                                style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                            Text('₹${_fmt.format(d.beginningSpendingBalance)}',
                                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
                            const SizedBox(width: 16),
                            Text('Savings: ',
                                style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                            Text('₹${_fmt.format(d.beginningSavingsBalance)}',
                                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    onTap: () => _editBeginningBalances(d),
                    borderRadius: BorderRadius.circular(20),
                    child: const Padding(
                      padding: EdgeInsets.all(6),
                      child: Icon(Icons.edit_outlined, size: 18, color: Color(0xFF1565C0)),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Monthly Breakdown',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          // Month grid
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 1.4,
            ),
            itemCount: d.monthly.length,
            itemBuilder: (_, i) {
              final m = d.monthly[i];
              final isPositive = m.net >= 0;
              return GestureDetector(
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(
                        builder: (_) => MonthlyViewScreen(
                            year: _year, month: m.month))),
                child: Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(m.monthName.substring(0, 3),
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 13)),
                            Icon(
                              isPositive
                                  ? Icons.trending_up
                                  : Icons.trending_down,
                              size: 16,
                              color: isPositive ? Colors.green : Colors.red,
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('₹${_fmt.format(m.totalIncome)}',
                                style: const TextStyle(
                                    fontSize: 11, color: Colors.green)),
                            Text('₹${_fmt.format(m.totalExpenses)}',
                                style: const TextStyle(
                                    fontSize: 11, color: Colors.red)),
                            Text(
                              '${isPositive ? '+' : ''}₹${_fmt.format(m.net)}',
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: isPositive
                                      ? Colors.green[700]
                                      : Colors.red[700]),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 20),
          // This month's transactions
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${months[_currentMonth]} Transactions',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              Text(
                '${_transactions.length} entries',
                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (_transactions.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'No transactions this month',
                  style: TextStyle(color: Colors.grey.shade500),
                ),
              ),
            )
          else
            ...(_transactions.map((t) => _buildTransactionRow(t))),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget _buildTransactionRow(Transaction t) {
    final canEdit = AuthService.isAdmin || t.userId == AuthService.userId;
    final amtFmt = NumberFormat('#,##0.00', 'en_IN');

    return Card(
      margin: const EdgeInsets.only(bottom: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      elevation: 1,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        leading: CircleAvatar(
          radius: 18,
          backgroundColor: const Color(0xFF1565C0).withAlpha(20),
          child: const Icon(Icons.receipt_long, color: Color(0xFF1565C0), size: 16),
        ),
        title: Text(t.categoryName,
            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
        subtitle: Text(
          '${DateFormat('dd MMM').format(t.transactionDate)} · ${t.userDisplayName}'
          '${t.note != null && t.note!.isNotEmpty ? ' · ${t.note}' : ''}'
          '${t.accountName != null ? ' · ${t.accountName}' : ''}',
          style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '₹${amtFmt.format(t.amount)}',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            if (canEdit) ...[
              const SizedBox(width: 4),
              InkWell(
                onTap: () => _showEditDialog(t),
                child: const Padding(
                  padding: EdgeInsets.all(4),
                  child: Icon(Icons.edit_outlined, size: 18, color: Color(0xFF1565C0)),
                ),
              ),
              InkWell(
                onTap: () => _confirmDelete(t),
                child: Padding(
                  padding: const EdgeInsets.all(4),
                  child: Icon(Icons.delete_outline, size: 18, color: Colors.red.shade400),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _confirmDelete(Transaction t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete Transaction?'),
        content: Text(
            'Remove ₹${NumberFormat('#,##0.00', 'en_IN').format(t.amount)} - ${t.categoryName}?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Cancel')),
          TextButton(
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok == true) {
      try {
        await ApiService.deleteTransaction(t.id);
        _reloadTransactions();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
        }
      }
    }
  }

  void _showEditDialog(Transaction t) {
    CategoryGroup? initGroup;
    Category? initCategory;
    for (final g in _groups) {
      for (final c in g.categories) {
        if (c.id == t.categoryId) {
          initGroup = g;
          initCategory = c;
          break;
        }
      }
      if (initGroup != null) break;
    }

    CategoryGroup? selGroup = initGroup;
    Category? selCategory = initCategory;
    Account? selAccount = _accounts.where((a) => a.id == t.accountId).firstOrNull;
    DateTime selDate = t.transactionDate;
    final amtCtrl = TextEditingController(text: t.amount.toStringAsFixed(2));
    final noteCtrl = TextEditingController(text: t.note ?? '');
    bool saving = false;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Edit Transaction'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Date
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  leading: const Icon(Icons.calendar_today,
                      color: Color(0xFF1565C0), size: 18),
                  title: Text(DateFormat('dd MMM yyyy').format(selDate),
                      style: const TextStyle(fontSize: 13)),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      initialDate: selDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2100),
                    );
                    if (d != null) setS(() => selDate = d);
                  },
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<CategoryGroup>(
                  value: selGroup,
                  decoration: const InputDecoration(
                      labelText: 'Category Group',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: _groups
                      .map((g) => DropdownMenuItem(value: g, child: Text(g.name)))
                      .toList(),
                  onChanged: (g) => setS(() {
                    selGroup = g;
                    selCategory = null;
                  }),
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<Category>(
                  value: selCategory,
                  decoration: const InputDecoration(
                      labelText: 'Category',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: (selGroup?.categories ?? [])
                      .map((c) => DropdownMenuItem(value: c, child: Text(c.name)))
                      .toList(),
                  onChanged: (c) => setS(() => selCategory = c),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: amtCtrl,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                      labelText: 'Amount (₹)',
                      border: OutlineInputBorder(),
                      isDense: true,
                      prefixText: '₹ '),
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<Account?>(
                  value: selAccount,
                  decoration: const InputDecoration(
                      labelText: 'Account',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: [
                    const DropdownMenuItem<Account?>(
                        value: null, child: Text('None')),
                    ..._accounts.map((a) => DropdownMenuItem<Account?>(
                        value: a, child: Text(a.name))),
                  ],
                  onChanged: (v) => setS(() => selAccount = v),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: noteCtrl,
                  decoration: const InputDecoration(
                      labelText: 'Note (optional)',
                      border: OutlineInputBorder(),
                      isDense: true),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1565C0),
                  foregroundColor: Colors.white),
              onPressed: saving
                  ? null
                  : () async {
                      if (selCategory == null) return;
                      final amt = double.tryParse(amtCtrl.text);
                      if (amt == null || amt <= 0) return;
                      setS(() => saving = true);
                      try {
                        await ApiService.updateTransaction(
                          t.id,
                          categoryId: selCategory!.id,
                          amount: amt,
                          date: selDate,
                          accountId: selAccount?.id,
                          note: noteCtrl.text.isEmpty ? null : noteCtrl.text,
                        );
                        if (ctx.mounted) Navigator.pop(ctx);
                        _reloadTransactions();
                      } catch (e) {
                        setS(() => saving = false);
                        if (ctx.mounted) {
                          ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                              content: Text('Error: $e'),
                              backgroundColor: Colors.red));
                        }
                      }
                    },
              child: saving
                  ? const SizedBox(
                      height: 16,
                      width: 16,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2))
                  : const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}
