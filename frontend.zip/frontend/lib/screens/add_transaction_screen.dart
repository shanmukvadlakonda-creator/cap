import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../services/auth_service.dart';
import '../models/category.dart';
import '../models/user.dart';
import '../models/account.dart';
import '../models/investment.dart';
import '../models/loan.dart';

class AddTransactionScreen extends StatefulWidget {
  final int year;
  final int month;

  const AddTransactionScreen(
      {super.key, required this.year, required this.month});

  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();

  List<CategoryGroup> _groups = [];
  List<User> _users = [];
  List<Account> _accounts = [];
  List<Investment> _investments = [];
  List<Loan> _loans = [];
  bool _loading = true;
  bool _saving = false;

  CategoryGroup? _selectedGroup;
  Category? _selectedCategory;
  User? _selectedUser;
  Account? _selectedAccount;
  Investment? _selectedInvestment;
  Loan? _selectedLoan;
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _selectedDate =
        DateTime(widget.year, widget.month, DateTime.now().day <= 28 ? DateTime.now().day : 1);
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final results = await Future.wait([
        ApiService.getCategories(),
        ApiService.getUsers(),
        ApiService.getAccounts(),
      ]);
      final groups = results[0] as List<CategoryGroup>;
      final users = results[1] as List<User>;
      final accounts = results[2] as List<Account>;
      setState(() {
        _groups = groups;
        _users = users;
        _accounts = accounts;
        _selectedUser =
            users.firstWhere((u) => u.id == AuthService.userId, orElse: () => users.first);
        _loading = false;
      });
      // Load investments and loans silently
      try {
        final inv = await ApiService.getInvestments();
        if (mounted) setState(() => _investments = inv.where((i) => i.isActive).toList());
      } catch (_) {}
      try {
        final loans = await ApiService.getLoans();
        if (mounted) setState(() => _loans = loans.where((l) => l.isActive).toList());
      } catch (_) {}
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed to load: $e'), backgroundColor: Colors.red));
        Navigator.pop(context, false);
      }
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedCategory == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please select a category')));
      return;
    }
    setState(() => _saving = true);
    try {
      await ApiService.addTransaction(
        categoryId: _selectedCategory!.id,
        userId: _selectedUser!.id,
        amount: double.parse(_amountCtrl.text),
        date: _selectedDate,
        accountId: _selectedAccount?.id,
        investmentId: _selectedInvestment?.id,
        loanId: _selectedLoan?.id,
        note: _noteCtrl.text.isEmpty ? null : _noteCtrl.text,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() => _saving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(e.toString().replaceFirst('Exception: ', '')),
            backgroundColor: Colors.red));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Transaction'),
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Date picker
                    _SectionLabel('Date'),
                    ListTile(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(color: Colors.grey.shade300)),
                      tileColor: Colors.white,
                      leading: const Icon(Icons.calendar_today,
                          color: Color(0xFF1565C0)),
                      title: Text(DateFormat('dd MMM yyyy').format(_selectedDate)),
                      onTap: () async {
                        final d = await showDatePicker(
                          context: context,
                          initialDate: _selectedDate,
                          firstDate: DateTime(widget.year, widget.month, 1),
                          lastDate: DateTime(widget.year, widget.month + 1, 0),
                        );
                        if (d != null) setState(() => _selectedDate = d);
                      },
                    ),
                    const SizedBox(height: 16),

                    // Category group
                    _SectionLabel('Category Group'),
                    DropdownButtonFormField<CategoryGroup>(
                      value: _selectedGroup,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white),
                      hint: const Text('Select group'),
                      items: _groups
                          .map((g) => DropdownMenuItem(
                              value: g, child: Text(g.name)))
                          .toList(),
                      onChanged: (g) => setState(() {
                        _selectedGroup = g;
                        _selectedCategory = null;
                      }),
                      validator: (v) => v == null ? 'Select a group' : null,
                    ),
                    const SizedBox(height: 12),

                    // Category
                    _SectionLabel('Category'),
                    DropdownButtonFormField<Category>(
                      value: _selectedCategory,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white),
                      hint: const Text('Select category'),
                      items: (_selectedGroup?.categories ?? [])
                          .map((c) => DropdownMenuItem(
                              value: c, child: Text(c.name)))
                          .toList(),
                      onChanged: (c) => setState(() => _selectedCategory = c),
                      validator: (v) => v == null ? 'Select a category' : null,
                    ),
                    const SizedBox(height: 16),

                    // Amount
                    _SectionLabel('Amount (₹)'),
                    TextFormField(
                      controller: _amountCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        prefixText: '₹ ',
                        border: OutlineInputBorder(),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'Required';
                        if (double.tryParse(v) == null) return 'Invalid amount';
                        if (double.parse(v) <= 0) return 'Must be > 0';
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    // Account
                    _SectionLabel('Account (optional)'),
                    DropdownButtonFormField<Account>(
                      value: _selectedAccount,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white),
                      hint: const Text('Select account'),
                      items: [
                        const DropdownMenuItem<Account>(
                            value: null, child: Text('None')),
                        ..._accounts.map((a) => DropdownMenuItem(
                            value: a,
                            child: Row(
                              children: [
                                Icon(
                                  a.type == 'credit_card'
                                      ? Icons.credit_card
                                      : a.type == 'cash'
                                          ? Icons.money
                                          : Icons.account_balance,
                                  size: 16,
                                  color: const Color(0xFF1565C0),
                                ),
                                const SizedBox(width: 8),
                                Text(a.name),
                              ],
                            ))),
                      ],
                      onChanged: (v) => setState(() => _selectedAccount = v),
                    ),
                    const SizedBox(height: 16),

                    // Investment link
                    if (_investments.isNotEmpty) ...[
                      _SectionLabel('Link to Investment (optional)'),
                      DropdownButtonFormField<Investment?>(
                        value: _selectedInvestment,
                        decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            filled: true,
                            fillColor: Colors.white),
                        hint: const Text('Select investment'),
                        items: [
                          const DropdownMenuItem<Investment?>(
                              value: null, child: Text('None')),
                          ..._investments.map((inv) => DropdownMenuItem(
                              value: inv,
                              child: Row(children: [
                                const Icon(Icons.trending_up, size: 16, color: Color(0xFF00796B)),
                                const SizedBox(width: 8),
                                Expanded(child: Text('${inv.name} (${inv.type})', overflow: TextOverflow.ellipsis)),
                              ]))),
                        ],
                        onChanged: (v) => setState(() {
                          _selectedInvestment = v;
                          if (v != null) _selectedLoan = null;
                        }),
                      ),
                      const SizedBox(height: 16),
                    ],

                    // Loan link
                    if (_loans.isNotEmpty) ...[
                      _SectionLabel('Link to Loan EMI (optional)'),
                      DropdownButtonFormField<Loan?>(
                        value: _selectedLoan,
                        decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            filled: true,
                            fillColor: Colors.white),
                        hint: const Text('Select loan'),
                        items: [
                          const DropdownMenuItem<Loan?>(
                              value: null, child: Text('None')),
                          ..._loans.map((l) => DropdownMenuItem(
                              value: l,
                              child: Row(children: [
                                const Icon(Icons.account_balance_wallet, size: 16, color: Color(0xFFE65100)),
                                const SizedBox(width: 8),
                                Expanded(child: Text('${l.name} (${l.type})', overflow: TextOverflow.ellipsis)),
                              ]))),
                        ],
                        onChanged: (v) => setState(() {
                          _selectedLoan = v;
                          if (v != null) _selectedInvestment = null;
                        }),
                      ),
                      const SizedBox(height: 16),
                    ],

                    // Who
                    if (_users.length > 1) ...[
                      _SectionLabel('Spent By'),
                      DropdownButtonFormField<User>(
                        value: _selectedUser,
                        decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            filled: true,
                            fillColor: Colors.white),
                        items: _users
                            .map((u) => DropdownMenuItem(
                                value: u, child: Text(u.displayName)))
                            .toList(),
                        onChanged: (u) => setState(() => _selectedUser = u),
                      ),
                      const SizedBox(height: 16),
                    ],

                    // Note
                    _SectionLabel('Note (optional)'),
                    TextFormField(
                      controller: _noteCtrl,
                      maxLines: 2,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white,
                          hintText: 'Add a note...'),
                    ),
                    const SizedBox(height: 24),

                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _saving ? null : _submit,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF1565C0),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                        child: _saving
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                    color: Colors.white, strokeWidth: 2))
                            : const Text('Save Transaction',
                                style: TextStyle(fontSize: 16)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(text,
            style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 13,
                color: Color(0xFF1565C0))),
      );
}
