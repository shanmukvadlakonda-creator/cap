import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../services/auth_service.dart';
import '../models/category.dart';
import '../models/user.dart';

class AddTransactionScreen extends StatefulWidget {
  final int year;
  final int month;

  const AddTransactionScreen(
      {super.key, required this.year, required this.month});

  @override
  State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();

  List<CategoryGroup> _groups = [];
  List<User> _users = [];
  bool _loading = true;
  bool _saving = false;

  CategoryGroup? _selectedGroup;
  Category? _selectedCategory;
  User? _selectedUser;
  DateTime _selectedDate = DateTime.now();
  String _paymentMethod = 'Cash';

  static const _paymentMethods = [
    'Cash', 'SBI', 'ICICI', 'RBL', 'HDFC', 'HDFC Rupay', 'Yes Rupay'
  ];

  @override
  void initState() {
    super.initState();
    _selectedDate =
        DateTime(widget.year, widget.month, DateTime.now().day <= 28 ? DateTime.now().day : 1);
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final groups = await ApiService.getCategories();
      final users = await ApiService.getUsers();
      setState(() {
        _groups = groups;
        _users = users;
        _selectedUser =
            users.firstWhere((u) => u.id == AuthService.userId, orElse: () => users.first);
        _loading = false;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed to load: $e'), backgroundColor: Colors.red));
        Navigator.pop(context, false);
      }
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedCategory == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please select a category')));
      return;
    }
    setState(() => _saving = true);
    try {
      await ApiService.addTransaction(
        categoryId: _selectedCategory!.id,
        userId: _selectedUser!.id,
        amount: double.parse(_amountCtrl.text),
        date: _selectedDate,
        paymentMethod: _paymentMethod,
        note: _noteCtrl.text.isEmpty ? null : _noteCtrl.text,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      setState(() => _saving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(e.toString().replaceFirst('Exception: ', '')),
            backgroundColor: Colors.red));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Transaction'),
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Date picker
                    _SectionLabel('Date'),
                    ListTile(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          side: BorderSide(color: Colors.grey.shade300)),
                      tileColor: Colors.white,
                      leading: const Icon(Icons.calendar_today,
                          color: Color(0xFF1565C0)),
                      title: Text(DateFormat('dd MMM yyyy').format(_selectedDate)),
                      onTap: () async {
                        final d = await showDatePicker(
                          context: context,
                          initialDate: _selectedDate,
                          firstDate: DateTime(widget.year, widget.month, 1),
                          lastDate: DateTime(widget.year, widget.month + 1, 0),
                        );
                        if (d != null) setState(() => _selectedDate = d);
                      },
                    ),
                    const SizedBox(height: 16),

                    // Category group
                    _SectionLabel('Category Group'),
                    DropdownButtonFormField<CategoryGroup>(
                      value: _selectedGroup,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white),
                      hint: const Text('Select group'),
                      items: _groups
                          .map((g) => DropdownMenuItem(
                              value: g, child: Text(g.name)))
                          .toList(),
                      onChanged: (g) => setState(() {
                        _selectedGroup = g;
                        _selectedCategory = null;
                      }),
                      validator: (v) => v == null ? 'Select a group' : null,
                    ),
                    const SizedBox(height: 12),

                    // Category
                    _SectionLabel('Category'),
                    DropdownButtonFormField<Category>(
                      value: _selectedCategory,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white),
                      hint: const Text('Select category'),
                      items: (_selectedGroup?.categories ?? [])
                          .map((c) => DropdownMenuItem(
                              value: c, child: Text(c.name)))
                          .toList(),
                      onChanged: (c) => setState(() => _selectedCategory = c),
                      validator: (v) => v == null ? 'Select a category' : null,
                    ),
                    const SizedBox(height: 16),

                    // Amount
                    _SectionLabel('Amount (₹)'),
                    TextFormField(
                      controller: _amountCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        prefixText: '₹ ',
                        border: OutlineInputBorder(),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'Required';
                        if (double.tryParse(v) == null) return 'Invalid amount';
                        if (double.parse(v) <= 0) return 'Must be > 0';
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    // Payment method
                    _SectionLabel('Payment Method'),
                    DropdownButtonFormField<String>(
                      value: _paymentMethod,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white),
                      items: _paymentMethods
                          .map((m) => DropdownMenuItem(value: m, child: Text(m)))
                          .toList(),
                      onChanged: (v) => setState(() => _paymentMethod = v!),
                    ),
                    const SizedBox(height: 16),

                    // Who
                    if (_users.length > 1) ...[
                      _SectionLabel('Spent By'),
                      DropdownButtonFormField<User>(
                        value: _selectedUser,
                        decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            filled: true,
                            fillColor: Colors.white),
                        items: _users
                            .map((u) => DropdownMenuItem(
                                value: u, child: Text(u.displayName)))
                            .toList(),
                        onChanged: (u) => setState(() => _selectedUser = u),
                      ),
                      const SizedBox(height: 16),
                    ],

                    // Note
                    _SectionLabel('Note (optional)'),
                    TextFormField(
                      controller: _noteCtrl,
                      maxLines: 2,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          filled: true,
                          fillColor: Colors.white,
                          hintText: 'Add a note...'),
                    ),
                    const SizedBox(height: 24),

                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _saving ? null : _submit,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF1565C0),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                        child: _saving
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                    color: Colors.white, strokeWidth: 2))
                            : const Text('Save Transaction',
                                style: TextStyle(fontSize: 16)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(text,
            style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 13,
                color: Color(0xFF1565C0))),
      );
}
