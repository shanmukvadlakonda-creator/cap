import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/category.dart';

class BudgetPlanningScreen extends StatefulWidget {
  final VoidCallback? onMenuTap;
  const BudgetPlanningScreen({super.key, this.onMenuTap});

  @override
  State<BudgetPlanningScreen> createState() => _BudgetPlanningScreenState();
}

class _BudgetPlanningScreenState extends State<BudgetPlanningScreen> {
  int _year = DateTime.now().year;
  int _month = DateTime.now().month;
  List<CategoryGroup> _groups = [];
  Map<int, double> _targets = {}; // category_id -> planned_amount
  Map<int, TextEditingController> _controllers = {};
  bool _loading = true;
  bool _saving = false;

  static const _months = [
    '', 'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in _controllers.values) c.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final groups = await ApiService.getCategories();
      final targets = await ApiService.getTargets(_year, _month);
      final targetMap = <int, double>{};
      for (final t in targets) {
        targetMap[t['category_id'] as int] =
            (t['planned_amount'] as num).toDouble();
      }
      // Build controllers
      for (final c in _controllers.values) c.dispose();
      _controllers = {};
      for (final g in groups) {
        for (final cat in g.categories) {
          _controllers[cat.id] = TextEditingController(
              text: targetMap[cat.id]?.toStringAsFixed(0) ?? '');
        }
      }
      setState(() {
        _groups = groups;
        _targets = targetMap;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('$e'), backgroundColor: Colors.red));
      }
    }
  }

  Future<void> _saveAll() async {
    setState(() => _saving = true);
    try {
      for (final entry in _controllers.entries) {
        final val = double.tryParse(entry.value.text) ?? 0;
        if (val > 0 || (_targets[entry.key] ?? 0) > 0) {
          await ApiService.upsertTarget(_year, _month, entry.key, val);
        }
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Budget targets saved!'),
                backgroundColor: Colors.green));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('$e'), backgroundColor: Colors.red));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _copyPrevious() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Copy from previous month?'),
        content: Text(
            'This will copy all planned amounts from ${_month == 1 ? 'December ${_year - 1}' : '${_months[_month - 1]} $_year'} to ${_months[_month]} $_year.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Copy')),
        ],
      ),
    );
    if (ok == true) {
      try {
        await ApiService.copyTargetsFromPrevious(_year, _month);
        _load();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('$e'), backgroundColor: Colors.red));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: Column(
        children: [
          _buildHeader(),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView(
                    padding: const EdgeInsets.all(12),
                    children: _groups
                        .where((g) => g.type != 'income')
                        .map((g) => _buildGroupCard(g))
                        .toList(),
                  ),
          ),
          _buildBottomBar(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      color: const Color(0xFF1565C0),
      padding: const EdgeInsets.fromLTRB(16, 48, 16, 16),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.menu, color: Colors.white),
            onPressed: widget.onMenuTap,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
          const SizedBox(width: 8),
          const Icon(Icons.track_changes, color: Colors.white),
          const SizedBox(width: 8),
          const Text('Budget Planning',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold)),
          const Spacer(),
          // Month selector
          DropdownButton<int>(
            value: _month,
            dropdownColor: const Color(0xFF1565C0),
            style: const TextStyle(color: Colors.white),
            iconEnabledColor: Colors.white,
            underline: const SizedBox(),
            items: List.generate(
                12,
                (i) => DropdownMenuItem(
                    value: i + 1,
                    child: Text(_months[i + 1],
                        style: const TextStyle(color: Colors.white)))),
            onChanged: (m) {
              setState(() => _month = m!);
              _load();
            },
          ),
          // Year
          Row(children: [
            IconButton(
                icon: const Icon(Icons.chevron_left, color: Colors.white),
                onPressed: () { setState(() => _year--); _load(); }),
            Text('$_year',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
            IconButton(
                icon: const Icon(Icons.chevron_right, color: Colors.white),
                onPressed: () { setState(() => _year++); _load(); }),
          ]),
        ],
      ),
    );
  }

  Widget _buildGroupCard(CategoryGroup group) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ExpansionTile(
        title: Text(group.name,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        leading: Container(
          width: 10,
          decoration: BoxDecoration(
            color: group.type == 'savings'
                ? Colors.blue
                : Colors.orange,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        children: group.categories.map((cat) {
          return ListTile(
            dense: true,
            title: Text(cat.name, style: const TextStyle(fontSize: 13)),
            trailing: SizedBox(
              width: 120,
              child: TextFormField(
                controller: _controllers[cat.id],
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                textAlign: TextAlign.right,
                decoration: const InputDecoration(
                  prefixText: '₹',
                  isDense: true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                  border: OutlineInputBorder(),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.white,
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: _copyPrevious,
              icon: const Icon(Icons.copy),
              label: const Text('Copy Previous'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: _saving ? null : _saveAll,
              icon: _saving
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.save),
              label: const Text('Save All'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1565C0),
                  foregroundColor: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}
