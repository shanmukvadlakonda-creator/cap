import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../models/account.dart';
import '../models/account_transfer.dart';
import '../models/investment.dart';

final _fmt = NumberFormat('#,##0.00', 'en_IN');
String _inr(double v) => '₹${_fmt.format(v)}';

class AccountsScreen extends StatefulWidget {
  const AccountsScreen({super.key});

  @override
  State<AccountsScreen> createState() => _AccountsScreenState();
}

class _AccountsScreenState extends State<AccountsScreen> {
  List<Account> _accounts = [];
  List<Investment> _investments = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final results = await Future.wait([
        ApiService.getAccounts(),
        ApiService.getInvestments(),
      ]);
      setState(() {
        _accounts = results[0] as List<Account>;
        _investments = results[1] as List<Investment>;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed to load: $e'), backgroundColor: Colors.red));
      }
    }
  }

  List<Account> _byType(String type) =>
      _accounts.where((a) => a.type == type).toList();

  double _totalBalance(String type) =>
      _byType(type).fold(0, (s, a) => s + a.balance);

  List<Investment> _investmentsByType(String type) =>
      _investments.where((i) => i.type == type).toList();

  double get _totalInvested => _investments.fold(0, (s, i) => s + i.amount);
  double get _totalCurrentValue => _investments.fold(
      0, (s, i) => s + (i.currentValue ?? i.amount));

  @override
  Widget build(BuildContext context) {
    const investmentTypes = ['SIP', 'FD', 'Gold', 'Land', 'Other'];

    return Scaffold(
      backgroundColor: const Color(0xFFF0F4FF),
      appBar: AppBar(
        title: const Text('Accounts & Wallets'),
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.swap_horiz),
            tooltip: 'Add Transfer',
            onPressed: () => _showTransferDialog(context),
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _load,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
                children: [
                  if (_byType('bank').isNotEmpty) ...[
                    _SectionHeader(
                        'Bank Accounts', _totalBalance('bank'), false),
                    ..._byType('bank').map((a) => _AccountCard(
                        account: a, onRefresh: _load)),
                    const SizedBox(height: 16),
                  ],
                  if (_byType('cash').isNotEmpty) ...[
                    _SectionHeader('Cash', _totalBalance('cash'), false),
                    ..._byType('cash').map((a) => _AccountCard(
                        account: a, onRefresh: _load)),
                    const SizedBox(height: 16),
                  ],
                  if (_byType('credit_card').isNotEmpty) ...[
                    _SectionHeader(
                        'Credit Cards', _totalBalance('credit_card'), true),
                    ..._byType('credit_card').map((a) => _AccountCard(
                        account: a, onRefresh: _load)),
                    const SizedBox(height: 16),
                  ],
                  if (_investments.isNotEmpty) ...[
                    _InvestmentSectionHeader(
                        totalInvested: _totalInvested,
                        totalCurrentValue: _totalCurrentValue),
                    for (final type in investmentTypes)
                      if (_investmentsByType(type).isNotEmpty) ...[
                        Padding(
                          padding: const EdgeInsets.only(top: 8, bottom: 4),
                          child: Text(type,
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey.shade600)),
                        ),
                        ..._investmentsByType(type).map((inv) => _InvestmentCard(
                            investment: inv,
                            accounts: _accounts,
                            onRefresh: _load)),
                      ],
                    const SizedBox(height: 16),
                  ],
                  if (_accounts.isEmpty && _investments.isEmpty)
                    Center(
                      child: Column(
                        children: [
                          const SizedBox(height: 60),
                          Icon(Icons.account_balance_wallet_outlined,
                              size: 64, color: Colors.grey.shade400),
                          const SizedBox(height: 12),
                          Text('No accounts yet',
                              style: TextStyle(
                                  color: Colors.grey.shade600, fontSize: 16)),
                          const SizedBox(height: 8),
                          Text('Tap + to add your first account',
                              style: TextStyle(color: Colors.grey.shade500)),
                        ],
                      ),
                    ),
                ],
              ),
            ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton.small(
            heroTag: 'addInvestment',
            backgroundColor: const Color(0xFF1565C0),
            foregroundColor: Colors.white,
            tooltip: 'Add Investment',
            onPressed: () => _showAddInvestmentDialog(context),
            child: const Icon(Icons.trending_up),
          ),
          const SizedBox(height: 8),
          FloatingActionButton.extended(
            heroTag: 'addAccount',
            backgroundColor: const Color(0xFF1565C0),
            foregroundColor: Colors.white,
            icon: const Icon(Icons.add),
            label: const Text('Add Account'),
            onPressed: () => _showAddAccountDialog(context),
          ),
        ],
      ),
    );
  }

  void _showAddInvestmentDialog(BuildContext context) {
    final nameCtrl = TextEditingController();
    final amtCtrl = TextEditingController();
    final notesCtrl = TextEditingController();
    String type = 'SIP';
    Account? selAccount;
    DateTime startDate = DateTime.now();
    DateTime? maturityDate;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Add Investment'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                      labelText: 'Name', border: OutlineInputBorder(), isDense: true),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: type,
                  decoration: const InputDecoration(
                      labelText: 'Type', border: OutlineInputBorder(), isDense: true),
                  items: const [
                    DropdownMenuItem(value: 'SIP', child: Text('SIP')),
                    DropdownMenuItem(value: 'FD', child: Text('Fixed Deposit (FD)')),
                    DropdownMenuItem(value: 'Gold', child: Text('Gold')),
                    DropdownMenuItem(value: 'Land', child: Text('Land')),
                    DropdownMenuItem(value: 'Other', child: Text('Other')),
                  ],
                  onChanged: (v) => setS(() => type = v!),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<Account?>(
                  value: selAccount,
                  decoration: const InputDecoration(
                      labelText: 'Funded From (Account)',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: [
                    const DropdownMenuItem<Account?>(value: null, child: Text('None')),
                    ..._accounts.map((a) => DropdownMenuItem<Account?>(
                        value: a, child: Text(a.name))),
                  ],
                  onChanged: (v) => setS(() => selAccount = v),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: amtCtrl,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                      labelText: 'Amount (₹)',
                      border: OutlineInputBorder(),
                      isDense: true,
                      prefixText: '₹ '),
                ),
                const SizedBox(height: 10),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  leading: const Icon(Icons.calendar_today,
                      color: Color(0xFF1565C0), size: 18),
                  title: Text('Start: ${DateFormat('dd MMM yyyy').format(startDate)}',
                      style: const TextStyle(fontSize: 13)),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      initialDate: startDate,
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (d != null) setS(() => startDate = d);
                  },
                ),
                if (type == 'FD') ...[
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    leading: const Icon(Icons.event, color: Color(0xFF1565C0), size: 18),
                    title: Text(
                      maturityDate != null
                          ? 'Maturity: ${DateFormat('dd MMM yyyy').format(maturityDate!)}'
                          : 'Set Maturity Date',
                      style: const TextStyle(fontSize: 13),
                    ),
                    onTap: () async {
                      final d = await showDatePicker(
                        context: ctx,
                        initialDate: maturityDate ?? DateTime.now().add(const Duration(days: 365)),
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                      );
                      if (d != null) setS(() => maturityDate = d);
                    },
                  ),
                ],
                const SizedBox(height: 10),
                TextField(
                  controller: notesCtrl,
                  decoration: const InputDecoration(
                      labelText: 'Notes (optional)',
                      border: OutlineInputBorder(),
                      isDense: true),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1565C0),
                  foregroundColor: Colors.white),
              onPressed: () async {
                if (nameCtrl.text.trim().isEmpty) return;
                final amt = double.tryParse(amtCtrl.text);
                if (amt == null || amt <= 0) return;
                try {
                  await ApiService.createInvestment(
                    name: nameCtrl.text.trim(),
                    type: type,
                    accountId: selAccount?.id,
                    amount: amt,
                    startDate: startDate,
                    maturityDate: maturityDate,
                    notes: notesCtrl.text.isEmpty ? null : notesCtrl.text.trim(),
                  );
                  if (ctx.mounted) Navigator.pop(ctx);
                  _load();
                } catch (e) {
                  if (ctx.mounted) {
                    ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                        content: Text('Error: $e'), backgroundColor: Colors.red));
                  }
                }
              },
              child: const Text('Add'),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddAccountDialog(BuildContext context) {
    final nameCtrl = TextEditingController();
    final balCtrl = TextEditingController();
    String type = 'bank';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Add Account'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                      labelText: 'Account Name',
                      border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: type,
                  decoration: const InputDecoration(
                      labelText: 'Type', border: OutlineInputBorder()),
                  items: const [
                    DropdownMenuItem(value: 'bank', child: Text('Bank Account')),
                    DropdownMenuItem(
                        value: 'credit_card', child: Text('Credit Card')),
                    DropdownMenuItem(value: 'cash', child: Text('Cash')),
                  ],
                  onChanged: (v) => setS(() => type = v!),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: balCtrl,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                    labelText: type == 'credit_card'
                        ? 'Opening Outstanding (₹)'
                        : 'Opening Balance (₹)',
                    border: const OutlineInputBorder(),
                    prefixText: '₹ ',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1565C0),
                  foregroundColor: Colors.white),
              onPressed: () async {
                if (nameCtrl.text.trim().isEmpty) return;
                try {
                  await ApiService.createAccount(
                    name: nameCtrl.text.trim(),
                    type: type,
                    openingBalance:
                        double.tryParse(balCtrl.text) ?? 0,
                  );
                  if (ctx.mounted) Navigator.pop(ctx);
                  _load();
                } catch (e) {
                  if (ctx.mounted) {
                    ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                        content: Text('Error: $e'),
                        backgroundColor: Colors.red));
                  }
                }
              },
              child: const Text('Add'),
            ),
          ],
        ),
      ),
    );
  }

  void _showTransferDialog(BuildContext context) {
    if (_accounts.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Need at least 2 accounts to transfer')));
      return;
    }

    Account? fromAcc = _accounts.first;
    Account? toAcc = _accounts.length > 1 ? _accounts[1] : null;
    final amtCtrl = TextEditingController();
    final noteCtrl = TextEditingController();
    DateTime date = DateTime.now();

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) {
          final isCcPayment = toAcc?.type == 'credit_card';
          return AlertDialog(
            title: Text(isCcPayment ? 'Pay Credit Card Bill' : 'Transfer'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<Account>(
                    value: fromAcc,
                    decoration: const InputDecoration(
                        labelText: 'From', border: OutlineInputBorder()),
                    items: _accounts
                        .map((a) => DropdownMenuItem(
                            value: a, child: Text(a.name)))
                        .toList(),
                    onChanged: (v) => setS(() => fromAcc = v),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<Account>(
                    value: toAcc,
                    decoration: InputDecoration(
                        labelText: isCcPayment ? 'Pay To (CC)' : 'To',
                        border: const OutlineInputBorder()),
                    items: _accounts
                        .map((a) => DropdownMenuItem(
                            value: a, child: Text(a.name)))
                        .toList(),
                    onChanged: (v) => setS(() => toAcc = v),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: amtCtrl,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                        labelText: 'Amount (₹)',
                        border: OutlineInputBorder(),
                        prefixText: '₹ '),
                  ),
                  const SizedBox(height: 12),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.calendar_today,
                        color: Color(0xFF1565C0)),
                    title: Text(DateFormat('dd MMM yyyy').format(date)),
                    onTap: () async {
                      final d = await showDatePicker(
                        context: ctx,
                        initialDate: date,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2100),
                      );
                      if (d != null) setS(() => date = d);
                    },
                  ),
                  TextField(
                    controller: noteCtrl,
                    decoration: const InputDecoration(
                        labelText: 'Note (optional)',
                        border: OutlineInputBorder()),
                  ),
                  if (isCcPayment)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Row(
                        children: [
                          const Icon(Icons.info_outline,
                              size: 14, color: Color(0xFF1565C0)),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              'This will reduce ${toAcc?.name} outstanding',
                              style: const TextStyle(
                                  fontSize: 12, color: Color(0xFF1565C0)),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Cancel')),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1565C0),
                    foregroundColor: Colors.white),
                onPressed: () async {
                  final amt = double.tryParse(amtCtrl.text);
                  if (fromAcc == null || toAcc == null || amt == null || amt <= 0) {
                    ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                        content: Text('Fill all fields correctly')));
                    return;
                  }
                  if (fromAcc!.id == toAcc!.id) {
                    ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                        content: Text('From and To must be different')));
                    return;
                  }
                  try {
                    await ApiService.createTransfer(
                      fromAccountId: fromAcc!.id,
                      toAccountId: toAcc!.id,
                      amount: amt,
                      date: date,
                      note: noteCtrl.text.isEmpty ? null : noteCtrl.text,
                    );
                    if (ctx.mounted) Navigator.pop(ctx);
                    _load();
                  } catch (e) {
                    if (ctx.mounted) {
                      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                          content: Text('Error: $e'),
                          backgroundColor: Colors.red));
                    }
                  }
                },
                child: Text(isCcPayment ? 'Pay Bill' : 'Transfer'),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _InvestmentSectionHeader extends StatelessWidget {
  final double totalInvested;
  final double totalCurrentValue;

  const _InvestmentSectionHeader(
      {required this.totalInvested, required this.totalCurrentValue});

  @override
  Widget build(BuildContext context) {
    final gainLoss = totalCurrentValue - totalInvested;
    final gainLossColor = gainLoss >= 0 ? Colors.green.shade700 : Colors.red.shade700;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Investments',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  color: Color(0xFF1565C0))),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('Invested: ${_inr(totalInvested)}',
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade700,
                      fontWeight: FontWeight.w500)),
              if (gainLoss != 0)
                Text(
                  '${gainLoss >= 0 ? '+' : ''}${_inr(gainLoss)}',
                  style: TextStyle(
                      fontSize: 12,
                      color: gainLossColor,
                      fontWeight: FontWeight.w600),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final double total;
  final bool isCc;

  const _SectionHeader(this.title, this.total, this.isCc);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title,
              style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  color: Color(0xFF1565C0))),
          Text(
            isCc ? 'Outstanding: ${_inr(total)}' : 'Total: ${_inr(total)}',
            style: TextStyle(
                fontSize: 13,
                color: isCc && total > 0 ? Colors.red.shade700 : Colors.green.shade700,
                fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

class _InvestmentCard extends StatelessWidget {
  final Investment investment;
  final List<Account> accounts;
  final VoidCallback onRefresh;

  const _InvestmentCard(
      {required this.investment, required this.accounts, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    final gainLoss = investment.gainLoss;
    final currentVal = investment.currentValue ?? investment.amount;

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 1,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _showQuickValueDialog(context),
        onLongPress: () => _showFullEditDialog(context),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: const Color(0xFF1565C0).withAlpha(20),
                child: const Icon(Icons.trending_up, color: Color(0xFF1565C0)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(investment.name,
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                    if (investment.accountName != null)
                      Text(investment.accountName!,
                          style: TextStyle(
                              fontSize: 11, color: Colors.grey.shade600)),
                    if (investment.maturityDate != null)
                      Text(
                          'Matures: ${DateFormat('dd MMM yyyy').format(investment.maturityDate!)}',
                          style: TextStyle(
                              fontSize: 11, color: Colors.grey.shade500)),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    _inr(currentVal),
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 14),
                  ),
                  Text('Inv: ${_inr(investment.amount)}',
                      style: TextStyle(
                          fontSize: 11, color: Colors.grey.shade600)),
                  if (gainLoss != null && gainLoss != 0)
                    Text(
                      '${gainLoss >= 0 ? '+' : ''}${_inr(gainLoss)}',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: gainLoss >= 0
                              ? Colors.green.shade700
                              : Colors.red.shade700),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showQuickValueDialog(BuildContext context) {
    final ctrl = TextEditingController(
        text: (investment.currentValue ?? investment.amount).toStringAsFixed(2));
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Update Value: ${investment.name}'),
        content: TextField(
          controller: ctrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          autofocus: true,
          decoration: const InputDecoration(
              labelText: 'Current Value (₹)',
              border: OutlineInputBorder(),
              prefixText: '₹ '),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1565C0),
                foregroundColor: Colors.white),
            onPressed: () async {
              final val = double.tryParse(ctrl.text);
              if (val == null || val < 0) return;
              try {
                await ApiService.updateInvestment(investment.id,
                    currentValue: val);
                if (ctx.mounted) Navigator.pop(ctx);
                onRefresh();
              } catch (e) {
                if (ctx.mounted) {
                  ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                      content: Text('Error: $e'), backgroundColor: Colors.red));
                }
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showFullEditDialog(BuildContext context) {
    final nameCtrl = TextEditingController(text: investment.name);
    final amtCtrl =
        TextEditingController(text: investment.amount.toStringAsFixed(2));
    final notesCtrl = TextEditingController(text: investment.notes ?? '');
    DateTime? maturityDate = investment.maturityDate;
    Account? selAccount =
        accounts.where((a) => a.id == investment.accountId).firstOrNull;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text('Edit: ${investment.name}'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(
                      labelText: 'Name',
                      border: OutlineInputBorder(),
                      isDense: true),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: amtCtrl,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                      labelText: 'Invested Amount (₹)',
                      border: OutlineInputBorder(),
                      isDense: true,
                      prefixText: '₹ '),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<Account?>(
                  value: selAccount,
                  decoration: const InputDecoration(
                      labelText: 'Funded From',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: [
                    const DropdownMenuItem<Account?>(
                        value: null, child: Text('None')),
                    ...accounts.map((a) => DropdownMenuItem<Account?>(
                        value: a, child: Text(a.name))),
                  ],
                  onChanged: (v) => setS(() => selAccount = v),
                ),
                const SizedBox(height: 10),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  leading: const Icon(Icons.event,
                      color: Color(0xFF1565C0), size: 18),
                  title: Text(
                    maturityDate != null
                        ? 'Maturity: ${DateFormat('dd MMM yyyy').format(maturityDate!)}'
                        : 'Set Maturity Date',
                    style: const TextStyle(fontSize: 13),
                  ),
                  trailing: maturityDate != null
                      ? IconButton(
                          icon: const Icon(Icons.clear, size: 16),
                          onPressed: () => setS(() => maturityDate = null),
                        )
                      : null,
                  onTap: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      initialDate: maturityDate ??
                          DateTime.now().add(const Duration(days: 365)),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                    );
                    if (d != null) setS(() => maturityDate = d);
                  },
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: notesCtrl,
                  decoration: const InputDecoration(
                      labelText: 'Notes (optional)',
                      border: OutlineInputBorder(),
                      isDense: true),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(foregroundColor: Colors.red),
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: ctx,
                  builder: (c) => AlertDialog(
                    title: const Text('Remove Investment?'),
                    content:
                        Text('Remove "${investment.name}" from investments?'),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(c, false),
                          child: const Text('Cancel')),
                      TextButton(
                          onPressed: () => Navigator.pop(c, true),
                          child: const Text('Remove',
                              style: TextStyle(color: Colors.red))),
                    ],
                  ),
                );
                if (confirm == true) {
                  await ApiService.deleteInvestment(investment.id);
                  if (ctx.mounted) Navigator.pop(ctx);
                  onRefresh();
                }
              },
              child: const Text('Remove'),
            ),
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1565C0),
                  foregroundColor: Colors.white),
              onPressed: () async {
                final amt = double.tryParse(amtCtrl.text);
                if (amt == null || amt <= 0) return;
                try {
                  await ApiService.updateInvestment(
                    investment.id,
                    name: nameCtrl.text.trim().isEmpty ? null : nameCtrl.text.trim(),
                    amount: amt,
                    maturityDate: maturityDate,
                    notes: notesCtrl.text.isEmpty ? null : notesCtrl.text.trim(),
                    accountId: selAccount?.id,
                  );
                  if (ctx.mounted) Navigator.pop(ctx);
                  onRefresh();
                } catch (e) {
                  if (ctx.mounted) {
                    ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                        content: Text('Error: $e'),
                        backgroundColor: Colors.red));
                  }
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}

class _AccountCard extends StatelessWidget {
  final Account account;
  final VoidCallback onRefresh;

  const _AccountCard({required this.account, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    final isCc = account.type == 'credit_card';
    final balColor = isCc
        ? (account.balance > 0 ? Colors.red.shade700 : Colors.green.shade700)
        : (account.balance >= 0 ? Colors.green.shade700 : Colors.red.shade700);

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 1,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: const Color(0xFF1565C0).withAlpha(20),
          child: Icon(
            isCc
                ? Icons.credit_card
                : account.type == 'cash'
                    ? Icons.money
                    : Icons.account_balance,
            color: const Color(0xFF1565C0),
          ),
        ),
        title: Text(account.name,
            style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(
          isCc ? 'Outstanding' : 'Balance',
          style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              _inr(account.balance.abs()),
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: balColor),
            ),
            if (isCc && account.balance <= 0)
              Text('Cleared',
                  style: TextStyle(
                      fontSize: 11, color: Colors.green.shade700)),
          ],
        ),
        onTap: () => _showAccountDetail(context),
        onLongPress: () => _showEditDialog(context),
      ),
    );
  }

  void _showAccountDetail(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _AccountDetailSheet(account: account),
    );
  }

  void _showEditDialog(BuildContext context) {
    final nameCtrl = TextEditingController(text: account.name);
    final balCtrl =
        TextEditingController(text: account.openingBalance.toStringAsFixed(2));

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Edit ${account.name}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(
                  labelText: 'Name', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: balCtrl,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                  labelText: account.type == 'credit_card'
                      ? 'Opening Outstanding (₹)'
                      : 'Opening Balance (₹)',
                  border: const OutlineInputBorder(),
                  prefixText: '₹ '),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel')),
          TextButton(
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: ctx,
                builder: (c) => AlertDialog(
                  title: const Text('Deactivate Account?'),
                  content: Text(
                      'Hide "${account.name}" from the accounts list?'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(c, false),
                        child: const Text('Cancel')),
                    TextButton(
                        onPressed: () => Navigator.pop(c, true),
                        child: const Text('Deactivate',
                            style: TextStyle(color: Colors.red))),
                  ],
                ),
              );
              if (confirm == true) {
                await ApiService.deleteAccount(account.id);
                if (ctx.mounted) Navigator.pop(ctx);
                onRefresh();
              }
            },
            child: const Text('Deactivate'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1565C0),
                foregroundColor: Colors.white),
            onPressed: () async {
              try {
                await ApiService.updateAccount(
                  account.id,
                  name: nameCtrl.text.trim().isEmpty ? null : nameCtrl.text.trim(),
                  openingBalance: double.tryParse(balCtrl.text),
                );
                if (ctx.mounted) Navigator.pop(ctx);
                onRefresh();
              } catch (e) {
                if (ctx.mounted) {
                  ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                      content: Text('Error: $e'),
                      backgroundColor: Colors.red));
                }
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }
}

class _AccountDetailSheet extends StatefulWidget {
  final Account account;
  const _AccountDetailSheet({required this.account});

  @override
  State<_AccountDetailSheet> createState() => _AccountDetailSheetState();
}

class _AccountDetailSheetState extends State<_AccountDetailSheet> {
  List<AccountTransfer> _transfers = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final all = await ApiService.getTransfers();
      setState(() {
        _transfers = all
            .where((t) =>
                t.fromAccountId == widget.account.id ||
                t.toAccountId == widget.account.id)
            .toList()
          ..sort((a, b) => b.transferDate.compareTo(a.transferDate));
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isCc = widget.account.type == 'credit_card';
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.6,
      maxChildSize: 0.92,
      builder: (_, ctrl) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(widget.account.name,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      _inr(widget.account.balance.abs()),
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: isCc && widget.account.balance > 0
                              ? Colors.red.shade700
                              : Colors.green.shade700),
                    ),
                    Text(
                      isCc ? 'Outstanding' : 'Balance',
                      style: TextStyle(
                          fontSize: 12, color: Colors.grey.shade600),
                    ),
                  ],
                ),
              ],
            ),
            const Divider(height: 24),
            const Text('Recent Transfers',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            const SizedBox(height: 8),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _transfers.isEmpty
                      ? Center(
                          child: Text('No transfers',
                              style: TextStyle(color: Colors.grey.shade500)))
                      : ListView.builder(
                          controller: ctrl,
                          itemCount: _transfers.length,
                          itemBuilder: (_, i) {
                            final t = _transfers[i];
                            final isOut = t.fromAccountId == widget.account.id;
                            return ListTile(
                              dense: true,
                              leading: Icon(
                                isOut
                                    ? Icons.arrow_upward
                                    : Icons.arrow_downward,
                                color: isOut
                                    ? Colors.red.shade600
                                    : Colors.green.shade600,
                                size: 20,
                              ),
                              title: Text(
                                isOut
                                    ? 'To ${t.toAccountName}'
                                    : 'From ${t.fromAccountName}',
                                style: const TextStyle(fontSize: 13),
                              ),
                              subtitle: Text(
                                DateFormat('dd MMM yyyy').format(t.transferDate),
                                style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.grey.shade600),
                              ),
                              trailing: Text(
                                '${isOut ? '-' : '+'}${_inr(t.amount)}',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: isOut
                                        ? Colors.red.shade600
                                        : Colors.green.shade600),
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}
