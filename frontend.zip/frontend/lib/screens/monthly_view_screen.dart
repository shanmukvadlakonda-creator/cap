import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../models/budget.dart';
import '../widgets/category_group_tile.dart';
import 'add_transaction_screen.dart';

class MonthlyViewScreen extends StatefulWidget {
  final int year;
  final int month;

  const MonthlyViewScreen({super.key, required this.year, required this.month});

  @override
  State<MonthlyViewScreen> createState() => _MonthlyViewScreenState();
}

class _MonthlyViewScreenState extends State<MonthlyViewScreen>
    with SingleTickerProviderStateMixin {
  late int _year = widget.year;
  late int _month = widget.month;
  MonthlyDailyView? _data;
  bool _loading = true;
  String? _error;
  late TabController _tabCtrl;
  final _fmt = NumberFormat('#,##,##0.00', 'en_IN');

  static const _months = [
    '', 'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final data = await ApiService.getMonthlyView(_year, _month);
      setState(() => _data = data);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _prevMonth() {
    if (_month == 1) { _month = 12; _year--; }
    else { _month--; }
    _load();
  }

  void _nextMonth() {
    if (_month == 12) { _month = 1; _year++; }
    else { _month++; }
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
        title: Row(
          children: [
            IconButton(
                icon: const Icon(Icons.chevron_left, color: Colors.white),
                onPressed: _prevMonth),
            Text('${_months[_month]} $_year',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
            IconButton(
                icon: const Icon(Icons.chevron_right, color: Colors.white),
                onPressed: _nextMonth),
          ],
        ),
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(text: 'Summary', icon: Icon(Icons.pie_chart_outline, size: 18)),
            Tab(text: 'Daily', icon: Icon(Icons.calendar_today, size: 18)),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF1565C0),
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () async {
          final added = await Navigator.push<bool>(
              context,
              MaterialPageRoute(
                  builder: (_) =>
                      AddTransactionScreen(year: _year, month: _month)));
          if (added == true) _load();
        },
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(_error!, style: const TextStyle(color: Colors.red)),
                      TextButton(onPressed: _load, child: const Text('Retry')),
                    ],
                  ))
              : TabBarView(
                  controller: _tabCtrl,
                  children: [
                    _buildSummaryTab(),
                    _buildDailyTab(),
                  ],
                ),
    );
  }

  Widget _buildSummaryTab() {
    final d = _data!;
    final income = d.groups
        .where((g) => g.groupType == 'income')
        .fold(0.0, (s, g) => s + g.actual);
    final expenses = d.groups
        .where((g) => g.groupType != 'income')
        .fold(0.0, (s, g) => s + g.actual);
    final net = income - expenses;

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          // Top summary row
          Row(
            children: [
              Expanded(
                  child: _StatChip(
                      label: 'Income',
                      value: '₹${_fmt.format(income)}',
                      color: Colors.green[700]!)),
              const SizedBox(width: 8),
              Expanded(
                  child: _StatChip(
                      label: 'Expenses',
                      value: '₹${_fmt.format(expenses)}',
                      color: Colors.red[700]!)),
              const SizedBox(width: 8),
              Expanded(
                  child: _StatChip(
                      label: 'NET',
                      value: '₹${_fmt.format(net)}',
                      color: net >= 0 ? Colors.green[700]! : Colors.red[700]!)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                  child: _StatChip(
                      label: 'Spending Bal',
                      value: '₹${_fmt.format(d.days.isNotEmpty ? d.days.last.spendingBalance : d.beginningSpendingBalance)}',
                      color: Colors.blue[700]!)),
              const SizedBox(width: 8),
              Expanded(
                  child: _StatChip(
                      label: 'Savings Bal',
                      value: '₹${_fmt.format(d.days.isNotEmpty ? d.days.last.savingsBalance : d.beginningSavingsBalance)}',
                      color: Colors.indigo[700]!)),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(),
          ...d.groups.map((g) => CategoryGroupTile(group: g)).toList(),
        ],
      ),
    );
  }

  Widget _buildDailyTab() {
    final d = _data!;
    final activeDays = d.days.where((day) =>
        day.totalIncome > 0 || day.totalExpenses > 0).toList();

    if (activeDays.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.calendar_today, size: 48, color: Colors.grey),
            SizedBox(height: 8),
            Text('No transactions this month',
                style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: activeDays.length,
      itemBuilder: (_, i) {
        final day = activeDays[i];
        final net = day.net;
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: const Color(0xFF1565C0),
              child: Text(
                '${day.date.day}',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
            title: Row(
              children: [
                _MiniStat(
                    label: 'In', value: day.totalIncome, color: Colors.green),
                const SizedBox(width: 12),
                _MiniStat(
                    label: 'Out',
                    value: day.totalExpenses,
                    color: Colors.red),
                const SizedBox(width: 12),
                _MiniStat(
                    label: 'Net',
                    value: net,
                    color: net >= 0 ? Colors.green : Colors.red),
              ],
            ),
            subtitle: Text(
              'Balance: ₹${_fmt.format(day.spendingBalance)}',
              style: TextStyle(
                  fontSize: 11,
                  color: day.spendingBalance >= 0
                      ? Colors.green[700]
                      : Colors.red[700]),
            ),
          ),
        );
      },
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatChip(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: TextStyle(fontSize: 11, color: Colors.grey[600])),
          Text(value,
              style: TextStyle(
                  fontSize: 13, fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  final _fmt = NumberFormat('#,##,##0', 'en_IN');

  _MiniStat({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(fontSize: 10, color: Colors.grey[500])),
        Text('₹${_fmt.format(value.abs())}',
            style: TextStyle(
                fontSize: 12, fontWeight: FontWeight.w600, color: color)),
      ],
    );
  }
}
