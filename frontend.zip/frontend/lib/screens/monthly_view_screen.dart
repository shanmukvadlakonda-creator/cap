import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../services/auth_service.dart';
import '../models/budget.dart';
import '../models/transaction.dart';
import '../models/user.dart';
import '../models/category.dart';
import '../models/account.dart';
import '../models/investment.dart';
import '../models/loan.dart';
import '../widgets/category_group_tile.dart';
import 'add_transaction_screen.dart';

class MonthlyViewScreen extends StatefulWidget {
  final int year;
  final int month;

  const MonthlyViewScreen({super.key, required this.year, required this.month});

  @override
  State<MonthlyViewScreen> createState() => _MonthlyViewScreenState();
}

class _MonthlyViewScreenState extends State<MonthlyViewScreen>
    with SingleTickerProviderStateMixin {
  late int _year = widget.year;
  late int _month = widget.month;
  MonthlyDailyView? _data;
  List<Transaction> _transactions = [];
  List<User> _users = [];
  List<CategoryGroup> _groups = [];
  List<Account> _accounts = [];
  List<Investment> _investments = [];
  List<Loan> _loans = [];
  int? _filterUserId;
  bool _loading = true;
  String? _error;
  late TabController _tabCtrl;
  final _fmt = NumberFormat('#,##,##0.00', 'en_IN');

  static const _months = [
    '', 'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    // Viewers can only see their own transactions
    if (AuthService.role == 'viewer') {
      _filterUserId = AuthService.userId;
    }
    _load();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final results = await Future.wait([
        ApiService.getMonthlyView(_year, _month),
        ApiService.getTransactions(year: _year, month: _month, userId: _filterUserId),
        ApiService.getUsers(),
        ApiService.getCategories(),
        ApiService.getAccounts(),
      ]);
      setState(() {
        _data = results[0] as MonthlyDailyView;
        _transactions = results[1] as List<Transaction>;
        _users = results[2] as List<User>;
        _groups = results[3] as List<CategoryGroup>;
        _accounts = results[4] as List<Account>;
      });
      // Load investments and loans silently
      try {
        final inv = await ApiService.getInvestments();
        if (mounted) setState(() => _investments = inv.where((i) => i.isActive).toList());
      } catch (_) {}
      try {
        final loans = await ApiService.getLoans();
        if (mounted) setState(() => _loans = loans.where((l) => l.isActive).toList());
      } catch (_) {}
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _reloadTransactions() async {
    try {
      final txns = await ApiService.getTransactions(
          year: _year, month: _month, userId: _filterUserId);
      setState(() => _transactions = txns);
    } catch (_) {}
  }

  void _prevMonth() {
    if (_month == 1) { _month = 12; _year--; }
    else { _month--; }
    _load();
  }

  void _nextMonth() {
    if (_month == 12) { _month = 1; _year++; }
    else { _month++; }
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
        title: Row(
          children: [
            IconButton(
                icon: const Icon(Icons.chevron_left, color: Colors.white),
                onPressed: _prevMonth),
            Text('${_months[_month]} $_year',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
            IconButton(
                icon: const Icon(Icons.chevron_right, color: Colors.white),
                onPressed: _nextMonth),
          ],
        ),
        actions: [
          if (_users.isNotEmpty) _buildUserFilter(),
        ],
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(text: 'Summary', icon: Icon(Icons.pie_chart_outline, size: 18)),
            Tab(text: 'Daily', icon: Icon(Icons.calendar_today, size: 18)),
          ],
        ),
      ),
      floatingActionButton: AuthService.role != 'viewer'
          ? FloatingActionButton(
              backgroundColor: const Color(0xFF1565C0),
              child: const Icon(Icons.add, color: Colors.white),
              onPressed: () async {
                final added = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(
                        builder: (_) =>
                            AddTransactionScreen(year: _year, month: _month)));
                if (added == true) _load();
              },
            )
          : null,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(_error!, style: const TextStyle(color: Colors.red)),
                      TextButton(onPressed: _load, child: const Text('Retry')),
                    ],
                  ))
              : TabBarView(
                  controller: _tabCtrl,
                  children: [
                    _buildSummaryTab(),
                    _buildDailyTab(),
                  ],
                ),
    );
  }

  Widget _buildUserFilter() {
    final isViewer = AuthService.role == 'viewer';
    // Build items: viewers have no "All" option
    final items = <DropdownMenuItem<int?>>[];
    if (!isViewer) {
      items.add(const DropdownMenuItem<int?>(
        value: null,
        child: Text('All', style: TextStyle(color: Colors.white)),
      ));
    }
    for (final u in _users) {
      items.add(DropdownMenuItem<int?>(
        value: u.id,
        child: Text(u.displayName, style: const TextStyle(color: Colors.white)),
      ));
    }
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: DropdownButton<int?>(
        value: _filterUserId,
        dropdownColor: const Color(0xFF1565C0),
        iconEnabledColor: Colors.white,
        underline: const SizedBox(),
        items: items,
        onChanged: isViewer
            ? null
            : (v) {
                setState(() => _filterUserId = v);
                _reloadTransactions();
              },
      ),
    );
  }

  Widget _buildSummaryTab() {
    final d = _data!;
    final income = d.groups
        .where((g) => g.groupType == 'income')
        .fold(0.0, (s, g) => s + g.actual);
    final expenses = d.groups
        .where((g) => g.groupType != 'income')
        .fold(0.0, (s, g) => s + g.actual);
    final net = income - expenses;

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Row(
            children: [
              Expanded(
                  child: _StatChip(
                      label: 'Income',
                      value: '₹${_fmt.format(income)}',
                      color: Colors.green[700]!)),
              const SizedBox(width: 8),
              Expanded(
                  child: _StatChip(
                      label: 'Expenses',
                      value: '₹${_fmt.format(expenses)}',
                      color: Colors.red[700]!)),
              const SizedBox(width: 8),
              Expanded(
                  child: _StatChip(
                      label: 'NET',
                      value: '₹${_fmt.format(net)}',
                      color: net >= 0 ? Colors.green[700]! : Colors.red[700]!)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                  child: _StatChip(
                      label: 'Spending Bal',
                      value: '₹${_fmt.format(d.days.isNotEmpty ? d.days.last.spendingBalance : d.beginningSpendingBalance)}',
                      color: Colors.blue[700]!)),
              const SizedBox(width: 8),
              Expanded(
                  child: _StatChip(
                      label: 'Savings Bal',
                      value: '₹${_fmt.format(d.days.isNotEmpty ? d.days.last.savingsBalance : d.beginningSavingsBalance)}',
                      color: Colors.indigo[700]!)),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(),
          ...d.groups.map((g) => CategoryGroupTile(group: g)).toList(),
        ],
      ),
    );
  }

  Widget _buildDailyTab() {
    final d = _data!;
    final dayMap = {
      for (final day in d.days)
        if (day.totalIncome > 0 || day.totalExpenses > 0) day.date.day: day
    };

    final daysInMonth = DateTime(_year, _month + 1, 0).day;
    final firstWeekday = DateTime(_year, _month, 1).weekday; // 1=Mon, 7=Sun
    final today = DateTime.now();
    const dayHeaders = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    return SingleChildScrollView(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: dayHeaders
                .map((h) => Expanded(
                      child: Center(
                        child: Text(h,
                            style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: Colors.grey.shade500)),
                      ),
                    ))
                .toList(),
          ),
          const SizedBox(height: 6),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7,
              mainAxisSpacing: 4,
              crossAxisSpacing: 4,
              childAspectRatio: 0.9,
            ),
            itemCount: (firstWeekday - 1) + daysInMonth,
            itemBuilder: (_, idx) {
              if (idx < firstWeekday - 1) return const SizedBox();
              final dayNum = idx - (firstWeekday - 1) + 1;
              final dayView = dayMap[dayNum];
              final hasActivity = dayView != null;
              final isToday = today.year == _year &&
                  today.month == _month &&
                  today.day == dayNum;

              Color bgColor;
              Color borderColor;
              Color dayNumColor;
              if (isToday) {
                bgColor = const Color(0xFF1565C0);
                borderColor = const Color(0xFF1565C0);
                dayNumColor = Colors.white;
              } else if (!hasActivity) {
                bgColor = Colors.white;
                borderColor = Colors.grey.shade200;
                dayNumColor = Colors.grey.shade700;
              } else if (dayView.net >= 0) {
                bgColor = const Color(0xFFE8F5E9);
                borderColor = const Color(0xFF81C784);
                dayNumColor = const Color(0xFF2E7D32);
              } else {
                bgColor = const Color(0xFFFFEBEE);
                borderColor = const Color(0xFFEF9A9A);
                dayNumColor = const Color(0xFFC62828);
              }

              final dayTxns = _transactions
                  .where((t) =>
                      t.transactionDate.year == _year &&
                      t.transactionDate.month == _month &&
                      t.transactionDate.day == dayNum)
                  .toList();

              return GestureDetector(
                onTap: dayTxns.isNotEmpty
                    ? () => _showDaySheet(DateTime(_year, _month, dayNum), dayTxns)
                    : null,
                child: Container(
                  decoration: BoxDecoration(
                    color: bgColor,
                    borderRadius: BorderRadius.circular(7),
                    border: Border.all(color: borderColor, width: 1),
                  ),
                  padding: const EdgeInsets.fromLTRB(3, 3, 3, 2),
                  child: Center(
                    child: Text(
                      '$dayNum',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: dayNumColor),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  String _fmtK(double v) {
    final abs = v.abs();
    final sign = v < 0 ? '-' : '+';
    if (abs >= 100000) return '$sign${(abs / 100000).toStringAsFixed(1)}L';
    if (abs >= 1000) return '$sign${(abs / 1000).toStringAsFixed(0)}K';
    return '$sign${abs.toStringAsFixed(0)}';
  }

  void _showDaySheet(DateTime date, List<Transaction> dayTxns) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 60),
        child: _DayTransactionSheet(
          date: date,
          transactions: dayTxns,
          groups: _groups,
          accounts: _accounts,
          investments: _investments,
          loans: _loans,
          users: _users,
          onChanged: () {
            Navigator.pop(ctx);
            _load();
          },
        ),
      ),
    );
  }
}

class _DayTransactionSheet extends StatelessWidget {
  final DateTime date;
  final List<Transaction> transactions;
  final List<CategoryGroup> groups;
  final List<Account> accounts;
  final List<Investment> investments;
  final List<Loan> loans;
  final List<User> users;
  final VoidCallback onChanged;

  const _DayTransactionSheet({
    required this.date,
    required this.transactions,
    required this.groups,
    required this.accounts,
    required this.investments,
    required this.loans,
    required this.users,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    DateFormat('EEEE, dd MMMM yyyy').format(date),
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Icon(Icons.close, size: 20, color: Colors.grey.shade600),
                ),
              ],
            ),
            const Divider(height: 16),
            SizedBox(
              height: 320,
              child: ListView.builder(
                itemCount: transactions.length,
                itemBuilder: (_, i) {
                  final t = transactions[i];
                  final canEdit = AuthService.isAdmin || t.userId == AuthService.userId;
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      radius: 18,
                      backgroundColor: const Color(0xFF1565C0).withAlpha(20),
                      child: const Icon(Icons.receipt_long,
                          color: Color(0xFF1565C0), size: 16),
                    ),
                    title: Text(t.categoryName,
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 13)),
                    subtitle: Text(
                      '${t.userDisplayName}${t.note != null && t.note!.isNotEmpty ? ' · ${t.note}' : ''}${t.accountName != null ? ' · ${t.accountName}' : ''}',
                      style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '₹${NumberFormat('#,##0.00', 'en_IN').format(t.amount)}',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        if (canEdit) ...[
                          const SizedBox(width: 4),
                          InkWell(
                            onTap: () => _showEditDialog(context, t),
                            child: const Padding(
                              padding: EdgeInsets.all(4),
                              child: Icon(Icons.edit_outlined,
                                  size: 18, color: Color(0xFF1565C0)),
                            ),
                          ),
                          InkWell(
                            onTap: () => _confirmDelete(context, t),
                            child: Padding(
                              padding: const EdgeInsets.all(4),
                              child: Icon(Icons.delete_outline,
                                  size: 18, color: Colors.red.shade400),
                            ),
                          ),
                        ],
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, Transaction t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete Transaction?'),
        content: Text('Remove ₹${NumberFormat('#,##0.00', 'en_IN').format(t.amount)} - ${t.categoryName}?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Cancel')),
          TextButton(
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok == true) {
      try {
        await ApiService.deleteTransaction(t.id);
        onChanged();
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Error: $e'), backgroundColor: Colors.red));
        }
      }
    }
  }

  void _showEditDialog(BuildContext context, Transaction t) {
    // Find initial category group and category
    CategoryGroup? initGroup;
    Category? initCategory;
    for (final g in groups) {
      for (final c in g.categories) {
        if (c.id == t.categoryId) {
          initGroup = g;
          initCategory = c;
          break;
        }
      }
      if (initGroup != null) break;
    }

    CategoryGroup? selGroup = initGroup;
    Category? selCategory = initCategory;
    Account? selAccount = accounts.where((a) => a.id == t.accountId).firstOrNull;
    // Pre-populate investment/loan from the transaction's existing links
    // Use a sentinel "no change" vs "cleared" distinction via _selInvestment/_selLoan nullable
    Investment? selInvestment = investments.where((i) => i.id == t.investmentId).firstOrNull;
    Loan? selLoan = loans.where((l) => l.id == t.loanId).firstOrNull;
    DateTime selDate = t.transactionDate;
    final amtCtrl = TextEditingController(text: t.amount.toStringAsFixed(2));
    final noteCtrl = TextEditingController(text: t.note ?? '');
    bool saving = false;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Edit Transaction'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Date
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  leading: const Icon(Icons.calendar_today,
                      color: Color(0xFF1565C0), size: 18),
                  title: Text(DateFormat('dd MMM yyyy').format(selDate),
                      style: const TextStyle(fontSize: 13)),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      initialDate: selDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2100),
                    );
                    if (d != null) setS(() => selDate = d);
                  },
                ),
                const SizedBox(height: 8),
                // Category group
                DropdownButtonFormField<CategoryGroup>(
                  value: selGroup,
                  decoration: const InputDecoration(
                      labelText: 'Category Group',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: groups
                      .map((g) => DropdownMenuItem(value: g, child: Text(g.name)))
                      .toList(),
                  onChanged: (g) => setS(() {
                    selGroup = g;
                    selCategory = null;
                  }),
                ),
                const SizedBox(height: 8),
                // Category
                DropdownButtonFormField<Category>(
                  value: selCategory,
                  decoration: const InputDecoration(
                      labelText: 'Category',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: (selGroup?.categories ?? [])
                      .map((c) => DropdownMenuItem(value: c, child: Text(c.name)))
                      .toList(),
                  onChanged: (c) => setS(() => selCategory = c),
                ),
                const SizedBox(height: 8),
                // Amount
                TextField(
                  controller: amtCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                      labelText: 'Amount (₹)',
                      border: OutlineInputBorder(),
                      isDense: true,
                      prefixText: '₹ '),
                ),
                const SizedBox(height: 8),
                // Account
                DropdownButtonFormField<Account?>(
                  value: selAccount,
                  decoration: const InputDecoration(
                      labelText: 'Account',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: [
                    const DropdownMenuItem<Account?>(
                        value: null, child: Text('None')),
                    ...accounts.map((a) => DropdownMenuItem<Account?>(
                        value: a, child: Text(a.name))),
                  ],
                  onChanged: (v) => setS(() => selAccount = v),
                ),
                const SizedBox(height: 8),
                // Investment link
                if (investments.isNotEmpty || t.investmentId != null) ...[
                  DropdownButtonFormField<Investment?>(
                    value: selInvestment,
                    decoration: const InputDecoration(
                        labelText: 'Investment (optional)',
                        border: OutlineInputBorder(),
                        isDense: true),
                    items: [
                      const DropdownMenuItem<Investment?>(
                          value: null, child: Text('None')),
                      ...investments.map((inv) => DropdownMenuItem<Investment?>(
                          value: inv,
                          child: Text('${inv.name} (${inv.type})',
                              overflow: TextOverflow.ellipsis))),
                    ],
                    onChanged: (v) => setS(() {
                      selInvestment = v;
                      if (v != null) selLoan = null;
                    }),
                  ),
                  const SizedBox(height: 8),
                ],
                // Loan link
                if (loans.isNotEmpty || t.loanId != null) ...[
                  DropdownButtonFormField<Loan?>(
                    value: selLoan,
                    decoration: const InputDecoration(
                        labelText: 'Loan EMI (optional)',
                        border: OutlineInputBorder(),
                        isDense: true),
                    items: [
                      const DropdownMenuItem<Loan?>(
                          value: null, child: Text('None')),
                      ...loans.map((l) => DropdownMenuItem<Loan?>(
                          value: l,
                          child: Text('${l.name} (${l.type})',
                              overflow: TextOverflow.ellipsis))),
                    ],
                    onChanged: (v) => setS(() {
                      selLoan = v;
                      if (v != null) selInvestment = null;
                    }),
                  ),
                  const SizedBox(height: 8),
                ],
                // Note
                TextField(
                  controller: noteCtrl,
                  decoration: const InputDecoration(
                      labelText: 'Note (optional)',
                      border: OutlineInputBorder(),
                      isDense: true),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1565C0),
                  foregroundColor: Colors.white),
              onPressed: saving
                  ? null
                  : () async {
                      if (selCategory == null) return;
                      final amt = double.tryParse(amtCtrl.text);
                      if (amt == null || amt <= 0) return;
                      setS(() => saving = true);
                      try {
                        await ApiService.updateTransaction(
                          t.id,
                          categoryId: selCategory!.id,
                          amount: amt,
                          date: selDate,
                          accountId: selAccount?.id,
                          investmentId: selInvestment?.id,
                          clearInvestment: selInvestment == null && t.investmentId != null,
                          loanId: selLoan?.id,
                          clearLoan: selLoan == null && t.loanId != null,
                          note: noteCtrl.text.isEmpty ? null : noteCtrl.text,
                        );
                        if (ctx.mounted) Navigator.pop(ctx);
                        onChanged();
                      } catch (e) {
                        setS(() => saving = false);
                        if (ctx.mounted) {
                          ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                              content: Text('Error: $e'),
                              backgroundColor: Colors.red));
                        }
                      }
                    },
              child: saving
                  ? const SizedBox(
                      height: 16,
                      width: 16,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2))
                  : const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatChip(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: TextStyle(fontSize: 14, color: Colors.grey[600])),
          Text(value,
              style: TextStyle(
                  fontSize: 17, fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  final _fmt = NumberFormat('#,##,##0', 'en_IN');

  _MiniStat({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(fontSize: 13, color: Colors.grey[500])),
        Text('₹${_fmt.format(value.abs())}',
            style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.w600, color: color)),
      ],
    );
  }
}
