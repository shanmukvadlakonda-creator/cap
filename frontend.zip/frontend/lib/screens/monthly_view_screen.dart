import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';
import '../services/auth_service.dart';
import '../models/budget.dart';
import '../models/transaction.dart';
import '../models/user.dart';
import '../models/category.dart';
import '../models/account.dart';
import '../widgets/category_group_tile.dart';
import 'add_transaction_screen.dart';

class MonthlyViewScreen extends StatefulWidget {
  final int year;
  final int month;

  const MonthlyViewScreen({super.key, required this.year, required this.month});

  @override
  State<MonthlyViewScreen> createState() => _MonthlyViewScreenState();
}

class _MonthlyViewScreenState extends State<MonthlyViewScreen>
    with SingleTickerProviderStateMixin {
  late int _year = widget.year;
  late int _month = widget.month;
  MonthlyDailyView? _data;
  List<Transaction> _transactions = [];
  List<User> _users = [];
  List<CategoryGroup> _groups = [];
  List<Account> _accounts = [];
  int? _filterUserId;
  bool _loading = true;
  String? _error;
  late TabController _tabCtrl;
  final _fmt = NumberFormat('#,##,##0.00', 'en_IN');

  static const _months = [
    '', 'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    // Viewers can only see their own transactions
    if (AuthService.role == 'viewer') {
      _filterUserId = AuthService.userId;
    }
    _load();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final results = await Future.wait([
        ApiService.getMonthlyView(_year, _month),
        ApiService.getTransactions(year: _year, month: _month, userId: _filterUserId),
        ApiService.getUsers(),
        ApiService.getCategories(),
        ApiService.getAccounts(),
      ]);
      setState(() {
        _data = results[0] as MonthlyDailyView;
        _transactions = results[1] as List<Transaction>;
        _users = results[2] as List<User>;
        _groups = results[3] as List<CategoryGroup>;
        _accounts = results[4] as List<Account>;
      });
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _reloadTransactions() async {
    try {
      final txns = await ApiService.getTransactions(
          year: _year, month: _month, userId: _filterUserId);
      setState(() => _transactions = txns);
    } catch (_) {}
  }

  void _prevMonth() {
    if (_month == 1) { _month = 12; _year--; }
    else { _month--; }
    _load();
  }

  void _nextMonth() {
    if (_month == 12) { _month = 1; _year++; }
    else { _month++; }
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
        title: Row(
          children: [
            IconButton(
                icon: const Icon(Icons.chevron_left, color: Colors.white),
                onPressed: _prevMonth),
            Text('${_months[_month]} $_year',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
            IconButton(
                icon: const Icon(Icons.chevron_right, color: Colors.white),
                onPressed: _nextMonth),
          ],
        ),
        actions: [
          if (_users.isNotEmpty) _buildUserFilter(),
        ],
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(text: 'Summary', icon: Icon(Icons.pie_chart_outline, size: 18)),
            Tab(text: 'Daily', icon: Icon(Icons.calendar_today, size: 18)),
          ],
        ),
      ),
      floatingActionButton: AuthService.role != 'viewer'
          ? FloatingActionButton(
              backgroundColor: const Color(0xFF1565C0),
              child: const Icon(Icons.add, color: Colors.white),
              onPressed: () async {
                final added = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(
                        builder: (_) =>
                            AddTransactionScreen(year: _year, month: _month)));
                if (added == true) _load();
              },
            )
          : null,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(_error!, style: const TextStyle(color: Colors.red)),
                      TextButton(onPressed: _load, child: const Text('Retry')),
                    ],
                  ))
              : TabBarView(
                  controller: _tabCtrl,
                  children: [
                    _buildSummaryTab(),
                    _buildDailyTab(),
                  ],
                ),
    );
  }

  Widget _buildUserFilter() {
    final isViewer = AuthService.role == 'viewer';
    // Build items: viewers have no "All" option
    final items = <DropdownMenuItem<int?>>[];
    if (!isViewer) {
      items.add(const DropdownMenuItem<int?>(
        value: null,
        child: Text('All', style: TextStyle(color: Colors.white)),
      ));
    }
    for (final u in _users) {
      items.add(DropdownMenuItem<int?>(
        value: u.id,
        child: Text(u.displayName, style: const TextStyle(color: Colors.white)),
      ));
    }
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: DropdownButton<int?>(
        value: _filterUserId,
        dropdownColor: const Color(0xFF1565C0),
        iconEnabledColor: Colors.white,
        underline: const SizedBox(),
        items: items,
        onChanged: isViewer
            ? null
            : (v) {
                setState(() => _filterUserId = v);
                _reloadTransactions();
              },
      ),
    );
  }

  Widget _buildSummaryTab() {
    final d = _data!;
    final income = d.groups
        .where((g) => g.groupType == 'income')
        .fold(0.0, (s, g) => s + g.actual);
    final expenses = d.groups
        .where((g) => g.groupType != 'income')
        .fold(0.0, (s, g) => s + g.actual);
    final net = income - expenses;

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Row(
            children: [
              Expanded(
                  child: _StatChip(
                      label: 'Income',
                      value: '₹${_fmt.format(income)}',
                      color: Colors.green[700]!)),
              const SizedBox(width: 8),
              Expanded(
                  child: _StatChip(
                      label: 'Expenses',
                      value: '₹${_fmt.format(expenses)}',
                      color: Colors.red[700]!)),
              const SizedBox(width: 8),
              Expanded(
                  child: _StatChip(
                      label: 'NET',
                      value: '₹${_fmt.format(net)}',
                      color: net >= 0 ? Colors.green[700]! : Colors.red[700]!)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                  child: _StatChip(
                      label: 'Spending Bal',
                      value: '₹${_fmt.format(d.days.isNotEmpty ? d.days.last.spendingBalance : d.beginningSpendingBalance)}',
                      color: Colors.blue[700]!)),
              const SizedBox(width: 8),
              Expanded(
                  child: _StatChip(
                      label: 'Savings Bal',
                      value: '₹${_fmt.format(d.days.isNotEmpty ? d.days.last.savingsBalance : d.beginningSavingsBalance)}',
                      color: Colors.indigo[700]!)),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(),
          ...d.groups.map((g) => CategoryGroupTile(group: g)).toList(),
        ],
      ),
    );
  }

  Widget _buildDailyTab() {
    final d = _data!;
    final activeDays = d.days.where((day) =>
        day.totalIncome > 0 || day.totalExpenses > 0).toList();

    if (activeDays.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.calendar_today, size: 48, color: Colors.grey),
            SizedBox(height: 8),
            Text('No transactions this month',
                style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: activeDays.length,
      itemBuilder: (_, i) {
        final day = activeDays[i];
        final net = day.net;
        final dayTxns = _transactions
            .where((t) =>
                t.transactionDate.year == day.date.year &&
                t.transactionDate.month == day.date.month &&
                t.transactionDate.day == day.date.day)
            .toList();
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: dayTxns.isNotEmpty
                ? () => _showDaySheet(day.date, dayTxns)
                : null,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundColor: const Color(0xFF1565C0),
                    child: Text(
                      '${day.date.day}',
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            _MiniStat(label: 'In', value: day.totalIncome, color: Colors.green),
                            const SizedBox(width: 12),
                            _MiniStat(label: 'Out', value: day.totalExpenses, color: Colors.red),
                            const SizedBox(width: 12),
                            _MiniStat(
                                label: 'Net',
                                value: net,
                                color: net >= 0 ? Colors.green : Colors.red),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Balance: ₹${_fmt.format(day.spendingBalance)}',
                          style: TextStyle(
                              fontSize: 11,
                              color: day.spendingBalance >= 0
                                  ? Colors.green[700]
                                  : Colors.red[700]),
                        ),
                      ],
                    ),
                  ),
                  if (dayTxns.isNotEmpty)
                    Icon(Icons.chevron_right, color: Colors.grey.shade400, size: 18),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showDaySheet(DateTime date, List<Transaction> dayTxns) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _DayTransactionSheet(
        date: date,
        transactions: dayTxns,
        groups: _groups,
        accounts: _accounts,
        users: _users,
        onChanged: () {
          Navigator.pop(context);
          _load();
        },
      ),
    );
  }
}

class _DayTransactionSheet extends StatelessWidget {
  final DateTime date;
  final List<Transaction> transactions;
  final List<CategoryGroup> groups;
  final List<Account> accounts;
  final List<User> users;
  final VoidCallback onChanged;

  const _DayTransactionSheet({
    required this.date,
    required this.transactions,
    required this.groups,
    required this.accounts,
    required this.users,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.55,
      maxChildSize: 0.92,
      builder: (_, ctrl) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40, height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              DateFormat('EEEE, dd MMMM yyyy').format(date),
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 8),
            const Divider(),
            Expanded(
              child: ListView.builder(
                controller: ctrl,
                itemCount: transactions.length,
                itemBuilder: (_, i) {
                  final t = transactions[i];
                  final canEdit = AuthService.isAdmin || t.userId == AuthService.userId;
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      radius: 18,
                      backgroundColor: const Color(0xFF1565C0).withAlpha(20),
                      child: const Icon(Icons.receipt_long,
                          color: Color(0xFF1565C0), size: 16),
                    ),
                    title: Text(t.categoryName,
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 13)),
                    subtitle: Text(
                      '${t.userDisplayName}${t.note != null && t.note!.isNotEmpty ? ' · ${t.note}' : ''}${t.accountName != null ? ' · ${t.accountName}' : ''}',
                      style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '₹${NumberFormat('#,##0.00', 'en_IN').format(t.amount)}',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        if (canEdit) ...[
                          const SizedBox(width: 4),
                          InkWell(
                            onTap: () => _showEditDialog(context, t),
                            child: const Padding(
                              padding: EdgeInsets.all(4),
                              child: Icon(Icons.edit_outlined,
                                  size: 18, color: Color(0xFF1565C0)),
                            ),
                          ),
                          InkWell(
                            onTap: () => _confirmDelete(context, t),
                            child: Padding(
                              padding: const EdgeInsets.all(4),
                              child: Icon(Icons.delete_outline,
                                  size: 18, color: Colors.red.shade400),
                            ),
                          ),
                        ],
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, Transaction t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete Transaction?'),
        content: Text('Remove ₹${NumberFormat('#,##0.00', 'en_IN').format(t.amount)} - ${t.categoryName}?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Cancel')),
          TextButton(
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok == true) {
      try {
        await ApiService.deleteTransaction(t.id);
        onChanged();
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Error: $e'), backgroundColor: Colors.red));
        }
      }
    }
  }

  void _showEditDialog(BuildContext context, Transaction t) {
    // Find initial category group and category
    CategoryGroup? initGroup;
    Category? initCategory;
    for (final g in groups) {
      for (final c in g.categories) {
        if (c.id == t.categoryId) {
          initGroup = g;
          initCategory = c;
          break;
        }
      }
      if (initGroup != null) break;
    }

    CategoryGroup? selGroup = initGroup;
    Category? selCategory = initCategory;
    Account? selAccount = accounts.where((a) => a.id == t.accountId).firstOrNull;
    DateTime selDate = t.transactionDate;
    final amtCtrl = TextEditingController(text: t.amount.toStringAsFixed(2));
    final noteCtrl = TextEditingController(text: t.note ?? '');
    bool saving = false;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Edit Transaction'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Date
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  leading: const Icon(Icons.calendar_today,
                      color: Color(0xFF1565C0), size: 18),
                  title: Text(DateFormat('dd MMM yyyy').format(selDate),
                      style: const TextStyle(fontSize: 13)),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      initialDate: selDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2100),
                    );
                    if (d != null) setS(() => selDate = d);
                  },
                ),
                const SizedBox(height: 8),
                // Category group
                DropdownButtonFormField<CategoryGroup>(
                  value: selGroup,
                  decoration: const InputDecoration(
                      labelText: 'Category Group',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: groups
                      .map((g) => DropdownMenuItem(value: g, child: Text(g.name)))
                      .toList(),
                  onChanged: (g) => setS(() {
                    selGroup = g;
                    selCategory = null;
                  }),
                ),
                const SizedBox(height: 8),
                // Category
                DropdownButtonFormField<Category>(
                  value: selCategory,
                  decoration: const InputDecoration(
                      labelText: 'Category',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: (selGroup?.categories ?? [])
                      .map((c) => DropdownMenuItem(value: c, child: Text(c.name)))
                      .toList(),
                  onChanged: (c) => setS(() => selCategory = c),
                ),
                const SizedBox(height: 8),
                // Amount
                TextField(
                  controller: amtCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                      labelText: 'Amount (₹)',
                      border: OutlineInputBorder(),
                      isDense: true,
                      prefixText: '₹ '),
                ),
                const SizedBox(height: 8),
                // Account
                DropdownButtonFormField<Account?>(
                  value: selAccount,
                  decoration: const InputDecoration(
                      labelText: 'Account',
                      border: OutlineInputBorder(),
                      isDense: true),
                  items: [
                    const DropdownMenuItem<Account?>(
                        value: null, child: Text('None')),
                    ...accounts.map((a) => DropdownMenuItem<Account?>(
                        value: a, child: Text(a.name))),
                  ],
                  onChanged: (v) => setS(() => selAccount = v),
                ),
                const SizedBox(height: 8),
                // Note
                TextField(
                  controller: noteCtrl,
                  decoration: const InputDecoration(
                      labelText: 'Note (optional)',
                      border: OutlineInputBorder(),
                      isDense: true),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1565C0),
                  foregroundColor: Colors.white),
              onPressed: saving
                  ? null
                  : () async {
                      if (selCategory == null) return;
                      final amt = double.tryParse(amtCtrl.text);
                      if (amt == null || amt <= 0) return;
                      setS(() => saving = true);
                      try {
                        await ApiService.updateTransaction(
                          t.id,
                          categoryId: selCategory!.id,
                          amount: amt,
                          date: selDate,
                          accountId: selAccount?.id,
                          note: noteCtrl.text.isEmpty ? null : noteCtrl.text,
                        );
                        if (ctx.mounted) Navigator.pop(ctx);
                        onChanged();
                      } catch (e) {
                        setS(() => saving = false);
                        if (ctx.mounted) {
                          ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                              content: Text('Error: $e'),
                              backgroundColor: Colors.red));
                        }
                      }
                    },
              child: saving
                  ? const SizedBox(
                      height: 16,
                      width: 16,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2))
                  : const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _StatChip(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: TextStyle(fontSize: 11, color: Colors.grey[600])),
          Text(value,
              style: TextStyle(
                  fontSize: 13, fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  final _fmt = NumberFormat('#,##,##0', 'en_IN');

  _MiniStat({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(fontSize: 10, color: Colors.grey[500])),
        Text('₹${_fmt.format(value.abs())}',
            style: TextStyle(
                fontSize: 12, fontWeight: FontWeight.w600, color: color)),
      ],
    );
  }
}
