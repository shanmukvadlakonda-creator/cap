class ApiConfig {
  // Desktop: localhost. Mobile on Wi-Fi: change to your PC's local IP e.g. 192.168.1.100
  static const String baseUrl = 'http://localhost:8080/api';
}
